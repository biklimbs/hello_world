﻿# Base_URL="https://94lqsncnhj.execute-api.ap-south-1.amazonaws.com/staging/AutoWorldJapanGetPrice"

# MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
# MY_SQL_USER_NAME = 'root'
# MY_SQL_PASSWORD = 'Vmmobility@1234'
# MY_SQL_DB_NAME = 'cawm_rawdata'

#----------------------- Server and db details -----------------
MY_SQL_HOST_NAME = 'mysqldb.stg.chanceworldautomall.com'
MY_SQL_USER_NAME = 'vicibi'
MY_SQL_PASSWORD = 'vicibi!46'
MY_SQL_DB_NAME = 'cwam'
PORT=3307
CHARSET='utf8mb4'

#------------------------- Exchange rate url and token ------------------------
EXCHANGE_RATE_BASE_URL="free.currencyconverterapi.com"
EXCHANGE_RATE_TOKEN="d88955f4-c1db-d4ec-50bd-b9b8475752a8"

#-------------------------- SpotQuote API details -----------------------
QUOTE_API_BASE_URL="api.stg.chanceworldautomall.com"
QUOTE_API_ACCESS_TOKEN="Q1dBTUFjY2Vzc1Byb3ZpZGVy"
QUOTE_API_POSTMAN_TOKEN="07bdf7ca-7c6e-13c3-36d0-bf20bc198b24"

#------------------------ Table details ------------------------------
TABLE='history'
CATLOG_TABLE='catalogue_metadata'
TABLE_DISTINCT="quote_master"

#----------------------- Special countries slab rate -----------------------
MALTA_SLAB_RATE=70000
NEW_ZEALAND_SLAB_RATE=70000
CYPRUS_SLAB_RATE=180000

#------------------------ Standard Charges ------------------------
STANDARD_MISC_CHARGE=5000
STANDARD_MARGIN_PERCENTAGE=8
PRICE_DIFF=500000

#------------------------ CSV file strage details (used in storing and retriving history details) -------------------------
HISTORY_CSV_FILE="/history.csv"
# CSV_FOLDER_DIR="./"
CSV_FOLDER="bid/history_view/csv"


#-------------------------- Display tags for standards-------------
DISPLAY_TERMS=['bidPrice','auctionFee','inspectionfee','transportFee','forwordingVanning','LCCharge','oceanFreight','margin','misl_charge']

#-------------------------- tags for standards to be shown with charges-------------
DISPLAY_TERMS_SHOWMN=["bidPrice","auctionFee","oceanFreight"]

#-------------------------- tags for standards to hide charges-------------
DISPLAY_TERMS_HIDDEN=["transportFee","inspectionfee","forwordingVanning","LCCharge","margin","misl_charge"]

#-------------------------- Display tags -------------

DISPLAY_COUNTRY_TAG=        "Country            : "
DISPLAY_PORT_TAG=           "Port               : "
DISPLAY_VESSEL_TAG=         "Vessel             : "
DISPLAY_MAKE_TAG=           "Make               : "
DISPLAY_MODEL_TAG=          "Model              : "
DISPLAY_CHASSIS_TAG=        "Chassis ID         : "
DISPLAY_YEAR_TAG=           "Year               : "
DISPLAY_MILEAGE_TAG=        "Mileage            : "
DISPLAY_GRADR_TAG=          "Grade              : "
DISPLAY_COLOR_TAG=          "Color              : "

DISPLAY_DATA_COUNT_TAG=     "Data point count   : "

DISPLAY_AVG_TAG=            "Average Price      : "
DISPLAY_AUCTION_TAG=        "Auction Fee        : "
DISPLAY_FREIGHT_TAG=        "Ocean Freight      : "
DISPLAY_TRANSPORT_TAG=      "Transport Cost     : "
DISPLAY_INSPECTION_TAG=     "Inspection Fee     : "
DISPLAY_FORWORDVANNING_TAG= "Forwarding/Vanning : "
DISPLAY_LC_CHARGE_TAG=      "LC Charge          : "
DISPLAY_MARGIN_TAG=         "Margin             : "
DISPLAY_MISL_TAG=           "Miscellaneous Fee  : "
DISPLAY_SLAB_TAG=           "Slab Rate          : "

DISPLAY_FOB_TAG="FOB        : "
DISPLAY_CNF_TAG="C&F        : "
DISPLAY_CIF_TAG="CIF        : "


DISPLAY_TAG_DIC={"bidPrice":DISPLAY_AVG_TAG,"auctionFee":DISPLAY_AUCTION_TAG,"oceanFreight":DISPLAY_FREIGHT_TAG,"transportFee":DISPLAY_TRANSPORT_TAG,"inspectionfee":DISPLAY_INSPECTION_TAG,"forwordingVanning":DISPLAY_FORWORDVANNING_TAG,"LCCharge":DISPLAY_LC_CHARGE_TAG,"margin":DISPLAY_MARGIN_TAG,"misl_charge":DISPLAY_MISL_TAG}
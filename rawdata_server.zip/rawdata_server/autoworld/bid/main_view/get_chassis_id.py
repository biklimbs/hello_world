﻿import traceback
import sys
import pandas as pd
import numpy as np
import pymysql.cursors
# from logger_config import log
from termcolor import colored
sys.path.append('/usr/local/lib/python3.5/dist-packages')
from .constants import *
import time as t
import os, inspect
from .helper import *

# import logger_config
# from logger_config import *
#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


# MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
# MY_SQL_USER_NAME = 'root'
# MY_SQL_PASSWORD = 'Vmmobility@1234'
# MY_SQL_DB_NAME = 'cawm_rawdata'
# CATLOG_TABLE = 'catalogue_metadata'
# TABLE= 'history_cleaned'

MY_SQL_HOST_NAME = 'mysqldb.stg.chanceworldautomall.com'
MY_SQL_USER_NAME = 'vicibi'
MY_SQL_PASSWORD = 'vicibi!46'
MY_SQL_DB_NAME = 'cwam'
PORT=3307

# TABLE= 'history'


# To Check that the network is connected or not
def check_connection(host,user,password):
	connection_check = 0
	while (connection_check==0):
		try:
			connection_check = pymysql.connect(host=host,
		                             user=user,
		                             port=PORT,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(connection_check)
			#traceback.print_exc()
			t.sleep(5)

	return connection_check

# To check that the Database is there or not
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			cursor.execute(sql)
			db_check_result = cursor.fetchone()

			return db_check_result

	except:
		#traceback.print_stack()
		return None

# To connect the Database in mysql
def connect_to_db(host,user,password,db):
	connection_hadoop_internal=0
	while (connection_hadoop_internal==0):
		try:
			connection_hadoop_internal = pymysql.connect(host=host,
	                             	user=user,
	                             	port=PORT,
	                             	password=password,
	                             	db=db,
	                             	charset='utf8mb4',
	                             	cursorclass=pymysql.cursors.DictCursor)
		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(connection_hadoop_check)
			#traceback.print_exc()
			t.sleep(5)

	return connection_hadoop_internal

# To check that there TABLE exixts or not in Database
def check_if_TABLE_exits(connection_to_db,TABLE_):
	try:
		with connection_to_db.cursor() as cursor:
			sql_query = "desc "+TABLE_+";"
			cursor.execute(sql_query)
			TABLE_check_result = cursor.fetchone()
			#print(line_cleaning_TABLE_result)
			return True

	except:
		#traceback.print_stack()
		return False

# To retry again and again till network comes while executing the sql query
def network_call(sql,cursor):
	#response  = ""
	response_code = 0
	while response_code==0:
		try:
			cursor.execute(sql)
			response_code = cursor.fetchall()
			# print(response_code)
		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			# response_code = 0
			# print(response_code)
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			# traceback.print_exc()
			t.sleep(5)
			#traceback.print_stack()
	# sys.exit()
	return response_code


def fetch_chassis_id(MARKA_NAME, MODEL_NAME, from_year, to_year):
	empty_df=pd.DataFrame()
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	if(check_if_DB_exists(connection_check)==None):
		return empty_df,"Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		# log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		traceback.print_exc(limit=0,file=sys.stdout)

	if(check_if_TABLE_exits(connection_to_db,TABLE)!=True):
		
		return empty_df,"History_TABLE "+TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		MODEL_NAME="(\'"+MODEL_NAME+"\',\'"+str(MODEL_NAME.replace(" ",""))+"\')"
		print(MODEL_NAME)
		with connection_to_db.cursor() as cursor:
			sql="select KUZOV,ENG_V from "+TABLE+" where MARKA_NAME=\'"+MARKA_NAME+"\' and  MODEL_NAME in "+MODEL_NAME+" and AUCTION not like 'USS%' and AUCTION not like 'JU%' and FINISH != 0 and STATUS not in ('NOT SOLD','CANCELLED','Not Sold','') and YEAR between "+from_year+" and "+to_year+";"
			log.info (sql)
			
			data=network_call(sql,cursor)

			data_df= pd.DataFrame(data)
			
	except Exception as e:
		# log.error("Data not available")
		return empty_df, str(e)
		#traceback.print_exc()
	connection_to_db.close()
	return data_df, "Success"



def get_chassis(MARKA_NAME, MODEL_NAME, from_year, to_year):
	try:
		data_df , resp= fetch_chassis_id(MARKA_NAME, MODEL_NAME, from_year, to_year)
		# print(data_df)
		# sys.exit()
		if resp=="Success":
			if len(data_df["KUZOV"].unique())>1:
				popular= data_df["KUZOV"].value_counts().index[0]
				log.info(popular)
				chassis_id=[]
				chassis_id.append(popular)
				log.info(chassis_id)
				
				return chassis_id, "Success"
				
			else:
				chassis_id= data_df["KUZOV"].unique()
				chassis_id=list(chassis_id)
				log.info(chassis_id)
				
				return chassis_id, "Success"
				
			# print(data_df)
		else:
			chassis_id=[]
			log.info(str(chassis_id)+" "+ str(resp))
			# print(chassis_id, resp)
			return chassis_id, resp
	except Exception as e:
		log.error(str(e))
		# print(str(e))
		return [], "False"




# if __name__=="__main__":
# 	MARKA_NAME="TOYOTA"
# 	MODEL_NAME="AQUA"
# 	from_year="2008"
# 	to_year="2018"
# 	get_chassis(MARKA_NAME, MODEL_NAME, from_year, to_year)

from .helper import *
from .html_helper import *


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			cursor.execute(sql)
			db_check_result = cursor.fetchone()
			return db_check_result
	except Exception as e:
		log.error(str(e))
		#traceback.print_stack()
		return None
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as cursor:
			sql_query = "desc LOCATION_DATE_TABLE ;"
			cursor.execute(sql_query)
			table_check_result = cursor.fetchone()
			return True
	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_to_db=0
	while (connection_to_db==0):
		try:
			connection_to_db = pymysql.connect(host=host,
				user=user,
				port=3307,
				password=password,
				db=db,
				charset=CHARSET,
				cursorclass=pymysql.cursors.DictCursor)
		except Exception as e:
			log.error(e)
			t.sleep(30)
	return connection_to_db
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	check_connection = 0
	while (check_connection==0):
		try:
			check_connection = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset=CHARSET,
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)
	return check_connection

#-----------To get distinct Country from master table  ----------      
def get_country():
	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		with connection_to_db.cursor() as cursor:
			countries_res=''
			sql="select distinct code as code, name as country from country where portAvailable =1 order by name;"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			countries=response_code
			countries_res="<option value=COUNTRY selected='selected' >Country</option>"
			for country in countries:
				countries_res=countries_res+"<option value='"+str(country['code'])+"' >"+str(country['country'])+"</option>"
			return Markup(countries_res)
					# return response_code
	except Exception as e :
		log.error(e)
		return "[]"

#-----------To get port and port_code based on country code  ----------      
def get_port(cc):
	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		with connection_to_db.cursor() as cursor:
			countries_res=''
			sql="select name,code FROM cwam.port where countryCode=\""+cc+"\";"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			return response_code
	except Exception as e :
		log.error(e)
		return "[]"

#-----------To get vessel and vessel_code based on port code  ----------      
def get_vessel(pc):
        try:
        	connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
        	with connection_to_db.cursor() as cursor:
        		sql="select name,code FROM cwam.vessel where code in (select vesselCode FROM cwam.freight where portcode="+str(pc)+") order by name DESC;"
        		cursor.execute(sql)
        		response_code = cursor.fetchall()
        		return response_code
                        # return response_code
        except Exception as e :
                log.error(e)
                return "[]"

#-----------To get distinct make from history table based on basic conditions  ----------      
def get_marka_name():
	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		with connection_to_db.cursor() as cursor:
			countries_list=[]	
			sql="select distinct MARKA_NAME as marka FROM "+TABLE_DISTINCT+"  order by marka;"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			countries=sorted(list(pd.DataFrame(response_code)['marka']))
			for country in countries:
				countries_list.append(country)
			return countries_list
	except Exception as e :
		log.error(e)
		return "[]"

#-----------To get results based on parameters like make,model,year,mileage,rate,color  ----------      
def get_filter_params(search_dic,parameter):
	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		with connection_to_db.cursor() as cursor:
			# print("Hai")
			res=[]
			make=search_dic['company']
			model=search_dic['model']
			s_year=search_dic['s_year']
			e_year=search_dic['e_year']
			mileage=search_dic['mileage'] if('mileage' in search_dic)  else "MILEAGE"
			kuzov=search_dic['kuzov']
			# rate=search_dic['rate'] if 'rate' in search_dic else 'RATE'
			# color=search_dic['color']
			sql_where = "select distinct "+parameter+" FROM "+TABLE+" Where AUCTION not like 'USS%' and AUCTION not like 'JU%' and FINISH != 0 and STATUS='SOLD' and  "
			# sql = sql_empty
			if (make == "" and model == "" and mileage == "" and kuzov == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" and "

				if (model != "MODEL"):
					sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

				if (e_year != "YEAR"):
					sql = sql+"YEAR between "+s_year+" and "+e_year+" and "

				if (mileage != "MILEAGE"):
					mil_resp=mileage_converter(mileage," and ")
					sql = sql+"MILEAGE between "+mileage_converter(mileage," and ")+" and " if(mil_resp!="0 and 0") else sql
					
				if (kuzov != "KUZOV"):
					sql = sql+"KUZOV = \""+kuzov+"\""+" and "

				if ('rate' in search_dic):
					sql = sql+"RATE in ("+array_parram(search_dic,'rate')+") and " if(len(array_parram(search_dic,'rate'))>0) else sql

				if ('color' in search_dic):
					sql = sql+"COLOR in ("+array_parram(search_dic,'color')+") and " if(len(array_parram(search_dic,'color'))>0) else sql
				
			# log.info(str(sql[0:-4]))
			cursor.execute(str(sql[0:-4]))
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code)>0):
				params=sorted(list(pd.DataFrame(response_code)[parameter]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res=[]
	except Exception as e :
		log.error(e)
		return []

#-----------To get distinct results based on parameters model  ----------
def get_model_params(search_dic):
	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME, MY_SQL_USER_NAME, MY_SQL_PASSWORD, MY_SQL_DB_NAME)
		with connection_to_db.cursor() as cursor:
			# print("Hai")
			res = []
			make = search_dic['company']

			sql_where = "select distinct MODEL_NAME FROM "+TABLE_DISTINCT + " where "
			# sql = sql_empty
			if (make == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" and "

			# log.info(str(sql[0:-4]))
			cursor.execute(str(sql[0:-4]))
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code) > 0):
				params = sorted(list(pd.DataFrame(response_code)["MODEL_NAME"]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res = []
	except Exception as e:
		log.error(e)
		return []

#-----------To get distinct results based on parameters year  ----------
def get_year_params(search_dic):
	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME, MY_SQL_USER_NAME, MY_SQL_PASSWORD, MY_SQL_DB_NAME)
		with connection_to_db.cursor() as cursor:
			# print("Hai")
			res = []
			make = search_dic['company']
			model = search_dic['model']

			sql_where = "select distinct YEAR FROM "+TABLE_DISTINCT + " where "
			# sql = sql_empty
			if (make == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" and "
				
				if (model != "MODEL"):
					sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

			# log.info(str(sql[0:-4]))
			cursor.execute(str(sql[0:-4]))
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code) > 0):
				params = sorted(list(pd.DataFrame(response_code)["YEAR"]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res = []
	except Exception as e:
		log.error(e)
		return []

#-----------To get distinct results based on parameters chassis  ----------
def get_chassis_params(search_dic):
	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME, MY_SQL_USER_NAME, MY_SQL_PASSWORD, MY_SQL_DB_NAME)
		with connection_to_db.cursor() as cursor:
			# print("Hai")
			res = []
			make = search_dic['company']
			model = search_dic['model']
			start_year = search_dic['s_year']
			end_year = search_dic['e_year']

			sql_where = "select distinct KUZOV FROM "+TABLE_DISTINCT + " where "
			# sql = sql_empty
			if (make == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" and "

				if (model != "MODEL"):
					sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

				if (end_year != "YEAR"):
					sql = sql+"YEAR between "+start_year+" and "+end_year+" and "

			# log.info(str(sql[0:-4]))
			cursor.execute(str(sql[0:-4]))
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code) > 0):
				params = sorted(list(pd.DataFrame(response_code)["KUZOV"]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res = []
	except Exception as e:
		log.error(e)
		return []

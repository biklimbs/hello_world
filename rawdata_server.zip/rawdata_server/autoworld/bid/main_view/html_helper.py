from .helper import *
from .api_helper import *


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


#------------- only FOB shown here no c&f and cif for newzealand --------------------------------
def get_quote_newzealand(fob):
	return DISPLAY_FOB_TAG+str(str(fob)+" ¥‎ "+"  "+str(convert_dollar_yen(int(fob),get_exchange_rate('JPY_USD')))+" $ ")+" </br>"+DISPLAY_CNF_TAG+" - "+"</br>"+DISPLAY_CIF_TAG+" - "

#------------- only FOB shown here no c&f and cif for malta --------------------------------
def get_quote_malta(fob):
	return DISPLAY_FOB_TAG+str(str(fob)+" ¥‎ "+"  "+str(convert_dollar_yen(int(fob),get_exchange_rate('JPY_USD')))+" $ ")+" </br>"+DISPLAY_CNF_TAG+" - "+"</br>"+DISPLAY_CIF_TAG+" - "

#------------- only FOB shown here no c&f and cif for cyprus --------------------------------
def get_quote_cyprus(fob,cf,cif):
	return DISPLAY_FOB_TAG+" - "+" </br>"+DISPLAY_CNF_TAG+str(str(cf))+" ¥‎ "+"  "+str(str(convert_dollar_yen(int(cf),get_exchange_rate('JPY_USD')))+" $ ")+"</br>"+DISPLAY_CIF_TAG+str(str(cif))+" ¥‎ "+"  "+str(convert_dollar_yen(int(cif),get_exchange_rate('JPY_USD')))+" $ "

#------------- only FOB shown here --------------------------------
def get_quote(fob,cf,cif):
	return DISPLAY_FOB_TAG+str(str(fob)+" ¥‎ "+"  "+str(convert_dollar_yen(int(fob),get_exchange_rate('JPY_USD')))+" $ ")+" </br>"+DISPLAY_CNF_TAG+str(str(cf))+" ¥‎ "+"  "+str(str(convert_dollar_yen(int(cf),get_exchange_rate('JPY_USD')))+" $ ")+"</br>"+DISPLAY_CIF_TAG+str(str(cif))+" ¥‎ "+"  "+str(convert_dollar_yen(int(cif),get_exchange_rate('JPY_USD')))+" $ "

#------------- avg-price and other details shown here for newzealand --------------------------------
def get_avg_price_and_charges_standard_newzealand(result):
	res_tag=""
	for tag in DISPLAY_TERMS:
		if(tag!='oceanFreight'):
			if(tag in DISPLAY_TERMS_SHOWMN):
				res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
			elif(tag in DISPLAY_TERMS_HIDDEN):
				res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>Included"
		elif(tag=='oceanFreight'):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str('0')+" ¥‎"
	return res_tag+"</br>"

#------------- avg-price and other details shown here for malta --------------------------------
def get_avg_price_and_charges_standard_malta(result):
	res_tag=""
	for tag in DISPLAY_TERMS:
		if(tag!='oceanFreight'):
			if(tag in DISPLAY_TERMS_SHOWMN):
				res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
			elif(tag in DISPLAY_TERMS_HIDDEN):
				res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>Included"
		elif(tag=='oceanFreight'):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str('0')+" ¥‎"
	return res_tag+"</br>"

#------------- avg-price and other details shown here for cyprus --------------------------------
def get_avg_price_and_charges_standard_cyprus(result):
	res_tag=""
	for tag in DISPLAY_TERMS:
		if(tag in DISPLAY_TERMS_SHOWMN):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
		elif(tag in DISPLAY_TERMS_HIDDEN):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>Included"
	return res_tag+"</br>"

#------------- avg-price and other details shown here  --------------------------------
def get_avg_price_and_charges_standard(result):
	res_tag=""
	for tag in DISPLAY_TERMS:
		if(tag in DISPLAY_TERMS_SHOWMN):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
		elif(tag in DISPLAY_TERMS_HIDDEN):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>Included"
	return res_tag+"</br>"

#------------- avg-price and other details shown here for newzealand  --------------------------------
def get_avg_price_and_charges_custom_newzealand(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+DISPLAY_AVG_TAG+"</strong>"+str(str(avg_price)+" ¥‎ ")+"</br><strong>"+DISPLAY_SLAB_TAG+"</strong>"+str(slab_rate)+" ¥‎"+"</br><strong>"+DISPLAY_INSPECTION_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+DISPLAY_LC_CHARGE_TAG+"</strong>"+str(lc_charges)+" ¥‎"+"</br><strong>"+DISPLAY_FREIGHT_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+DISPLAY_MISL_TAG+"</strong>"+str(misc_charge)+" ¥‎ </br>"

#------------- avg-price and other details shown here for malta  --------------------------------
def get_avg_price_and_charges_custom_malta(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+DISPLAY_AVG_TAG+"</strong>"+str(str(avg_price)+" ¥‎ ")+"</br><strong>"+DISPLAY_SLAB_TAG+"</strong>"+str(slab_rate)+" ¥‎"+"</br><strong>"+DISPLAY_INSPECTION_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+DISPLAY_LC_CHARGE_TAG+"</strong>"+str(lc_charges)+" ¥‎"+"</br><strong>"+DISPLAY_FREIGHT_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+DISPLAY_MISL_TAG+"</strong>"+str(misc_charge)+" ¥‎ </br>"

#------------- avg-price and other details shown here for cyprus  --------------------------------
def get_avg_price_and_charges_custom_cyprus(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+DISPLAY_AVG_TAG+"</strong>"+str(str(avg_price)+" ¥‎ ")+"</br><strong>"+DISPLAY_SLAB_TAG+"</strong>"+str(slab_rate)+" ¥‎"+"</br><strong>"+DISPLAY_INSPECTION_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+DISPLAY_LC_CHARGE_TAG+"</strong>"+str(lc_charges)+" ¥‎"+"</br><strong>"+DISPLAY_FREIGHT_TAG+"</strong>"+str(freight_charge)+" ¥‎"+"</br><strong>"+DISPLAY_MISL_TAG+"</strong>"+str(misc_charge)+" ¥‎ </br>"	

#------------- avg-price and other details shown here   --------------------------------
def get_avg_price_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+DISPLAY_AVG_TAG+"</strong>"+str(str(avg_price)+" ¥‎ ")+"</br><strong>"+DISPLAY_SLAB_TAG+"</strong>"+str(slab_rate)+" ¥‎"+"</br><strong>"+DISPLAY_INSPECTION_TAG+"</strong>"+str(inspection_fee)+" ¥‎"+"</br><strong>"+DISPLAY_LC_CHARGE_TAG+"</strong>"+str(lc_charges)+" ¥‎"+"</br><strong>"+DISPLAY_FREIGHT_TAG+"</strong>"+str(freight_charge)+" ¥‎"+"</br><strong>"+DISPLAY_MISL_TAG+"</strong>"+str(misc_charge)+" ¥‎ </br>"	

#-----------To set HTML format for user selection   ----------    
def form_quote_html(country,port,vessel,Company,Model,s_year,e_year,Kuzov,Mileage,Rate,Color):
	return "<p style='font-size:13px;'><strong>"+DISPLAY_COUNTRY_TAG+"</strong>"+str(country)+"</br><strong>"+DISPLAY_PORT_TAG+"</strong>"+str(port)+"</br><strong>"+DISPLAY_VESSEL_TAG+"</strong>"+str(vessel)+"</br><strong>"+DISPLAY_MAKE_TAG+"</strong>"+str(Company)+"</br><strong>"+DISPLAY_MODEL_TAG+"</strong>"+str(Model)+"</br><strong>"+DISPLAY_CHASSIS_TAG+"</strong>"+str(Kuzov)+"</br><strong>"+DISPLAY_YEAR_TAG+"</strong>"+str(s_year)+"-"+str(e_year)+"</br><strong>"+DISPLAY_MILEAGE_TAG+"</strong>"+str(Mileage)+"</br><strong>"+DISPLAY_GRADR_TAG+"</strong>"+str(Rate)+"</br><strong>"+DISPLAY_COLOR_TAG+"</strong>"+str(Color)

#-----------To set HTML format for data_point   ----------    
def form_data_points(data_count):
	return "</br><strong>"+DISPLAY_DATA_COUNT_TAG+"</strong>"+str(data_count)

#-----------To set HTML format to display entire resultant data   ----------    
def get_display_quote(selection_prices,result_html):
	return Markup("<p><font size='3' color='red'>Selection Criterion </font></p><pre>"+selection_prices+"</br><strong><font size='3' color='green'>"+str(result_html)+"</font></strong></p></pre> ")		


#-----------To Create basic html tag for selection list  ----------    
def basic_tags_params(param):
	return Markup("<option value='"+param+"' selected='selected' >"+param.capitalize()+"</option>")

def get_user_selection_custom(country_name,port_name,vessel_name,select_,mileage_,rate_,color_):
	return "<p style='font-size:13px;'><strong>"+DISPLAY_COUNTRY_TAG+"</strong>"+str(country_name)+"</br><strong>"+DISPLAY_PORT_TAG+"</strong>"+str(port_name)+"</br><strong>"+DISPLAY_VESSEL_TAG+"</strong>"+str(vessel_name)+"</br><strong>"+DISPLAY_MAKE_TAG+"</strong>"+str(select_['company'])+"</br><strong>"+DISPLAY_MODEL_TAG+"</strong>"+str(select_['model'])+"</br><strong>"+DISPLAY_CHASSIS_TAG+"</strong>"+str(select_['kuzov'])+"</br><strong>"+DISPLAY_YEAR_TAG+"</strong>"+str(select_['s_year'])+"-"+str(select_['e_year'])+"</br><strong>"+DISPLAY_MILEAGE_TAG+"</strong>"+mileage_+"</br><strong>"+DISPLAY_GRADR_TAG+"</strong>"+str(rate_)+"</br><strong>"+DISPLAY_COLOR_TAG+"</strong>"+str(color_)

#-----------To set HTML format for avg-price and other details   ----------  
def form_fee_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge,country):
	try:
		if(country=="New Zealand"):
			return get_avg_price_and_charges_custom_newzealand(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
		elif(country=="Malta"):
			return get_avg_price_and_charges_custom_malta(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
		elif(country=="Cyprus"):
			return get_avg_price_and_charges_custom_cyprus(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
		else:
			return get_avg_price_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
	except Exception as e:
		log.error(str(e))

#-----------To set HTML format for avg-price and other details   ----------    
def form_fee_and_charges_standard(result,country):
	try:
		log.info(str(result))
		if(country=="New Zealand" ):
			return get_avg_price_and_charges_standard_newzealand(result)
		elif(country=="Malta"):
			return get_avg_price_and_charges_standard_malta(result)
		elif(country=="Cyprus"):
			return get_avg_price_and_charges_standard_cyprus(result)
		else:
			return get_avg_price_and_charges_standard(result)
	except Exception as e:
		log.error(str(e))

#-----------To set HTML format for quote   ----------      		
def form_result_html(fob,cf,cif,country):
	try:
		if(country=="New Zealand"):
			return get_quote_newzealand(fob)
		elif(country=="Malta"):
			return get_quote_malta(fob)
		elif(country=="Cyprus"):
			return get_quote_cyprus(fob,cf,cif)
		else:
			return get_quote(fob,cf,cif)
	except Exception as e:
		log.error(str(e))
	

# def display_tag(result):
# 	res_tag=""
# 	for tag in DISPLAY_TERMS:
# 		if(tag in DISPLAY_TERMS_SHOWMN):
# 			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
# 		elif(tag in DISPLAY_TERMS_HIDDEN):
# 			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>Included"
# 	return res_tag+"</br>"
	
#-----------To set visible for prices in HTML for al prices   (Not using, if want to display all charges we can use this definition) ----------      		
def display_tag_with_price(result):
	res_tag=""
	for tag in DISPLAY_TERMS:
		if(tag in result['Records']):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
		elif(tag=="margin"):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(get_margin_search_results(int(result['Records']['bidPrice'])))+" ¥‎"
		elif(tag=="misl_charge"):
			res_tag=res_tag+"</br><strong>"+DISPLAY_TAG_DIC[tag]+"</strong>"+str(get_standard_misl_charge())+" ¥‎"+"</br>"
	return res_tag

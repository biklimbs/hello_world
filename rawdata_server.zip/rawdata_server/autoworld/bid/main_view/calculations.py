from .constants import *
from .calculations_spe import *
from datetime import datetime, time
import csv
from .logger_config import *
import bid.main_view.logger_config as logger_config


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#-----------To change dollar to yen formate value is in $ and rate is value/yen   ----------
def convert_dollar_yen(vaule, rate):
    try:
	    return int(vaule*rate)
    except Exception as e:
        log.error(str(e))

#-----------To get standard misl charge ----------
def get_standard_misl_charge():
	return STANDARD_MISC_CHARGE

#-----------To calculate fob for standard ----------
def get_fob_standard(avg_price, auction_fee, trasport_charge,forward_fee, inspection_fee, lc_charges, misc_charge, margin):
    try:
        fob = avg_price+auction_fee + trasport_charge + forward_fee + inspection_fee + lc_charges + misc_charge + margin
        return fob  
    except Exception as e:
        log.error(str(e))

#-----------To calculate c&f for standard ----------
def get_cnf_standard(fob, freight_charge):
    try:
        cnf = fob+freight_charge
        return cnf
    except Exception as e:
        log.error(str(e))

#-----------To calculate cif for standard ----------
def get_cif_standard(fob, freight_charge):
    try:
        cif = fob+freight_charge
        return cif
    except Exception as e:
        log.error(str(e))

#-----------To calculate fob for custom ----------
def get_fob_custom(avg_price,slab_rate,lc_charges,inspection_fee,misc_charge):
    try:
        fob = int(avg_price)+int(slab_rate)+int(lc_charges) + int(inspection_fee)+int(misc_charge)
        return fob
    except Exception as e:
        log.error(str(e))

#-----------To calculate c&f for standard ----------
def get_cnf_custom(fob, freight_charge):
    try:
        cnf = fob+ int(freight_charge)
        return cnf
    except Exception as e:
        log.error(str(e))

#-----------To calculate cif for standard ----------
def get_cif_custom(fob, freight_charge):
    try:
        cif = fob+int(freight_charge)
        return cif
    except Exception as e:
        log.error(str(e))


#-----------To get the margin for standard quote   ----------
def get_margin_search_results(avg_price):
    try:
        margin = int(avg_price/100)*STANDARD_MARGIN_PERCENTAGE
        return margin
    except Exception as e:
        log.error(str(e))

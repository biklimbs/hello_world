from .helper import *
from .constants import *

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")



#-----------To get exchange rate by doing rest_api call   ----------    
def get_exchange_rate(mode):
	try:
		conn = http.client.HTTPConnection(EXCHANGE_RATE_BASE_URL)
		headers = {'cache-control': "no-cache",'postman-token': EXCHANGE_RATE_TOKEN}
		conn.request("GET", "/api/v5/convert?q="+mode, headers=headers)
		res = conn.getresponse()
		data = res.read().decode("utf-8")
		return float(json.loads(data)['results'][mode]['val'])
	except Exception as e:
		return " "
		log.error(str(e))
		print(e)


#-----------REST API call to get fob_cf_cif based on selection  ----------      
def call_quote_api(country,port,vessel,company,model,s_year,e_year,mileage,kuzov,rate,color):
	try:
		conn = http.client.HTTPSConnection(QUOTE_API_BASE_URL)
		res=""
		while (res == ""):
			try:
				payload = "{\r\n\"company\": \""+company+"\",\r\n\"model\": \""+model+"\",\r\n\"s_year\": \""+s_year+"\",\r\n\"e_year\": \""+e_year+"\",\r\n\"mileage\": \""+mileage+"\",\r\n\"color\": "+str(color).replace("'","\"")+" ,\r\n\"kuzov\": \""+kuzov+"\",\r\n\"rate\": "+str(rate).replace("'","\"")+",\r\n\"countryCode\":\""+country+"\",\r\n\"portCode\":\""+port+"\",\r\n\"vessleCode\":\""+vessel+"\"\r\n}"
				headers = {'appname': "CWAM_AP",'accesstoken': QUOTE_API_ACCESS_TOKEN,'accept': "application/json",'content-type': "application/json",'cache-control': "no-cache",'postman-token': QUOTE_API_POSTMAN_TOKEN}
				conn.request("POST", "/cwam/api/spotqoute", payload, headers)
				res = conn.getresponse()
				data = res.read()
				# return data.decode("utf-8")
			except Exception as e:
				log.error("API CALL TIME OUT"+str(e))
		return payload,json.loads(data.decode("utf-8"))
	except Exception as e:
		log.error(str(e))
		return {}
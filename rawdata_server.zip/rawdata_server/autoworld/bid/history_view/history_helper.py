from bid.main_view.sql_helper import *    


def save_to_history_csv(payload,quote,change):
	try:
		now = datetime.now()
		with open(CSV_FOLDER+"/"+HISTORY_CSV_FILE,'a') as fd:
					csv.writer(fd).writerow([str(now.strftime("%Y-%m-%d %H:%M")),payload,quote,change])
		return True
	except Exception as e:
		log.error(str(e))
		return False
	# return " "
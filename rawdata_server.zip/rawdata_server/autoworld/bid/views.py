from django.shortcuts import render
from flask import Flask,  request,Response,redirect,url_for,Markup,jsonify
import requests


from bid.main_view.helper import *
from bid.main_view.sql_helper import * 
from bid.main_view.quote import * 
from django.http import HttpResponse,JsonResponse

# Create your views here.


def index(request):
    """
    View function for home page of site.
    """
    # Number of visits to this view, as counted in the session variable.
    num_visits=request.session.get('num_visits', 0)
    request.session['num_visits'] = num_visits+1
    
    # Render the HTML template index.html with the data in the context variable.
    return render(
        request,
        'index.html',
        context={"currency":str(round(get_exchange_rate('USD_JPY'),2)),
        "country":get_country(),"port_tags":basic_tags_params("PORT"),
        "vessel_tags":basic_tags_params("VESSEL"),
        "make_tag":basic_tags_params("MARK"),
        "model_tags":basic_tags_params("MODEL"),
        "kuzov_tags":Markup("<option value='KUZOV' selected='selected' >Chassis ID</option>"),
        "mileage_tags":basic_tags_params("MILEAGE"),
        "year_tags":basic_tags_params("YEAR"),
        "rate_tags":Markup("<option value='RATE'  >Grade</option>"),
        "color_tags":basic_tags_params("COLOR"),
        "result":Markup("<p  align='center'>  Select Search Criterion </p>"),
        "history":set_history()},
    )

def port(request):
    if request.method == 'POST':
        return JsonResponse(get_port(str(request.POST['country'])),safe=False)

def mark(request):
    if request.method == 'POST':
        return JsonResponse(get_marka_name(),safe=False)

def vessel(request):
    if request.method == 'POST':
        return JsonResponse(get_vessel(str(request.POST['port'])),safe=False)

def model(request):
    if request.method == 'POST':
        return JsonResponse(get_model_params(request.POST),safe=False)

def year(request):
    if request.method == 'POST':
        return JsonResponse(get_year_params(request.POST),safe=False)

def chasisid(request):
    if request.method == 'POST':
        dic=request.POST
        if(str(dic['chas_check'])=="false"):
            return JsonResponse(get_chassis_params(dic),safe=False)
        else:
            res_,status=get_chassis(str(dic['company']), str(dic['model']), str(dic['s_year']), str(dic['e_year']))
            if(status=="Success"):
                return JsonResponse(res_,safe=False)
            else:
                return JsonResponse([],safe=False)

def rate(request):
    if request.method == 'POST':
        return JsonResponse(get_filter_params(request.POST,'RATE'),safe=False)

def color(request):
    if request.method == 'POST':
        return JsonResponse(get_filter_params(request.POST,'COLOR'),safe=False)

def standard_quote_(request):
    if request.method == 'POST':
        try:
            search_dic=request.POST
            resultant_array=standard_quote(search_dic)
            return JsonResponse(resultant_array,safe=False)
        except Exception as e:
            print(e)
            return  str(e)

def customize(request):
    if request.method == 'POST':
        return JsonResponse(display_custom_options(request.POST),safe=False)

def custom_quote_(request):
    if request.method == 'POST':
        try:
            search_dic=request.POST
            resultant_array=custom_quote(search_dic)
            return JsonResponse(resultant_array,safe=False)
        except Exception as e:
            print(e)
            log.error(e)
            traceback.print_stack()
            return  str(e)


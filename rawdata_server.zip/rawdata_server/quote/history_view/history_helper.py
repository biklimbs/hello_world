# Description: history_helper deals with saving the record of request made in standard and customization.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:

from constants import *
from datetime import datetime, time
from logger_config import *
import logger_config
import csv

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		To save search data history to csv file
def save_to_history_csv(payload,quote,change):
	try:
		now = datetime.now()
		with open(CSV_FOLDER+"/"+HISTORY_CSV_FILE,'a') as fd:
			csv.writer(fd).writerow([str(now.strftime("%Y-%m-%d %H:%M")),payload,quote,change])
		return True
	except Exception as e:
		log.error(str(e))
		return False
	# return " "
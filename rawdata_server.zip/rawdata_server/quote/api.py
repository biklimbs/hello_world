import requests
import sys
import flask
#sys.path.append('/usr/local/lib/python3.5/dist-packages')
sys.path.append('/usr/local/lib/python3.6/dist-packages')
import requests
import os
import traceback

#		Deployment path(Enable when project go to deployment/Disable when running local system level) 
# sys.path.append('./src/front_end/V-4.0/main_view/')
#		Local path(Enable when running local system level/Disable when project go to deployment) 
sys.path.append('./main_view/')


from logger_config import *
import logger_config

#---Global variable---
avg_price=""

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


try:
	try:
		from main_view.helper import *
	except:
		print("helper")
	try:
		from main_view.api_helper import *
	except:
		print("api helper")
	try:
		from main_view.sql_helper import *
	except:
		print("sql helper")
	try:
		from main_view.quote import *
	except:
		print("quote")
		traceback.print_exc()
	try:
		from update.update_query import *
	except:
		print("update query")
	try:
		from pdf.pdf_generator import *
	except:
		print("pdf_generator")
		traceback.print_exc()
	try:
		from mail.send_mail import *
	except:
		print("send_mail")
	try:
		from recommendations.recommendations_query import *
	except:
		print("recommendations")
	#from flask import jsonify
except Exception as e:
	log.error("sys.path.append('./main_view/') is not defined")



#		Flask tasks starts from here
app = Flask(__name__,static_url_path='/static')

#		Page loads on lanch of application  		    
@app.route("/", methods = ["GET",'POST'])
def index():
	try:
		global EXCHANGE_RATE
		EXCHANGE_RATE=get_exchange_rate('USD')
		# print(EXCHANGE_RATE)
		file_name=get_file_name(" ")
		try:
			country=get_country()
			history=set_history()
		except:
			country="india"
			history=""
			print("error")
		currency=str(round(EXCHANGE_RATE,2))
		port_tags,vessel_tags,make_tag,model_tags,kuzov_tags,mileage_tags,year_tags,rate_tags,color_tags,result,vehicle_grade_tags=on_page_load()
		return render_template("index.html",filefpdfname=file_name,currency=currency,country=country,port_tags=port_tags,vessel_tags=vessel_tags,make_tag=make_tag,model_tags=model_tags,kuzov_tags=kuzov_tags,mileage_tags=mileage_tags,year_tags=year_tags,rate_tags=rate_tags,color_tags=color_tags,result=result,history=history,vehicle_grade_tags=vehicle_grade_tags)
	except Exception as e:
		log.error(e)

		return 'something went wrong : '+str(e)

#		Calls when change happens in country dropdown in "search" tab
@app.route('/port', methods=["POST"])
def get_port_in_search():
	try:
		country=str(request.form['country'])
		port=get_port(country)
		return jsonify(port)
	except Exception as e:
		log.error(str(e))

#		Calls when change happens in port dropdown in "search" tab
@app.route('/vessel', methods=["POST"])
def get_vessel_in_search():
	try:
		port=str(request.form['port'])
		vessel=get_vessel(port,"true")
		return jsonify(vessel)	
	except Exception as e:
		log.error(str(e))

#		marka : Manufacturer of the vehicle
#		Calls on lanching of page in "search" tab
@app.route('/marka', methods=["POST"])
def get_marka_in_search():
	try:
		marka=get_marka_name()
		return jsonify(marka)	
	except Exception as e:
		log.error(str(e))

#		Calls when change happens in make dropdown in "search" tab
@app.route('/model', methods=["POST"])
def get_model_in_search():
	try:
		model=get_model_params(request.form)
		return jsonify(model)	
	except Exception as e:
		log.error(str(e))

#		Calls when change happens in model dropdown in "search" tab
@app.route('/year', methods=["POST"])
def get_year_in_search():
	try:
		year=get_year_params(request.form)
		return jsonify(year)
	except Exception as e:
		log.error(str(e))

#		Calls when change happens in selection of year range in "search" tab    
@app.route('/kuzov', methods=["POST"])
def get_kuzov_in_search():
	try:
		kuzov=get_chassis_params(request.form)
		return jsonify(kuzov)
	except Exception as e:
		log.error(str(e))

#		Calls to get vehicle grade details based on filtered Criterion in "search" tab    
@app.route("/vehicle_grade",methods=["POST"])
def get_vehiclegrade_in_search():
	try:
		vehicle_grade=get_vehicle_grade(request.form)
		return jsonify(vehicle_grade)
	except Exception as e:
		log.error(str(e))

#		Calls to get engine cc details based on filtered Criterion in "search" tab
@app.route("/eng_cc",methods=["POST"])
def get_eng_cc_in_search():
	try:
		eng_cc=get_engine_cc(request.form)
		return jsonify(eng_cc)
	except Exception as e:
		log.error(str(e))
#		Calls when clicks on Set(Button) in "search" tab
@app.route('/rate', methods=["POST"])
def get_rate_in_search():
	try:
		rate=get_filter_params(request.form,'RATE')
		return jsonify(rate)	
	except Exception as e:
		log.error(str(e))
		
#		Calls when choosing rates in "search" tab
@app.route('/color', methods=["POST"])
def get_color_in_search():
	try:
		color=get_filter_params(request.form,'COLOR')
		return jsonify(color)	
	except Exception as e:
		log.error(str(e))

#		Calls on selection of Customize checkbox in "search" tab		    
@app.route("/customize", methods = ["POST"])
def get_bid_price():
	try:
		customize=display_custom_options(request.form)
		return jsonify(customize)
	except Exception as e:
		log.error(str(e))

#		Calls to get standard quote based on user selection in "search" tab	    
@app.route("/standard_quote", methods = ['POST'])
def get_standard_quote():
	try:
		global avg_price
		# print(EXCHANGE_RATE)
		search_dic=request.form
		# print(EXCHANGE_RATE)
		avg_price,resultant_array=standard_quote(search_dic,float(EXCHANGE_RATE))
		print("avg price: "+str(avg_price))
		#result_str=json.dumps(resultant_array.get_json())
		#print("the returned :"+result_str)
		#print(json.loads(result_str)["bidPrice"])
		return resultant_array
	except Exception as e:
		print(e)
		log.error(e)
		traceback.print_stack()
		return  str(e)

#		Calls to get recommendations based on user selection in "search" tab	    
@app.route("/recommendations", methods = ['POST'])
def get_recommendation():
	try:
		# print(EXCHANGE_RATE)
		search_dic=request.form
		resultant_array=recommendation_quote(search_dic,float(EXCHANGE_RATE),avg_price)
		return resultant_array
	except Exception as e:
		print(e)
		log.error(e)
		traceback.print_stack()
		return  str(e)


#		Calls to get custom quote based on charges available in "search" tab
@app.route("/custom_quote", methods = ['POST'])
def get_custom_quote():
	try:
		search_dic=request.form
		# print(EXCHANGE_RATE)
		resultant_array=custom_quote(search_dic,float(EXCHANGE_RATE))		
		return resultant_array
	except Exception as e:
		print(e)
		log.error(e)
		traceback.print_stack()
		return  str(e)

#		Calls when user wants to update freight data for a port in "update" tab
@app.route('/port_update', methods=[ "POST"])
def get_port_update():
	try:
		country=str(request.form['country_update'])
		port=get_port(country)
		return jsonify(port)
	except Exception as e:
		log.error(str(e))

#		Calls when user wants to update freight data for a vessel in "update" tab  
@app.route('/vessel_update', methods=[ "POST"])
def get_vessel_update():
	try:
		port=str(request.form['port_update'])
		update_status=request.form['update_new']
		vessel=get_vessel(port,update_status)
		return jsonify(vessel)
	except Exception as e:
		log.error(str(e))

#		Calls to get exixting freight data based on port and vessel in "update" tab    
@app.route('/get_freight_data', methods=[ "POST"])
def get_freight_data():
	try:
		port=str(request.form['port_update'])
		vessel=str(request.form['vessel_update'])
		freight_charges=get_freight_charge(port,vessel)
		return jsonify(freight_charges)	
	except Exception as e:
		log.error(str(e))

#		Calls to update freight details based on port and vessel in "update" tab
@app.route('/update_freight_data', methods=[ "POST"])
def update_freight_data():
	try:
		update_freight=update_freight_details(request.form)
		return jsonify(update_freight)
	except Exception as e:
		log.error(str(e))


#		Calls to generate .PDF based on form data in "send mail" dialog
@app.route("/pdf_generator",methods=["POST"]) 
def generate_pdf():
	try:
		invoice_receipt,invoice_date,invoice_no,invoice_item_no,make,model,grade,year_month,chassis,color,trans,eng_cc,drive,total,total_units,invoice_remarks,to_invoice_contact,invoice_currency,port_name=get_parse_data_pdf(request)
		status,file_name=pdf_generator(invoice_receipt,invoice_date,invoice_no,invoice_item_no,make,model,grade,year_month,chassis,color,trans,eng_cc,drive,total,total_units,invoice_remarks,to_invoice_contact,invoice_currency,port_name,EXCHANGE_RATE)
		if(status):
			t.sleep(4)
			return file_name
		else:
			return "False"
	except Exception as e:
		log.error(str(e))
		return "False"

#		Calls to send email with attachment in "send mail" dialog
@app.route("/send_mail",methods=["POST"])
def send_mail_with_attachment():
	try:
		from_address,from_password,to_address,mail_subject,mail_body,pdf_path,invoice_receipt,country_name=on_sending_mail(request)
		status,msg=send_mail(from_address,from_password,to_address,mail_subject,mail_body,pdf_path,invoice_receipt,country_name)
		if(status):
			result=[]
			result.append("True")
			result.append(msg)
			return jsonify(result)
		else:
			result=[]
			result.append("False")
			result.append(msg)
			return jsonify(result)
		# return "True"
	except Exception as e:
		log.error(str(e))
		return "False"


#		Declaration of flask port
if __name__ == "__main__":
	app.run(host='0.0.0.0' ,port=86)

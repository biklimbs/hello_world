# Description: helper deals with rearranging content to customize/readable way.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:



import sys, os
sys.path.append(os.path.abspath(os.path.join('..')))

from datetime import datetime, time
import csv
from flask import Flask, render_template, request,Response,redirect,url_for,Markup,jsonify


import json
from logger_config import *
import logger_config
import os, inspect
import traceback
import pymysql.cursors
import time as t
import pandas as pd


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


#		To make a list of parameters which are having more than one value in dic helps for color and rate(multiple select)        
def array_parram(dic,param):
	choices=""
	try:
		for key in dic.keys():
			for value in dic.getlist(key):
				if(key==param):
					if(str(value).strip()!='' and str(value).strip()!=str(param).upper()):
						choices=choices+",\""+value+"\""
					else:
						choices=choices
		# print(str(choices[1:]))
		return str(choices[1:])
	except Exception as e:
		log.error(str(e))

#		To convert string to array by spliting string with " , "        	
def convert_to_array(string):
	try:
		res=[]
		if len(string)>0:
			for each in string.split(","):
				res.append(str(each)[1:-1])
		else:
			pass
		return str(json.dumps(res))
	except Exception as e:
		log.error(str(e))

#		To validate parameters they are same or not helps in passing paylod        
def validate_parameter(param,term):
	try:
		if(param!='' and param!=term.upper()):
			return param
		else:
			if(param=='S_YEAR' or param=='E_YEAR'):
				return '0'
			else:
				return ""
	except Exception as e:
		log.error(str(e))

#		To change mileage format from 'k' to '000'(numerical)        
def mileage_converter(mil_str,div):
	try:
		res=""
		mil_str=mil_str.split("-")
		if(int(str(mil_str[0]).split('k')[0])>0):
			res=res+str(str(mil_str[0]).split('k')[0])+"000"
		else:
			res=res+"0"
		if(int(str(mil_str[1]).split('k')[0])>0):
			res=res+div+str(str(mil_str[1]).split('k')[0])+"000"
		else:
			res=res+div+"0"
		return res
	except Exception as e:
		log.error(str(e))
	

#		To Create a folder if not present in path     
def check_folder_and_create(dir_path,folder_path):
	if not os.path.isdir(dir_path+folder_path):
		os.system('mkdir '+folder_path+'')


#		------- Remove comma from string and returns integer formate   		
def remove_comma_return_int(string):
	try:
		return int(float(string.replace(",","")))
	except Exception as e:
		log.error(str(e))
		return " "

#		------- To get parse data and return to create PDF file  		
def get_parse_data_pdf(request):
	invoice_receipt=str(request.form['to_invoice'])
	invoice_date=str(request.form['date_invoice'])
	invoice_no=str(request.form['invoice_no'])
	invoice_item_no=str(request.form['sr_no'])
	make=str(request.form['invoice_make'])
	model=str(request.form['invoice_model'])
	grade=str(request.form['invoice_grade'])
	year_month=str(request.form['invoice_y_n'])
	chassis=str(request.form['invoice_chassis'])
	color=str(request.form['invoice_chassis'])
	trans=str(request.form['invoice_trans'])
	eng_cc=str(request.form['invoice_cc'])
	drive=str(request.form['invoice_drive'])
	total=str(request.form['invoice_total'])
	total_units=str(request.form['invoice_total_units'])
	invoice_remarks=str(request.form['invoice_remarks'])
	to_invoice_contact=str(request.form['to_invoice_contact'])
	invoice_currency=str(request.form['invoice_currency'])
	port_name=str(request.form['port_name'])

	return invoice_receipt,invoice_date,invoice_no,invoice_item_no,make,model,grade,year_month,chassis,color,trans,eng_cc,drive,total,total_units,invoice_remarks,to_invoice_contact,invoice_currency,port_name



#		------- To get parse data and return to send mail  		
def on_sending_mail(request):
	from_address=str(request.form['from_add'])
	from_password=str(request.form['from_pass'])
	to_address=str(request.form['to_add'])
	mail_subject=str(request.form['mail_subject'])
	mail_body=str(request.form['mail_body'])
	pdf_path=str(request.form['pdf_path'])
	invoice_receipt=str(request.form["to_invoice"])
	country_name=str(request.form["country_name"])

	return from_address,from_password,to_address,mail_subject,mail_body,pdf_path,invoice_receipt,country_name
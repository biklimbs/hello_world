# Description: sql_helper deals with getting data from server database based on query we have passed.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:


#		Query to get charges based on vessel_code,chassis id,port_code,country_code 

# SELECT v.cost as vesselRate,c.cbm,F.cost,F.unit,ER.keyValue as exchangeRate,AUCFee.keyValue as auctionFee,
# TPCost.keyValue as transportCost,Infee.charge as inspectionFee,lcfee.charge as lcFee  from 
# (SELECT cost FROM vessel where code=1) AS v,
# (SELECT IFNULL(cbm, 0)as cbm FROM carDetails where kuzosCode='NG11') AS c,
# (SELECT cost,unit FROM freight where portCode=6 and vesselCode=1 ) AS F,
# (SELECT keyValue FROM constant where code='AUCTION_FEE') AS AUCFee,
# (SELECT keyValue FROM constant where code='TRANSPORT_COST') AS TPCost,
# (select IFNULL(charge, 0)as charge from inspection where countrycode='ARU') as Infee,
# (select IFNULL(charge, 0)as charge from lc where countrycode='ARU') as lcfee
try:
	from helper import *
	from constants import *
except Exception as e:
	print(str(e))
	
#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		Checking Database available or not  		             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+DB_NAME+"';"
			cursor.execute(sql)
			db_check_result = cursor.fetchone()
			return db_check_result
	except Exception as e:
		log.error(str(e))
		#traceback.print_stack()
		return None
    
#		Checking table available or not  		             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as cursor:
			sql_query = "desc LOCATION_DATE_TABLE ;"
			cursor.execute(sql_query)
			table_check_result = cursor.fetchone()
			return True
	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#		Connecting to database server 		    
def connect_to_db(host,user,password,db):
	connection_to_db=0
	while (connection_to_db==0):
		try:
			connection_to_db = pymysql.connect(host=host,
				user=user,
				port=3307,
				password=password,
				db=db,
				charset=CHARSET,
				cursorclass=pymysql.cursors.DictCursor)
		except Exception as e:
			log.error(e)
			t.sleep(30)
	return connection_to_db
    
#		Checking connection established or not  		                 
def check_connection(host,user,password):
	check_connection = 0
	while (check_connection==0):
		try:
			check_connection = pymysql.connect(host=host,
			user=user,
			password=password,
			charset=CHARSET,
			cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)
	return check_connection

#		To get distinct Country from master table  		      
def get_country():
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			countries_res=''
			sql="select distinct code as code, name as country from "+COUNTRY_TABLE+" where portAvailable =1 order by name;"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			countries=response_code
			countries_res="<option value=COUNTRY selected='selected' >Country</option>"
			for country in countries:
				countries_res=countries_res+"<option value='"+str(country['code'])+"' >"+str(country['country'])+"</option>"
			return Markup(countries_res)
					# return response_code
	except Exception as e :
		log.error(e)
		return "[]"

#		To get port and port_code based on country code  		      
def get_port(cc):
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			sql="select name,code FROM "+PORT_TABLE+" where countryCode=\""+cc+"\";"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			return response_code
	except Exception as e :
		log.error(e)
		return "[]"

#		To get vessel and vessel_code based on port code  		      
def get_vessel(port_code,update_or_new):
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			# print(update_or_new)
			if(str(update_or_new)=="true"):
				sql="select name,code FROM "+VESSEL_TABLE+" where code in (select vesselCode FROM cwam.freight where portcode="+str(port_code)+") order by name DESC;"
			else:
				sql="select name,code FROM "+VESSEL_TABLE+" where code not in (select vesselCode FROM cwam.freight where portcode="+str(port_code)+") order by name DESC;"			
			# print(sql)
			cursor.execute(sql)
			response_code = cursor.fetchall()
			return response_code
					# return response_code
	except Exception as e :
			log.error(e)
			return "[]"

#		To get vessel and vessel_code based on port code  		      
def get_freight_charge(port_code,vessel_code):
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			sql="SELECT * FROM "+FREIGHT_TABLE+" where portCode="+str(port_code)+" and vesselCode="+str(vessel_code)+";"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			print(response_code)
			return response_code
	except Exception as e :
			log.error(e)
			return "[]"

#		To get distinct make from history table based on basic conditions  		      
def get_marka_name():
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			countries_list=[]	
			sql="select MARKA_NAME as marka,count(*) FROM "+MAKE_MODEL_TABLE+"  group by marka order by count(*) desc limit 15"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			countries=sorted(list(pd.DataFrame(response_code)['marka']))
			for country in countries:
				countries_list.append(country)
			return countries_list
	except Exception as e :
		log.error(e)
		return "[]"

#		To get results based on parameters like make,model,year,mileage,rate,color  		      
def get_filter_params(search_dic,parameter):
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			res=[]
			make=search_dic['company']
			model=search_dic['model']
			s_year=search_dic['s_year']
			e_year=search_dic['e_year']
			# grade=if("vehicle_grade" in search_dic) search_dic['vehicle_grade'] else "v_grade"
			if('mileage' in search_dic):
				mileage=search_dic['mileage']
			else:
				mileage="MILEAGE"
			kuzov=search_dic['kuzov']
			# rate=search_dic['rate'] if 'rate' in search_dic else 'RATE'
			# color=search_dic['color']
			sql_where = "select distinct "+parameter+" FROM "+HISTORY_TABLE+" Where AUCTION not like 'USS%' and AUCTION not like 'JU%' and FINISH != 0 and STATUS='SOLD' and  "
			# sql = sql_empty
			sql = sql_where
			if (make != "MAKE"):
				sql = sql+"MARKA_NAME = \""+make+"\""+" and "

			if (model != "MODEL"):
				sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

			if (e_year != "YEAR"):
				sql = sql+"YEAR between "+s_year+" and  "+e_year+" and "

			if (mileage != "MILEAGE"):
				mil_resp=mileage_converter(mileage," and ")
				if(mil_resp!="0 and 0"):
					sql = sql+"MILEAGE between "+mileage_converter(mileage," and ")+" and "
				else:
					sql = sql
				
			if (kuzov != "KUZOV"):
				sql = sql+"KUZOV = \""+kuzov+"\""+" and "

			if ('vehicle_grade' in search_dic):
				if(len(array_parram(search_dic,'vehicle_grade'))>0):
					sql = sql+"GRADE in ("+array_parram(search_dic,'vehicle_grade')+") and "
				else:
					sql = sql
			
			if ('eng_v' in search_dic):
				if(len(array_parram(search_dic,'eng_v'))>0):
					sql = sql+"ENG_V in ("+array_parram(search_dic,'eng_v')+") and "
				else:
					sql = sql

			if ('rate' in search_dic):
				if(len(array_parram(search_dic,'rate'))>0):
					sql = sql+"RATE in ("+array_parram(search_dic,'rate')+") and "
				else:
					sql = sql

			if ('color' in search_dic):
				if(len(array_parram(search_dic,'color'))>0):
					sql = sql+"COLOR in ("+array_parram(search_dic,'color')+") and "
				else:
					sql = sql
			
			# print(str(sql[0:-4]))
			query=str(sql[0:-4])+"order by "+parameter
			cursor.execute(query)
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code)>0):
				params=sorted(list(pd.DataFrame(response_code)[parameter]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res=[]
	except Exception as e :
		log.error(e)
		return []


#		To get vehicle grade results based on parameters like make,model,year,mileage,rate,color  		      
def get_vehicle_grade(search_dic):
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			res=[]
			make=search_dic['company']
			model=search_dic['model']
			s_year=search_dic['s_year']
			e_year=search_dic['e_year']
			# grade=if("vehicle_grade" in search_dic) search_dic['vehicle_grade'] else "v_grade"
			# mileage=search_dic['mileage'] if('mileage' in search_dic)  else "MILEAGE"
			kuzov=search_dic['kuzov']
			# rate=search_dic['rate'] if 'rate' in search_dic else 'RATE'
			# color=search_dic['color']
			sql_where = "select distinct GRADE FROM "+TABLE_DISTINCT+" Where  "
			# sql = sql_empty
			sql = sql_where
			if (make != "MAKE"):
				sql = sql+"MARKA_NAME = \""+make+"\""+" and "

			if (model != "MODEL"):
				sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

			if (e_year != "YEAR"):
				sql = sql+"YEAR between "+s_year+" and "+e_year+" and "

			if (kuzov != "KUZOV"):
				sql = sql+"KUZOV = \""+kuzov+"\""+" and "
			
			query=str(sql[0:-4])+"order by GRADE"
			cursor.execute(query)
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code)>0):
				params=list(response_code)
				for param in params:
					res.append(str(param['GRADE']))
				# print(res)
				return res
			else:
				res=[]
	except Exception as e :
		log.error(e)
		return []


#		To get engine_cc results based on parameters like make,model,year,mileage,rate,color  		      
def get_engine_cc(search_dic):
	try:
		if(len(array_parram(search_dic,'vehicle_grade'))>0):
			connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
			with connection_to_db.cursor() as cursor:
				res=[]
				make=search_dic['company']
				model=search_dic['model']
				s_year=search_dic['s_year']
				e_year=search_dic['e_year']
				# grade=if("vehicle_grade" in search_dic) search_dic['vehicle_grade'] else "v_grade"
				# mileage=search_dic['mileage'] if('mileage' in search_dic)  else "MILEAGE"
				kuzov=search_dic['kuzov']
				# rate=search_dic['rate'] if 'rate' in search_dic else 'RATE'
				# color=search_dic['color']
				sql_where = "select distinct ENG_V FROM "+TABLE_DISTINCT+" Where  "
				# sql = sql_empty
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" and "

				if (model != "MODEL"):
					sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

				if (e_year != "YEAR"):
					sql = sql+"YEAR between "+s_year+" and "+e_year+" and "

				if (kuzov != "KUZOV"):
					sql = sql+"KUZOV = \""+kuzov+"\""+" and "

				if ('vehicle_grade' in search_dic):
					if(len(array_parram(search_dic,'vehicle_grade'))>0):
						sql = sql+"GRADE in ("+array_parram(search_dic,'vehicle_grade')+") and "
					else:
						sql = sql
				
				query=str(sql[0:-4])+"order by ENG_V"
				# print(query)
				cursor.execute(query)
				response_code = cursor.fetchall()
				# print(response_code)
				if(len(response_code)>0):
					params=list(response_code)
					for param in params:
						res.append(str(param['ENG_V']))
					# print(res)
					return res
				else:
					res=[]
		else:
			return []
	except Exception as e :
		log.error(e)
		return []

#		To get distinct results based on parameters model  		
def get_model_params(search_dic):
	try:
		connection_to_db = connect_to_db(HOST_NAME, USER_NAME, PASSWORD, DB_NAME)
		with connection_to_db.cursor() as cursor:
			res = []
			make = search_dic['company']

			sql_where = "select MODEL_NAME,count(*) FROM "+MAKE_MODEL_TABLE + " where "
			# sql = sql_empty
			if (make == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" group by MODEL_NAME order by count(*) desc limit 10"

			# log.info(str(sql[0:-4]))
			#cursor.execute(str(sql[0:-4]))
			cursor.execute(sql)
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code) > 0):
				params = sorted(list(pd.DataFrame(response_code)["MODEL_NAME"]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res = []
	except Exception as e:
		log.error(e)
		return []

#		To get distinct results based on parameters year  		
def get_year_params(search_dic):
	try:
		connection_to_db = connect_to_db(HOST_NAME, USER_NAME, PASSWORD, DB_NAME)
		with connection_to_db.cursor() as cursor:
			res = []
			make = search_dic['company']
			model = search_dic['model']

			sql_where = "select distinct YEAR FROM "+TABLE_DISTINCT + " where "
			# sql = sql_empty
			if (make == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" and "
				
				if (model != "MODEL"):
					sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

			# log.info(str(sql[0:-4]))
			cursor.execute(str(sql[0:-4]))
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code) > 0):
				params = sorted(list(pd.DataFrame(response_code)["YEAR"]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res = []
	except Exception as e:
		log.error(e)
		return []

#		To get distinct results based on parameters chassis  		
def get_chassis_params(search_dic):
	try:
		connection_to_db = connect_to_db(HOST_NAME, USER_NAME, PASSWORD, DB_NAME)
		with connection_to_db.cursor() as cursor:
			res = []
			make = search_dic['company']
			model = search_dic['model']
			start_year = search_dic['s_year']
			end_year = search_dic['e_year']

			sql_where = "select KUZOV,count(*) FROM "+MAKE_MODEL_TABLE + " where "
			# sql = sql_empty
			if (make == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (make != "MAKE"):
					sql = sql+"MARKA_NAME = \""+make+"\""+" and "

				if (model != "MODEL"):
					sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

				if (end_year != "YEAR"):
					sql = sql+"YEAR between "+start_year+" and "+end_year+" group by KUZOV order by count(*) desc limit 10"

			# log.info(str(sql[0:-4]))
			#cursor.execute(str(sql[0:-4]))
			cursor.execute(sql)
			response_code = cursor.fetchall()
			# print(response_code)
			if(len(response_code) > 0):
				params = sorted(list(pd.DataFrame(response_code)["KUZOV"]))
				for param in params:
					res.append(param)
				# print(res)
				return res
			else:
				res = []
	except Exception as e:
		log.error(e)
		return []

#		To get charges applied : 'auctionFee','inspectionfee','transportFee','forwordingVanning','LCCharge','oceanFreight'		
def get_chrages_applied(country_code,port_code,chasis_id,vessel_code):
	try:
		connection_to_db = connect_to_db(HOST_NAME, USER_NAME, PASSWORD, DB_NAME)
		with connection_to_db.cursor() as cursor:
			# print(get_chrages_applied_query(country_code,port_code,chasis_id,vessel_code))
			cursor.execute(get_chrages_applied_query(country_code,port_code,chasis_id,vessel_code))
			response_code = cursor.fetchall()
			# print(response_code[0])
			return response_code[0]
	except Exception as e:
		log.error(str(e))

#		Formatting SQL statement to get applied charges 		
def get_chrages_applied_query(country_code,port_code,chasis_id,vessel_code):
	query="SELECT ves.cost as forwordingVanning,cardetails.cbm,freight.cost as oceanFreight,freight.unit,auction.keyValue as auctionFee,transport.keyValue as transportFee,insepction.charge as inspectionfee,LCCharge.charge as LCCharge  from (SELECT cost FROM "+VESSEL_TABLE+" where code="+str(vessel_code)+") AS ves,(SELECT IFNULL(max(cbm), 0)as cbm FROM "+CARDETAIL_TABLE+" where kuzosCode='"+chasis_id+"') AS cardetails,(SELECT cost,unit FROM "+FREIGHT_TABLE+" where portCode="+str(port_code)+" and vesselCode="+str(vessel_code)+" ) AS freight,(SELECT keyValue FROM "+CONSTANT_TABLE+" where code='AUCTION_FEE') AS auction,(SELECT keyValue FROM "+CONSTANT_TABLE+" where code='TRANSPORT_COST') AS transport,(select IFNULL(max(charge), 0)as charge from "+INSPECTION_TABLE+" where countrycode='"+str(country_code)+"') as insepction,(select IFNULL(max(charge), 0)as charge from "+LETTEROFCREDIT_TABLE+" where countrycode='"+str(country_code)+"') as LCCharge"
	return query



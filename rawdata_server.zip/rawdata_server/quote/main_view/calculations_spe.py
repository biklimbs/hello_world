# Description: calculation_spe deals with calculation for special countries.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:


import sys, os
sys.path.append(os.path.abspath(os.path.join('..')))
try:
	from constants import *
except Exception as e:
		print("Failed to import constants.py. to "+str(os.path.dirname(os.path.realpath(sys.argv[0])))+"/"+os.path.splitext(os.path.basename(__file__))[0]+".py.")


#		To get slab rate based on avg_price and for exceptions countries  
def get_slab_rate(avg_price, country):
	slab_rate = 0
	from_range = 0
	to_range = PRICE_DIFF+1
	if(country == NEWZEALNND):
		slab_rate = get_slab_rate_new_zealand()
	elif(country == CYPRUS):
		slab_rate = get_slab_rate_cyprus()
	elif(country == MALTA):
		slab_rate = get_slab_rate_malta()
	else:
		i = 0
		while(i < 100):
			if(from_range < avg_price < to_range):
				slab_rate = (i*20000)+100000
				break
			i += 1
			from_range = to_range
			to_range = from_range+PRICE_DIFF

	return slab_rate

#		To get slab rate for new_zealand
def get_slab_rate_new_zealand():
	return NEW_ZEALAND_SLAB_RATE

#		To get slab rate for malta
def get_slab_rate_malta():
	return MALTA_SLAB_RATE

#		To get slab rate for cyprus
def get_slab_rate_cyprus():
	return CYPRUS_SLAB_RATE
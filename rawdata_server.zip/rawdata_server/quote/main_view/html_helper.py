# Description: html_helper deals with rearranging content to html foramate.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:


from helper import *
from calculations import *
# constants.py not imported since it is imported in calculations

#		Configuring log filename		
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


#		only FOB shown here no c&f and cif for newzealand 						
def get_quote_newzealand(fob,exchange_rate):
	return FOB_TAG+str(str(fob)+" ¥‎ "+"  "+str(convert_dollar_yen(int(fob),exchange_rate))+" $ ")+" </br>"+CNF_TAG+" - "+"</br>"+CIF_TAG+" - "

#		only FOB shown here no c&f and cif for malta 						
def get_quote_malta(fob,exchange_rate):
	return FOB_TAG+str(str(fob)+" ¥‎ "+"  "+str(convert_dollar_yen(int(fob),exchange_rate))+" $ ")+" </br>"+CNF_TAG+" - "+"</br>"+CIF_TAG+" - "

#		only FOB shown here no c&f and cif for cyprus 						
def get_quote_cyprus(fob,cf,cif,exchange_rate):
	# if(fob==cf):
	# 	return FOB_TAG+" - "+" </br>"+CNF_TAG+" - "+"</br>"+CIF_TAG+" - "
	# else:
	return FOB_TAG+" - "+" </br>"+CNF_TAG+str(str(cf))+" ¥‎ "+"  "+str(str(convert_dollar_yen(int(cf),exchange_rate))+" $ ")+"</br>"+CIF_TAG+str(str(cif))+" ¥‎ "+"  "+str(convert_dollar_yen(int(cif),exchange_rate))+" $ "

#		only FOB shown here 						
def get_quote(fob,cf,cif,exchange_rate):
	if(fob==cf):
		return FOB_TAG+str(str(fob)+" ¥‎ "+"  "+str(convert_dollar_yen(int(fob),exchange_rate))+" $ ")+" </br>"+CNF_TAG+" - "+"</br>"+CIF_TAG+" - "
	else:
		return FOB_TAG+str(str(fob)+" ¥‎ "+"  "+str(convert_dollar_yen(int(fob),exchange_rate))+" $ ")+" </br>"+CNF_TAG+str(str(cf))+" ¥‎ "+"  "+str(str(convert_dollar_yen(int(cf),exchange_rate))+" $ ")+"</br>"+CIF_TAG+str(str(cif))+" ¥‎ "+"  "+str(convert_dollar_yen(int(cif),exchange_rate))+" $ "

# #		avg-price and other details shown here for newzealand 						
# def get_avg_price_and_charges_standard_newzealand(result):
# 	res_tag=""
# 	for tag in TERMS:
# 		if(tag!='oceanFreight'):
# 			if(tag in TERMS_SHOWN):
# 				res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
# 			elif(tag in TERMS_HIDDEN):
# 				res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>Included"
# 		elif(tag=='oceanFreight'):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str('0')+" ¥‎"
# 	return res_tag+"</br>"

#		avg-price and other details shown here for newzealand 						
def get_avg_price_and_charges_standard_newzealand(result):
	if(int(result['Records']['oceanFreight'])>0):
		return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(result['Records']['bidPrice']))+" ¥‎ ")+"</br><strong>"+AUCTION_TAG+"</strong>‎"+INCLUDED+"</br><strong>"+INSPECTION_TAG+"</strong>"+INCLUDED+"</br><strong>"+TRANSPORT_TAG+"</strong>"+INCLUDED+"</br><strong>"+FORWORDVANNING_TAG+"</strong>"+INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+INCLUDED+"</br><strong>"+FREIGHT_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+MARGIN_TAG+"</strong>"+INCLUDED+"</br><strong>"+MISL_TAG+"</strong>"+INCLUDED+"</br><strong>"+INSURANCE_TAG+"</strong>"+INCLUDED+"  </br>"
	else:
		return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(result['Records']['bidPrice']))+" ¥‎ ")+"</br><strong>"+AUCTION_TAG+"</strong>‎"+INCLUDED+"</br><strong>"+INSPECTION_TAG+"</strong>"+INCLUDED+"</br><strong>"+TRANSPORT_TAG+"</strong>"+INCLUDED+"</br><strong>"+FORWORDVANNING_TAG+"</strong>"+INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+INCLUDED+"</br><strong>"+FREIGHT_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+MARGIN_TAG+"</strong>"+INCLUDED+"</br><strong>"+MISL_TAG+"</strong>"+INCLUDED+"</br><strong>"+INSURANCE_TAG+"</strong>"+NOT_INCLUDED+"  </br>"

# #		avg-price and other details shown here for malta 						
# def get_avg_price_and_charges_standard_malta(result):
# 	res_tag=""
# 	for tag in TERMS:
# 		if(tag!='oceanFreight'):
# 			if(tag in TERMS_SHOWN):
# 				res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
# 			elif(tag in TERMS_HIDDEN):
# 				res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>Included"
# 		elif(tag=='oceanFreight'):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str('0')+" ¥‎"
# 	return res_tag+"</br>"

#		avg-price and other details shown here for malta 						
def get_avg_price_and_charges_standard_malta(result):
	return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(result['Records']['bidPrice']))+" ¥‎ ")+"</br><strong>"+AUCTION_TAG+"</strong>‎"+INCLUDED+"</br><strong>"+INSPECTION_TAG+"</strong>"+INCLUDED+"</br><strong>"+TRANSPORT_TAG+"</strong>"+INCLUDED+"</br><strong>"+FORWORDVANNING_TAG+"</strong>"+INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+INCLUDED+"</br><strong>"+FREIGHT_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+MARGIN_TAG+"</strong>"+INCLUDED+"</br><strong>"+MISL_TAG+"</strong>"+INCLUDED+"</br><strong>"+INSURANCE_TAG+"</strong>"+NOT_INCLUDED+" </br>"

# #		avg-price and other details shown here for cyprus 						
# def get_avg_price_and_charges_standard_cyprus(result):
# 	res_tag=""
# 	for tag in TERMS:
# 		if(tag in TERMS_SHOWN):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
# 		elif(tag in TERMS_HIDDEN):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>Included"
# 	return res_tag+"</br>"

#		avg-price and other details shown here for cyprus 						
def get_avg_price_and_charges_standard_cyprus(result):
	if(int(result['Records']['oceanFreight'])>0):
		return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(result['Records']['bidPrice']))+" ¥‎ ")+"</br><strong>"+AUCTION_TAG+"</strong>‎"+INCLUDED+"</br><strong>"+INSPECTION_TAG+"</strong>"+INCLUDED+"</br><strong>"+TRANSPORT_TAG+"</strong>"+INCLUDED+"</br><strong>"+FORWORDVANNING_TAG+"</strong>"+INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+INCLUDED+"</br><strong>"+FREIGHT_TAG+"</strong>"+str(int(result['Records']['oceanFreight']))+" ¥‎"+"</br><strong>"+MARGIN_TAG+"</strong>"+INCLUDED+"</br><strong>"+MISL_TAG+"</strong>"+INCLUDED+"</br><strong>"+INSURANCE_TAG+"</strong>"+INCLUDED+" </br>"
	else:
		return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(result['Records']['bidPrice']))+" ¥‎ ")+"</br><strong>"+AUCTION_TAG+"</strong>‎"+INCLUDED+"</br><strong>"+INSPECTION_TAG+"</strong>"+INCLUDED+"</br><strong>"+TRANSPORT_TAG+"</strong>"+INCLUDED+"</br><strong>"+FORWORDVANNING_TAG+"</strong>"+INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+INCLUDED+"</br><strong>"+FREIGHT_TAG+"</strong>"+str(int(result['Records']['oceanFreight']))+" ¥‎"+"</br><strong>"+MARGIN_TAG+"</strong>"+INCLUDED+"</br><strong>"+MISL_TAG+"</strong>"+INCLUDED+"</br><strong>"+INSURANCE_TAG+"</strong>"+NOT_INCLUDED+" </br>"

# #		avg-price and other details shown here  						
# def get_avg_price_and_charges_standard(result):
# 	res_tag=""
# 	for tag in TERMS:
# 		if(tag in TERMS_SHOWN):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
# 		elif(tag in TERMS_HIDDEN):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>Included"
# 	return res_tag+"</br>"

#		avg-price and other details shown here  						
def get_avg_price_and_charges_standard(result):
	if(int(result['Records']['oceanFreight'])>0):
		return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(result['Records']['bidPrice']))+" ¥‎ ")+"</br><strong>"+AUCTION_TAG+"</strong>‎"+INCLUDED+"</br><strong>"+INSPECTION_TAG+"</strong>"+INCLUDED+"</br><strong>"+TRANSPORT_TAG+"</strong>"+INCLUDED+"</br><strong>"+FORWORDVANNING_TAG+"</strong>"+INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+INCLUDED+"</br><strong>"+FREIGHT_TAG+"</strong>"+str(int(result['Records']['oceanFreight']))+" ¥‎"+"</br><strong>"+MARGIN_TAG+"</strong>"+INCLUDED+"</br><strong>"+MISL_TAG+"</strong>"+INCLUDED+"</br><strong>"+INSURANCE_TAG+"</strong>"+INCLUDED+" </br>"
	else:
		return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(result['Records']['bidPrice']))+" ¥‎ ")+"</br><strong>"+AUCTION_TAG+"</strong>‎"+INCLUDED+"</br><strong>"+INSPECTION_TAG+"</strong>"+INCLUDED+"</br><strong>"+TRANSPORT_TAG+"</strong>"+INCLUDED+"</br><strong>"+FORWORDVANNING_TAG+"</strong>"+INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+INCLUDED+"</br><strong>"+FREIGHT_TAG+"</strong>"+str(int(result['Records']['oceanFreight']))+" ¥‎"+"</br><strong>"+MARGIN_TAG+"</strong>"+INCLUDED+"</br><strong>"+MISL_TAG+"</strong>"+INCLUDED+"</br><strong>"+INSURANCE_TAG+"</strong>"+NOT_INCLUDED+" </br>"

#		avg-price and other details shown here for newzealand  						
def get_avg_price_and_charges_custom_newzealand(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(avg_price))+" ¥‎ ")+"</br><strong>"+SLAB_TAG+"</strong>"+str(int(slab_rate))+" ¥‎"+"</br><strong>"+INSPECTION_TAG+"</strong>"+NOT_INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+str(int(lc_charges))+" ¥‎"+"</br><strong>"+FREIGHT_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+MISL_TAG+"</strong>"+str(int(misc_charge))+" ¥‎ </br>"

#		avg-price and other details shown here for malta  						
def get_avg_price_and_charges_custom_malta(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(avg_price))+" ¥‎ ")+"</br><strong>"+SLAB_TAG+"</strong>"+str(int(slab_rate))+" ¥‎"+"</br><strong>"+INSPECTION_TAG+"</strong>"+NOT_INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+str(int(lc_charges))+" ¥‎"+"</br><strong>"+FREIGHT_TAG+"</strong>"+str('0')+" ¥‎"+"</br><strong>"+MISL_TAG+"</strong>"+str(int(misc_charge))+" ¥‎ </br>"

#		avg-price and other details shown here for cyprus  						
def get_avg_price_and_charges_custom_cyprus(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(avg_price))+" ¥‎ ")+"</br><strong>"+SLAB_TAG+"</strong>"+str(int(slab_rate))+" ¥‎"+"</br><strong>"+INSPECTION_TAG+"</strong>"+NOT_INCLUDED+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+str(int(lc_charges))+" ¥‎"+"</br><strong>"+FREIGHT_TAG+"</strong>"+str(int(freight_charge))+" ¥‎"+"</br><strong>"+MISL_TAG+"</strong>"+str(int(misc_charge))+" ¥‎ </br>"	

#		avg-price and other details shown here   						
def get_avg_price_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge):
	return "</br><strong>"+AVG_TAG+"</strong>"+str(str(int(avg_price))+" ¥‎ ")+"</br><strong>"+SLAB_TAG+"</strong>"+str(int(slab_rate))+" ¥‎"+"</br><strong>"+INSPECTION_TAG+"</strong>"+str(int(inspection_fee))+" ¥‎"+"</br><strong>"+LC_CHARGE_TAG+"</strong>"+str(int(lc_charges))+" ¥‎"+"</br><strong>"+FREIGHT_TAG+"</strong>"+str(int(freight_charge))+" ¥‎"+"</br><strong>"+MISL_TAG+"</strong>"+str(int(misc_charge))+" ¥‎ </br>"	

#		To set HTML format for user selection   		    
def form_quote_html(country,port,vessel,Company,Model,s_year,e_year,Kuzov,Mileage,Grade,Engine_CC,Rate,Color):
	return "<p style='font-size:13px;'><strong>"+COUNTRY_TAG+"</strong>"+str(country)+"</br><strong>"+PORT_TAG+"</strong>"+str(port)+"</br><strong>"+VESSEL_TAG+"</strong>"+str(vessel)+"</br><strong>"+MAKE_TAG+"</strong>"+str(Company)+"</br><strong>"+MODEL_TAG+"</strong>"+str(Model)+"</br><strong>"+CHASSIS_TAG+"</strong>"+str(Kuzov)+"</br><strong>"+YEAR_TAG+"</strong>"+str(s_year)+"-"+str(e_year)+"</br><strong>"+MILEAGE_TAG+"</strong>"+str(Mileage)+"</br><strong>"+GRADE_TAG+"</strong>"+str(Grade)+"</br><strong>"+ENGINE_CC_TAG+"</strong>"+str(Engine_CC.replace("\"",""))+"</br><strong>"+RATE_TAG+"</strong>"+str(Rate)+"</br><strong>"+COLOR_TAG+"</strong>"+str(Color)

#		To set HTML format for data_point   		    
def form_data_points(data_count):
	return "</br><strong>"+DATA_COUNT_TAG+"</strong>"+str(data_count)

#		To set HTML format to display entire resultant data   		    
def get_display_quote(selection_prices,result_html):
	return Markup("<p><font size='3' color='red'>Selection Criterion </font></p><pre>"+selection_prices+"</br><strong><font size='3' color='green'>"+str(result_html)+"</font></strong></p></pre> ")		


#		To Create basic html tag for selection list  		    
def basic_tags_params(param):
	return Markup("<option value='"+param+"' selected='selected' >"+param.capitalize()+"</option>")

# def get_user_selection_custom(country_name,port_name,vessel_name,select,mileage,rate,color):
# 	return "<p style='font-size:13px;'><strong>"+COUNTRY_TAG+"</strong>"+str(country_name)+"</br><strong>"+PORT_TAG+"</strong>"+str(port_name)+"</br><strong>"+VESSEL_TAG+"</strong>"+str(vessel_name)+"</br><strong>"+MAKE_TAG+"</strong>"+str(select['company'])+"</br><strong>"+MODEL_TAG+"</strong>"+str(select['model'])+"</br><strong>"+CHASSIS_TAG+"</strong>"+str(select['kuzov'])+"</br><strong>"+YEAR_TAG+"</strong>"+str(select['s_year'])+"-"+str(select['e_year'])+"</br><strong>"+MILEAGE_TAG+"</strong>"+mileage+"</br><strong>"+GRADR_TAG+"</strong>"+str(rate)+"</br><strong>"+COLOR_TAG+"</strong>"+str(color)

#		To set HTML format for avg-price and other details   		  
def form_fee_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge,country):
	try:
		if(country==NEWZEALNND):
			return get_avg_price_and_charges_custom_newzealand(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
		elif(country==MALTA):
			return get_avg_price_and_charges_custom_malta(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
		elif(country==CYPRUS):
			return get_avg_price_and_charges_custom_cyprus(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
		else:
			return get_avg_price_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge)
	except Exception as e:
		log.error(str(e))

#		To set HTML format for avg-price and other details   		    
def form_fee_and_charges_standard(result,country):
	try:
		log.info(str(result))
		if(country==NEWZEALNND ):
			return get_avg_price_and_charges_standard_newzealand(result)
		elif(country==MALTA):
			return get_avg_price_and_charges_standard_malta(result)
		elif(country==CYPRUS):
			return get_avg_price_and_charges_standard_cyprus(result)
		else:
			return get_avg_price_and_charges_standard(result)
	except Exception as e:
		log.error(str(e))

#		To set HTML format for quote   		      		
def form_result_html(fob,cf,cif,country,exchange_rate):
	try:
		exchange_rate=float(1/(exchange_rate-SUBTRACTED_EXCHANGE_RATE_TO_CONVERSION))
		if(country==NEWZEALNND):
			return get_quote_newzealand(fob,exchange_rate)
		elif(country==MALTA):
			return get_quote_malta(fob,exchange_rate)
		elif(country==CYPRUS):
			return get_quote_cyprus(fob,cf,cif,exchange_rate)
		else:
			return get_quote(fob,cf,cif,exchange_rate)
	except Exception as e:
		log.error(str(e))
	

# def tag(result):
# 	res_tag=""
# 	for tag in TERMS:
# 		if(tag in TERMS_SHOWN):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
# 		elif(tag in TERMS_HIDDEN):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>Included"
# 	return res_tag+"</br>"
	
	
# #		To set visible for prices in HTML for all prices   (Not using, if want to display all charges we can use this definition) 		      		
# def tag_with_price(result):
# 	res_tag=""
# 	for tag in TERMS:
# 		if(tag in result['Records']):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(str(int(result['Records'][tag]))+" ¥‎ ")
# 		elif(tag=="margin"):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(get_margin_search_results(int(result['Records']['bidPrice'])))+" ¥‎"
# 		elif(tag=="misl_charge"):
# 			res_tag=res_tag+"</br><strong>"+TAG_DIC[tag]+"</strong>"+str(get_standard_misl_charge())+" ¥‎"+"</br>"
# 	return res_tag

#				Calls on load of page 								
def on_page_load():
	port_tags=basic_tags_params("PORT")
	vessel_tags=basic_tags_params("VESSEL")
	make_tag=basic_tags_params("MAKE")
	model_tags=basic_tags_params("MODEL")
	kuzov_tags=Markup("<option value='KUZOV' selected='selected' >Chassis ID</option>")
	mileage_tags=basic_tags_params("MILEAGE")
	year_tags=basic_tags_params("YEAR")
	rate_tags=Markup("<option value='RATE'  >Grade</option>")
	color_tags=basic_tags_params("COLOR")
	result=Markup("<p  align='center'>  Select Search Criterion </p>")
	vehicle_grade_tags=Markup("<option value='v_grade' selected='selected' >Vehicle Grade</option>")


	return port_tags,vessel_tags,make_tag,model_tags,kuzov_tags,mileage_tags,year_tags,rate_tags,color_tags,result,vehicle_grade_tags
# Description: quote deals with get quote price and charges based on selection for standard and customization.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:


import sys
from main_view.sql_helper import * 
from main_view.html_helper import * 
from main_view.api_helper import * 
from main_view.helper import * 
from main_view.constants import *
from main_view.calculations import * 

from history_view.history_html import *
from history_view.history_helper import *
from detailed_view.deailed_query import *
from recommendations.recommendations_query import *
from recommedation.recommendation_sys import *
from recommendations.recommendations_html import *

import ast

# Configuring log filename 
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		 To get Custom Quote 		
def custom_quote(search_dic,exchange_rate):
	try:
		resultant_dic={}
		payload=get_payload(search_dic)

		country, port, vessel, company, model, s_year, e_year, mileage, kuzov, grade, engine_cc, rate, color, country_name,port_name,vessel_name,vehicle_units= validate_parameter_standard(search_dic)

		c_params=str(search_dic['c_params']).split(',')

		#		To assign current charges       
		avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country_name,port_name,vessel_name,data_count=assign_chages_custom(c_params)

		inspection_fee=get_inspection_fee_for_country(int(inspection_fee),country_name)

		#		To get fob,cnf,cif charges for country       
		fob,cf,cif=get_fob_cf_cif_custom(avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country_name)

		#		To arrange HTML formation for parameters (if there is no value '-' will be included )
		if('rate' in str(search_dic)):
			rate=str(array_parram(search_dic,'rate'))
		else:
			rate="-"
		if('color' in str(search_dic)):
			color=str(array_parram(search_dic,'color'))
		else:
			color="-"
		if('vehicle_grade' in str(search_dic)):
			grade=str(array_parram(search_dic,'vehicle_grade'))
		else:
			grade="-"
		if('eng_v' in str(search_dic)):
			engine_cc=str(array_parram(search_dic,'eng_v'))
		else:
			engine_cc="-"

		mil_resp=mileage_converter(str(search_dic['mileage']),"-")
		if(mil_resp=="0-0"):
			mileage="-"
		else:
			mileage=mil_resp

		#		HTML for quote data       
		quote_html=form_quote_html(country_name,port_name,vessel_name,company,model,s_year,e_year,kuzov,mileage,grade,engine_cc,rate,color)
		
		#		HTML for data points       
		data_points_html=form_data_points(data_count)

		#		HTML for fee and charges       
		fee_and_charges_html=form_fee_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge,country_name)

		#		HTML for FOB C&F CIF       	
		result_html=form_result_html(fob,cf,cif,country_name,exchange_rate)

		#		   Display_html       
		display_html=get_display_quote(quote_html+data_points_html+fee_and_charges_html,result_html)

		#		   Save record to .csv file        
		save_to_history_csv(payload,str(result_html),fee_and_charges_html)


		resultant_dic['display_html']=display_html
		resultant_dic['history']=set_history()
		resultant_dic['cnf']=cf
		resultant_dic['fob']=fob

		return jsonify(resultant_dic)
	except Exception as e:
		log.error(str(e))

	
#		To assign current chages (used in custom mode)      
def assign_chages_custom(c_params):
	try:
		avg_price=str(c_params[0])
		slab_rate=str(c_params[1])
		inspection_fee=str(c_params[2])
		lc_charges=str(c_params[3])
		misc_charge=str(c_params[4])
		freight_charge=str(c_params[5])
		country_name=str(c_params[6])
		port_name=str(c_params[7])
		vessel_name=str(c_params[8])
		data_count=str(c_params[9])
		return avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country_name,port_name,vessel_name,data_count
	except Exception as e:
		log.error(str(e))


#		To get bid_price and other details by calling rest_api used in checkbox of customize         		
def display_custom_options(search_dic):
	try:
		res_dic={}
		c_params=str(search_dic['c_params']).split(",")
		country_name=validate_parameter(c_params[6],"country")
		
		avg_price=str(c_params[0])
		inspection_fee=str(c_params[2])
		freight_charge=str(c_params[5])
		
		res_dic['avg_price']=(avg_price)
		res_dic['slab_rate']=int(get_slab_rate(int(avg_price),country_name))
		res_dic['inspection_fee']=get_inspection_fee_for_country(int(inspection_fee),country_name)
		res_dic['lc_charge']=0
		res_dic['misl_fee']=0
		res_dic['freight_charge']=int(freight_charge)
		
		return res_dic
	except Exception as e:
		log.error(e)


#		 To get Standard Quote 		
def standard_quote(search_dic,exchange_rate):
	try:
		start_time=t.time()

		valid_start_time=t.time()

		country, port, vessel, company, model, s_year, e_year, mileage, kuzov, grade,engine_cc, rate, color, country_name,port_name,vessel_name,vehicle_units = validate_parameter_standard(search_dic)
		
		log.info("Time taken to Validate Prams call :"+str(round(t.time()-valid_start_time,2)))	
				
		
		api_start_time=t.time()	

		# payload,result=call_quote_api(country,port,vessel,company,model,s_year,e_year,mileage, kuzov,rate,color)
		payload,result=call_bid_lambda(country,port,vessel,company,model,s_year,e_year,mileage, kuzov,grade,engine_cc,rate,color)

		
		#print("Bid price: "+str(result["bidPrice"]))
		log.info("Time taken to API call :"+str(round(t.time()-api_start_time,2)))	
		# uncomment below condition if using call_quote_api defination
		# if(result['Success']):
		if(result['success']):
			
			db_res=get_chrages_applied(country,port,kuzov,vessel)
			avg_price=str(result["price"])	
			result=formatted_results_standard(db_res,result,vehicle_units,vessel,exchange_rate)
					
			log.debug("Quote API input"+str(payload))
			log.debug("Quote API response"+str(result))
			
			asign_varibles_start_time=t.time()
				
			#		Assign_varibles       
			avg_price,auction_fee,trasport_charge,forward_fee,inspection_fee,lc_charges,misc_charge,freight_charge,margin=asign_varibles_standard(result,country_name)
			
			log.info("Time taken to asign_varibles block :"+str(round(t.time()-asign_varibles_start_time,2)))	
			
			#		Get FOB C&F CIF       
			fob,cf,cif = get_fob_cf_cif_standard(avg_price,auction_fee,inspection_fee,forward_fee,trasport_charge,lc_charges,freight_charge,margin,misc_charge)					
					
			#		To arrange HTML formation for parameters (if there is no value '-' will be included )
			if company =='':
				Company='-'
			else:
				Company=company
			if(model==''):
				Model='-'
			else:
				Model=model
			if(mileage==''):
				Mileage='-'
			else:
				Mileage=mileage
			if(kuzov==''):
				Kuzov='-'
			else:
				Kuzov=kuzov
			if(rate=="[]"):
				Rate='-'
			else:
				Rate=str(str(rate).partition('[')[-1].rpartition(']')[0])
			if(color=="[]"):
				Color='-'
			else:
				Color=str(str(color).partition('[')[-1].rpartition(']')[0])
			if(grade=="[]"):
				Grade='-'
			else:
				Grade=str(str(grade).partition('[')[-1].rpartition(']')[0])
			if(engine_cc=="[]"):
				Engine_cc='-'
			else:
				Engine_cc=str(str(engine_cc).partition('[')[-1].rpartition(']')[0])

			# print(Markup( get_recommendations(search_dic)))

			detailed_start_time=t.time()

			#		HTML for Detailed view       
			detailed_view_formatter,length=get_Detailed_view(search_dic)
			
			log.info("Time taken to DB call :"+str(round(t.time()-detailed_start_time,2)))	

			renter_start_time=t.time()

			#		HTML for quote data       
			quote_html=form_quote_html(country_name,port_name,vessel_name,Company,Model,s_year,e_year,Kuzov,Mileage,Grade.replace(", ",","),Engine_cc.replace(", ",","),Rate.replace(", ",","),Color.replace(", ",","))

			#		HTML for data points       
			data_points_html=form_data_points(length)

			#		HTML for fee and charges       
			fee_and_charges_html=form_fee_and_charges_standard(result,country_name)
			
			#		HTML for FOB C&F CIF       
			result_html=form_result_html(fob,cf,cif,country_name,exchange_rate)

			#		   Display_html       
			display_html=get_display_quote(quote_html+data_points_html+fee_and_charges_html,result_html)

			#		   Save record to .csv file        
			save_to_history_csv(get_payload(search_dic),str(result_html)," ")
				
			log.info("Time taken to renter and validate HTML page function :"+str(round(t.time()-renter_start_time,2)))		

			log.info("Time taken to standard quote function :"+str(round(t.time()-start_time,2)))		
			
			#return jsonify(get_formated_dic_standard(country_name,avg_price,inspection_fee,freight_charge,length,display_html,detailed_view_formatter,Markup(get_recommendations(search_dic)),cf,fob))
			return avg_price,jsonify(get_formated_dic_standard(country_name,avg_price,inspection_fee,freight_charge,length,display_html,detailed_view_formatter,cf,fob))
		else:
			log.error("No car details found") 
			return "0",jsonify({"Status":False })
	except Exception as e:
		log.error(e)
		return "",jsonify({})

#		 To get Standard Quote 		
def recommendation_quote(search_dic,exchange_rate,avg_price):
	'''
	This function takes all parameter provided in search_dic required for query and return recommendation results
	'''
	try:
		country, port, vessel, company, model, s_year, e_year, mileage, kuzov, grade,engine_cc, rate, color, country_name,port_name,vessel_name,vehicle_units = validate_parameter_standard(search_dic)	

		try:
			grade= ast.literal_eval(grade)[0]
		except:
			grade=""
		try:
			engine_cc= ast.literal_eval(engine_cc)[0]
		except:
			engine_cc=""
		try:	
			rate= ast.literal_eval(rate)[0]
		except:
			rate=""
		try:
			color= ast.literal_eval(color)[0]
		except:
			color=""
		try:
			mileage=str(mileage).split("-")[1].strip()
		except:
			mileage="40000"	
		make=company
		model=model
		year=s_year
		mileage_range=mileage
		veh_grade=grade
		veh_cc=engine_cc
		#---gets recommeded data from database---
		recommed_car_data=get_recommend_cars(make, model, year,mileage_range, kuzov, veh_grade, veh_cc, rate, color, avg_price)
		#---format given data into HTML tags---
		recommed_car_data_html=Markup(get_recommendations_html(recommed_car_data))
		return jsonify(get_formated_dic_for_recommendation(recommed_car_data_html))
	except Exception as e:
		log.error(e)
		return jsonify({})


#		 Validating parameters for Standard Quote 		
def validate_parameter_standard(search_dic):
	try:
		c_params=str(search_dic['c_params']).split(",")
		company=validate_parameter(search_dic['company'],'company')
		model=validate_parameter(search_dic['model'],'model')
		start_year=validate_parameter(search_dic['s_year'],'year')
		end_year=validate_parameter(search_dic['e_year'],'year')
		mil_resp=mileage_converter(search_dic['mileage'],"-")
		if(mil_resp=="0-0"):
			mileage=""
		else:
			mileage=mil_resp
		chassis=validate_parameter(search_dic['kuzov'],'kuzov')
		grade=convert_to_array(array_parram(search_dic,'vehicle_grade'))
		engine_cc=convert_to_array(array_parram(search_dic,'eng_v'))
		rate=convert_to_array(array_parram(search_dic,'rate'))
		color=convert_to_array(array_parram(search_dic,'color'))
		country=validate_parameter(search_dic['country'],"country")
		port=validate_parameter(search_dic['port'],"port")
		vessel=validate_parameter(search_dic['vessel'],"vessel")
		country_name=c_params[6]
		port_name=c_params[7]
		vessel_name=c_params[8]
		vehicle_units=" "
		if('vehicle_units' in search_dic):
			vehicle_units=search_dic['vehicle_units']
		else:
			vehicle_units=" "
		
		return country, port, vessel, company, model, start_year, end_year, mileage, chassis,grade,engine_cc,rate, color, country_name,port_name,vessel_name,vehicle_units
	except Exception as e:
		log.error(str(e))
		traceback.print_exc()
	
#		 Assigning variables for Standard Quote 		
def asign_varibles_standard(result,country_name):
	try:
		avg_price=int(result['Records']['bidPrice'])
		auction_fee=int(result['Records']['auctionFee'])
		trasport_charge=int(result['Records']['transportFee'])
		forward_fee=int(result['Records']['forwordingVanning'])
		inspection_fee=int(result['Records']['inspectionfee'])
		lc_charges=int(result['Records']['LCCharge'])
		misc_charge=get_standard_misl_charge() # Fixed
		freight_charge=int(result['Records']['oceanFreight'])
		margin=get_margin_search_results(avg_price) # % of margin from avg_price
		return avg_price,auction_fee,trasport_charge,forward_fee,inspection_fee,lc_charges,misc_charge,freight_charge,margin
	except Exception as e:
		log.error(str(e))
	
#		 Formatting dictionary for Standard Quote 		
def get_formated_dic_standard(country_name,avg_price,inspection_fee,freight_charge,length,display_html,detailed_view_formatter,cnf,fob):
	try:
		start_time=t.time()
		html_dic={}
		html_dic['display_html']=display_html
		html_dic['history']=set_history()
		html_dic['detailed']=detailed_view_formatter

		html_dic['avg_price']=avg_price
		html_dic['slab_rate']=str(int(get_slab_rate(int(avg_price),country_name)))
		html_dic['inspection_fee']=inspection_fee
		html_dic['lc_charge']=0
		html_dic['misl_fee']=0
		html_dic['freight_charge']=freight_charge
		html_dic['data_count']=length
		html_dic['cnf']=cnf
		html_dic['fob']=fob
		#html_dic['recommendations_grid']=recommendations_grid
		html_dic["Status"]=True
		log.info("Time taken to standard quote formatting :"+str(round(t.time()-start_time,2)))		
		return html_dic
	except Exception as e:
		log.error(str(e))

#		 Formatting dictionary for Standard Quote 		
def get_formated_dic_for_recommendation(recommendations_grid):
	try:
		start_time=t.time()
		html_dic={}
		html_dic['recommendations_grid']=recommendations_grid
		html_dic["Status"]=True
		log.info("Time taken to standard quote formatting :"+str(round(t.time()-start_time,2)))		
		return html_dic
	except Exception as e:
		log.error(str(e))



#		Combining and formatting results into dictionary fromate
def formatted_results_standard(db_res,lambda_res,vehicle_units,vessel,exchange_rate):
	oceanFreight=""
	result={}
	records={}
	records['bidPrice']=lambda_res['price']
	records['auctionFee']=db_res['auctionFee']
	records['inspectionfee']=db_res['inspectionfee']
	records['transportFee']=db_res['transportFee']
	records['forwordingVanning']=db_res['forwordingVanning']
	records['LCCharge']=db_res['LCCharge']
	if(db_res['unit']=='JPY'):
		oceanFreight=remove_comma_return_int(db_res['oceanFreight'])
	else:
		# print("$",str(db_res['oceanFreight']))
		oceanFreight=get_freight(db_res['oceanFreight'],db_res['cbm'],exchange_rate)
		# print(oceanFreight)
	records['oceanFreight']=freightchages_on_units(oceanFreight,vehicle_units,vessel)
	result['Records']=records
	return result

#		To get freight charges based on units of vehicles user want to transport
def freightchages_on_units(charge,units,vessel):
	# print(charge,units,vessel)
	# print(units)
	oceanFreight=""
	if(int(charge)>0):
		if(units!=" "):
			try:
				if(int(vessel)==3):
					oceanFreight=int(charge/int(units))
				elif(int(vessel)==2):
					oceanFreight=int(charge/int(units))
			except Exception as e:
				oceanFreight=charge
		else:
			oceanFreight=charge		
	else:
		oceanFreight=charge		
	return oceanFreight


#		To change a formate of dic parameters in to payload formate readable for api call       
def get_payload(search_dic):
	try:
		c_params=str(search_dic['c_params']).split(',')
		country=str(c_params[6])
		port=str(c_params[7])
		vessel=str(c_params[8])
		company=validate_parameter(search_dic['company'],'company')
		model=validate_parameter(search_dic['model'],'model')
		s_year=validate_parameter(search_dic['s_year'],'year')
		e_year=validate_parameter(search_dic['e_year'],'year')
		mil_resp=mileage_converter(search_dic['mileage'],"-")
		if(mil_resp=="0-0"):
			mileage=""
		else:
			mileage=mil_resp
		kuzov=validate_parameter(search_dic['kuzov'],'kuzov')
		rate=convert_to_array(array_parram(search_dic,'rate'))
		color=convert_to_array(array_parram(search_dic,'color'))
		payload = "{\r\n\"company\": \""+company+"\",\r\n\"model\": \""+model+"\",\r\n\"s_year\": \""+s_year+"\",\r\n\"e_year\": \""+e_year+"\",\r\n\"mileage\": \""+mileage+"\",\r\n\"color\": "+str(color).replace("'","\"")+" ,\r\n\"kuzov\": \""+kuzov+"\",\r\n\"rate\": "+str(rate).replace("'","\"")+",\r\n\"countryCode\":\""+country+"\",\r\n\"portCode\":\""+port+"\",\r\n\"vessleCode\":\""+vessel+"\"\r\n}"
		return payload
	except Exception as e:
		log.error(str(e))
		# traceback.print_stack()
		return str(e)


#		To get fob,cf,cif for standard quote        		
def get_fob_cf_cif_standard(avg_price,auction_fee,inspection_fee,forward_fee,trasport_charge,lc_charges,freight_charge,margin,misc_charge):
	try:
		if(avg_price > 0):
			fob=get_fob_standard(avg_price, auction_fee, trasport_charge,forward_fee, inspection_fee, lc_charges, misc_charge, margin)
			cf=get_cnf_standard(fob, freight_charge)
			cif=get_cif_standard(fob, freight_charge)
		else:

			fob=0
			cf=0
			cif=0
		return fob,cf,cif
	except Exception as e:
		log.error(str(e))	

#		To get fob,cf,cif for custom quote        		
def get_fob_cf_cif_custom(avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country):
	try:
		fob=""
		cf=""
		cif=""
		if(int(avg_price) > 0):
			fob=get_fob_custom(avg_price,slab_rate,lc_charges,inspection_fee,misc_charge)
		else:
			fob=0
		cf=get_cnf_custom(fob, freight_charge)
		cif=get_cif_custom(fob, freight_charge)
		return fob,cf,cif
	except Exception as e:
		log.error(str(e))



#		To get inspection fee for country        
def get_inspection_fee_for_country(inspection,country):
	try:
		if(country==NEWZEALNND):
			return 0
		elif(country==MALTA):
			return 0
		elif(country==CYPRUS):
			return 0
		else:
			return inspection
	except Exception as e:
		log.error(str(e))

# -*- coding: iso-8859-1 -*-

import sys, os
sys.path.append(os.path.abspath(os.path.join('..')))
try:
	from constants import *
except Exception as e:
		print("Failed to import constants.py. to "+str(os.path.dirname(os.path.realpath(sys.argv[0])))+"/"+os.path.splitext(os.path.basename(__file__))[0]+".py.")

from fpdf import FPDF
from api_helper import *
from datetime import datetime, time
from calculations import * 

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		To crete .PDF file by binding dynamic data  
def pdf_generator(invoice_receipt,invoice_date,invoice_no,invoice_item_no,make,model,grade,year_month,chassis,color,transmission,eng_cc,drive,total,total_units,invoice_remarks,to_invoice_contact,invoice_currency,port_name,exchange_rate):	
	try:
		value_tag_shown=str(value_tobe_shown(total))
		exchange_rate=float(1/(exchange_rate-SUBTRACTED_EXCHANGE_RATE_TO_CONVERSION))
		total,currency_symbol=get_currency_symbol_n_Total(invoice_currency,total,exchange_rate)
		pdf = FPDF()
		pdf.add_page()
		pdf.set_font('helvetica', '', 13.0)

		pdf.rect(15.0, 15.0, 170.0, 245.0)
		pdf.rect(16.0, 16.0, 168.0, 48.0)
		pdf.set_font('Arial', '', 7)
		pdf.cell(10)
		# pdf.cell(ln=2, h=22.0, align='L', w=75.0, txt='Quote for: sallukhankhankhan@gmail.com', border=0,  link = '')
		pdf.image(PDF_LOGO, 16.5, 16.5, link='', type='', w=166.0, h=35.0)
		pdf.ln(h=48)
		pdf.cell(ln=2, h=3.0, align='C', w=0.0, txt='4th Floor, Koyo Building, 5-49, Honcho, Naka-Ku, Yokohama - 231-0005, Japan.', border=0,  link = '')
		pdf.cell(ln=2, h=3.0, align='C', w=0.0, txt='Tel: +81-50-6862-7659, Fax: +81-50-6862-7680, Email: autoworldjapan@gmail.com, www.autoworldjapan.com', border=0,  link = '')
		pdf.ln(h=20)
		pdf.set_font('Arial', 'B', 10)
		pdf.cell(ln=2, h=6.0, align='C', w=0.0, txt='PROFORMA INVOICE', border=0,  link = '')
		pdf.ln(h=6)
		pdf.cell(10)
		pdf.set_font('Arial', 'B', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt='To:', border=0)
		pdf.cell(10)
		pdf.set_font('Arial', '', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt=invoice_receipt, border=0)
		pdf.cell(40)
		pdf.set_font('Arial', 'B', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt='DATE:', border=0)
		pdf.cell(11)
		pdf.set_font('Arial', '', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt=invoice_date, border=0)
		pdf.cell(35)
		pdf.set_font('Arial', 'B', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt='INVOICE NO.:', border=0)
		pdf.cell(25)
		pdf.set_font('Arial', '', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt=invoice_no, border=0)
		pdf.ln(h=6)
		pdf.cell(10)
		pdf.set_font('Arial', 'B', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt='Contact:', border=0)
		pdf.cell(21)
		pdf.set_font('Arial', '', 10)
		pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt=to_invoice_contact, border=0)
		# pdf.cell(ln=2, h=0.0, align='L', w=13.0, txt='+254723459595', border=0)
		pdf.ln(h=12)
		pdf.set_font('Arial', 'B', 10)
		pdf.cell(ln=2, h=0.0, align='C', w=0.0, txt='DESCRIPTION & QUANTITY', border=0)
		pdf.rect(16.0, 85.0, 168.0, 80.0)
		pdf.line(16, 116.6, 184, 116.6)
		pdf.line(16, 130.1, 184, 130.1)
		pdf.line(16, 157, 184, 157)
		pdf.ln(h=3)
		pdf.cell(6)
		pdf.set_font('Arial', 'B', 8)
		pdf.set_fill_color(HEADER_RED, HEADER_GREEEN, HEADER_BLUE)
		pdf.multi_cell(h=13, align='C', w=15.0, txt='Sr No.', border=0,fill=True)
		pdf.y = 117
		pdf.x = 31
		pdf.multi_cell( h=13, align='C', w=15.0, txt='Make', border=0,fill=True)
		pdf.y = 117
		pdf.x = 46
		pdf.multi_cell( h=13, align='C', w=15.0, txt='Model', border=0,fill=True)
		pdf.y = 117
		pdf.x = 61
		pdf.multi_cell( h=13, align='C', w=15.0, txt='Grade', border=0,fill=True)
		pdf.y = 117
		pdf.x = 76
		pdf.multi_cell( h=6.5, align='C', w=15.0, txt='Year/    Month', border=0,fill=True)
		pdf.y = 117
		pdf.x = 91
		pdf.multi_cell( h=6.5, align='C', w=15.0, txt='Chassis No', border=0,fill=True)
		pdf.y = 117
		pdf.x = 106
		# pdf.multi_cell( h=6.5, align='J', w=12.0, txt='Engine No', border=0,fill=True)
		# pdf.y = 117
		# pdf.x = 100
		pdf.multi_cell( h=13, align='C', w=15.0, txt='Color', border=0,fill=True)
		pdf.y = 117
		pdf.x = 121
		pdf.multi_cell( h=13, align='C', w=15.0, txt='Trans.', border=0,fill=True)
		pdf.y = 117
		pdf.x = 136
		pdf.multi_cell( h=13, align='C', w=15.0, txt='CC', border=0,fill=True)
		pdf.y = 117
		pdf.x = 151
		pdf.multi_cell( h=13, align='C', w=15.0, txt='Drive.', border=0,fill=True)
		pdf.y = 117
		pdf.x = 166
		pdf.multi_cell( h=4.3, align='C', w=18, txt="Price "+value_tag_shown+" "+port_name+"         "+currency_symbol+".", border=0,fill=True)

		pdf.set_fill_color(255, 255, 255)
		pdf.ln(1)
		pdf.cell(6.2)
		pdf.set_font('Arial', '', 6)
		pdf.multi_cell(h=7, align='C', w=15.0, txt=invoice_item_no, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 31
		pdf.multi_cell( h=7, align='C', w=15.0, txt=make, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 46
		pdf.multi_cell( h=7, align='C', w=15.0, txt=model, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 61
		pdf.multi_cell( h=7, align='C', w=15.0, txt=grade, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 76
		pdf.multi_cell( h=7, align='C', w=15.0, txt=year_month, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 91
		pdf.multi_cell( h=7, align='C', w=15.0, txt=chassis, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 106
		# pdf.multi_cell( h=13, align='C', w=12.0, txt=ENG_NO, border=0,fill=True)
		# pdf.y = 130.3
		# pdf.x = 100
		pdf.multi_cell( h=7, align='C', w=15.0, txt=color, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 121
		pdf.multi_cell( h=7, align='C', w=15.0, txt=transmission, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 136
		pdf.multi_cell( h=7, align='C', w=15.0, txt=eng_cc, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 151
		pdf.multi_cell( h=7, align='C', w=15.0, txt=drive, border=0,fill=True)
		pdf.y = 130.3
		pdf.x = 166
		pdf.multi_cell( h=13, align='C', w=18, txt=total, border=0,fill=True)


		pdf.line(31, 117, 31, 157)
		pdf.line(46, 117, 46, 157)
		pdf.line(61, 117, 61 ,157)
		pdf.line(76, 117, 76, 157)
		pdf.line(91, 117, 91, 157)
		pdf.line(106, 117, 106, 157)
		pdf.line(121, 117, 121, 165)
		pdf.line(136, 117, 136, 165)
		pdf.line(151, 117, 151, 157)
		# pdf.line(136, 117, 136, 170)
		pdf.line(166, 117, 166, 165)

		pdf.ln(h=18)
		pdf.set_font('Arial', 'B', 10)
		pdf.cell(ln=0, h=0.0, align='C', w=100.0, txt='Total Unit(s)', border=0)
		pdf.x =120
		pdf.cell(ln=0, h=0.0, align='C', w=15.0, txt=total_units, border=0)
		pdf.x =145
		pdf.cell(ln=0, h=0.0, align='C', w=15.0, txt='Total ', border=0)
		pdf.set_font('Arial', 'B', 8)
		pdf.y = 160
		pdf.x =165
		pdf.multi_cell( h=3, align='C', w=18, txt=total , border=0)
		pdf.ln(h=8)
		pdf.cell(6)
		pdf.cell(ln=0, h=3.0, align='L', w=30.0, txt='Remarks:', border=0)
		pdf.set_font('Arial', '', 8)
		pdf.multi_cell( h=3, align='L', w=40, txt=invoice_remarks , border=0)

		# pdf.cell(ln=0, h=3.0, align='L', w=100.0, txt=REMARKS, border=0)
		
		pdf.ln(h=10)
		pdf.cell(6)
		pdf.set_font('Arial', 'B', 8)
		pdf.cell(ln=1, h=3.0, align='L', w=30.0, txt='PLEASE REMIT TO THE FOLLOWING ACCOUNT:', border=0)
		pdf.ln(h=2)
		pdf.cell(6)
		pdf.set_font('Arial', 'B', 8)
		pdf.cell(ln=0, h=3.0, align='L', w=30.0, txt='BENEFICIARY:', border=0)
		pdf.set_font('Arial', '', 8)
		pdf.cell(ln=0, h=3.0, align='L', w=100.0, txt='AUTOWORLD INTERNATIONAL LTD.', border=0)
		pdf.set_font('Arial', 'B', 8)
		pdf.ln(h=4)
		pdf.cell(6)
		pdf.cell(ln=0, h=3.0, align='L', w=30.0, txt='ACCOUNT NO.: ', border=0)
		pdf.set_font('Arial', '', 8)
		pdf.cell(ln=0, h=3.0, align='L', w=100.0, txt='9110142', border=0)
		pdf.set_font('Arial', 'B', 8)
		pdf.ln(h=4)
		pdf.cell(6)
		pdf.cell(ln=0, h=3.0, align='L', w=30.0, txt='BANK:', border=0)
		pdf.set_font('Arial', '', 8)
		pdf.cell(ln=0, h=3.0, align='L', w=100.0, txt='MIZUHO BANK LTD.', border=0)
		pdf.set_font('Arial', 'B', 8)
		pdf.ln(h=4)
		pdf.cell(6)
		pdf.cell(ln=0, h=3.0, align='L', w=30.0, txt='BRANCH:', border=0)
		pdf.set_font('Arial', '', 8)
		pdf.cell(ln=0, h=3.0, align='L', w=100.0, txt='HIRAI BRANCH, SWIFT. ', border=0)
		pdf.set_font('Arial', 'B', 8)
		pdf.ln(h=4)
		pdf.cell(6)
		pdf.cell(ln=0, h=3.0, align='L', w=30.0, txt='CODE:', border=0)
		pdf.set_font('Arial', '', 8)
		pdf.cell(ln=0, h=3.0, align='L', w=100.0, txt='MHCBJPJT. ', border=0)

		pdf.ln(h=8)
		pdf.image(PDF_SIGN, 125.0, 220.0, link='', type='', w=50.0, h=24.0)
		pdf.ln(h=35)
		pdf.set_font('Arial', 'B', 8)
		pdf.cell(ln=0, h=0.0, align='R', w=160.0, txt='Autoworld International Ltd.', border=0)

		year=int(datetime.today().strftime("%y"))
		
		file_name=get_file_name("clear")
		pdf.output(PDF_FILE_NAME+file_name+".pdf", 'F')
		pdf.output(PDF_FILE_NAME_EMAIL+file_name+".pdf", 'F')
		
		return True,PDF_FILE_NAME+file_name+".pdf"
	except Exception as e:
		log.error(str(e))
		return False,""


#		To set name for .pdf file dynamically 
def get_file_name(clear):
	files=" "
	for parent, dirnames, filenames in os.walk(PDF_FILE_NAME):
		for file in filenames:
			if file.lower().endswith('.pdf'):
				files=int(file.split(".")[0])+1
				if(clear=="clear"):
					os.remove(PDF_FILE_NAME+file)
					os.remove(PDF_FILE_NAME_EMAIL+file)
	# file_name=files
	if(str(files)==" "):
		file_name="001"
	elif(int(files)<10):
		file_name="00"+str(files)
	elif(int(files)<100):
		file_name="0"+str(files)
	else:
		file_name=str(files)

	return file_name

#		To set which value to be shown in .PDF file 
def value_tobe_shown(total):
	value_tobe_shown=" "
	if(str(str(total).split(":")[0]).strip()=="FOB"):
		value_tobe_shown="FOB"
	else:
		value_tobe_shown="C&F"
	return value_tobe_shown

#		To get price in JPY/$ and currency symbol 
def get_currency_symbol_n_Total(currency,total,exchange_rate):
	currency_symbol=""
	if(currency=="JPY"):
		# unicode code for japanese yen symbol (u"\u00A5") 
		currency_symbol=u"\u00A5"
		total=u"\u00A5"+" "+str(str(total).split(":")[1])
	else:
		currency_symbol="$"
		total="$ "+str(convert_dollar_yen(int(str(str(total).split(":")[1])),exchange_rate))
	return total,currency_symbol


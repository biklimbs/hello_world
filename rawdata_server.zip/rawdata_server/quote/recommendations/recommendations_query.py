# Description: history_html deals with reading records from csv and formating to readable HTML format.
# Author:  Pavan Kumar.C
# Created On: 30/11/2018
# Modified For:
# Modified On:
# Modified By:

import pandas as pd
from sql_helper import *
# constants.py not imported since it is imported in sql_helper
from .recommendations_html import *
from logger_config import *
import logger_config

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")



#---Connection to "DATABASE_Exception"---
def connect_to_db_spark():
	connection = pymysql.connect(host=HOST_SPARK,
                                     user=USER_SPARK,
                                     password=PASSWORD_SPARK,
                                     db=SOURCE_DATABASE_SPARK,
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)
	return connection

#		To get results based on parameters like make,model,year,mileage,rate,color        
def get_recommendations(search_dic):
	try:
		start_time=t.time()
		current_date=datetime.now()
		current_date,temp=str(current_date).split('.')
		connection_to_db = connect_to_db_spark()
		#print(search_dic)
		#connection_to_db = connect_to_db(HOST_SPARK,USER_SPARK,PASSWORD_SPARK,DB_NAME)
		with connection_to_db.cursor() as cursor:
			make=search_dic['company']
			model=search_dic['model']
			s_year=search_dic['s_year']
			e_year=search_dic['e_year']
			# grade=if("vehicle_grade" in search_dic) search_dic['vehicle_grade'] else "v_grade"
			if('mileage' in search_dic):
				mileage=search_dic['mileage']
			else:
				mileage="MILEAGE"
			kuzov=search_dic['kuzov']
			# rate=search_dic['rate'] if 'rate' in search_dic else 'RATE'
			# color=search_dic['color']
			sql_where = "select * FROM "+FUTURE_RECOMMENDATION_TABLE+" Where  AVG_PRICE!=0 and AUCTION_DATE > \""+current_date+"\"  and "
			# sql = sql_empty
			sql = sql_where
			if (make != "MAKE"):
				sql = sql+"MARKA_NAME = \""+make+"\""+" and "

			if (model != "MODEL"):
				sql = sql+"MODEL_NAME = \""+model+"\""+" and YEAR > 0 and "

			if (e_year != "YEAR"):
				sql = sql+"YEAR between "+s_year+" and "+e_year+" and "

			if (mileage != "MILEAGE"):
				mil_resp=mileage_converter(mileage," and ")
				if(mil_resp!="0 and 0"):
					sql = sql+"MILEAGE between "+mileage_converter(mileage," and ")+" and "
				else:
					sql = sql
				
			if (kuzov != "KUZOV"):
				sql = sql+"KUZOV = \""+kuzov+"\""+" and "

			if ('vehicle_grade' in search_dic):
				if(len(array_parram(search_dic,'vehicle_grade'))>0):
					sql = sql+"GRADE in ("+array_parram(search_dic,'vehicle_grade')+") and "
				else:
					sql = sql

			if ('rate' in search_dic):
				if(len(array_parram(search_dic,'rate'))>0):
					sql = sql+"RATE in ("+array_parram(search_dic,'rate')+") and "
				else:
					sql = sql

			if ('color' in search_dic):
				if(len(array_parram(search_dic,'color'))>0):
					sql = sql+"COLOR in ("+array_parram(search_dic,'color')+") and "
				else:
					sql = sql
			
			log.info("query for recomendations : " +str(sql[0:-4])+"order by AUCTION_DATE DESC ")
			cursor.execute(str(sql[0:-4])+"order by AUCTION_DATE DESC ")
			response_code = cursor.fetchall()
			print(response_code)
			print(response_code)
			if(len(response_code)>0):
				# params=list(response_code)
				log.info("Time taken to get recommendations from table :"+str(round(t.time()-start_time,2)))	 	
				return get_recommendations_html(response_code)
			else:
				log.info("Time taken to get recommendations from table :"+str(round(t.time()-start_time,2)))	
				return []
	except Exception as e :
		log.error(str(e))
		return []

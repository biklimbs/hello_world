﻿# Description: constants deals with details which are static data for entire application.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:



# MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
# MY_SQL_USER_NAME = 'root'
# MY_SQL_PASSWORD = 'Vmmobility@1234'
# MY_SQL_DB_NAME = 'cawm_rawdata'

#       Standard values
ADDITIONAL_EXCHANGE_RATE_TO_FREIGHT=3   # Adding this extra charge to exchange rate when calculating freight rate
SUBTRACTED_EXCHANGE_RATE_TO_CONVERSION=2    # Subtracting this charge from exchange rate when conversion of yen to USD
INCLUDED="Included"     #  When charge is included
NOT_INCLUDED="Not Included"     #  When charge is not included

#       Special countries 
NEWZEALNND="New Zealand" 
MALTA="Malta"
CYPRUS="Cyprus"

#       Server and db details 
HOST_NAME = 'mysqldb.stg.chanceworldautomall.com'
USER_NAME = 'vicibi'
PASSWORD = 'vicibi!46'
DB_NAME = 'cwam'
PORT=3307
CHARSET='utf8mb4'

#       Exchange rate url and token 
EXCHANGE_RATE_BASE_URL="www.apilayer.net"
EXCHANGE_RATE_TOKEN="0b38c70c-8803-0c19-1751-e0b87a3d6147"
EXCHANGE_RATE_ACCESS_KEY="60bc24f04535f40e551faf2ef4d42dcc"
EXCHANGE_RATE_EXTENSION_URL="/api/live?access_key="+EXCHANGE_RATE_ACCESS_KEY+"&format=1&base="
EXCHANGE_METHOD="GET"


#       SpotQuote API details 
# QUOTE_LAMBDA_URL="94lqsncnhj.execute-api.ap-south-1.amazonaws.com"
# QUOTE_LAMBDA_EXTENTION_URL="/staging/AutoWorldJapanGetPrice"
# QUOTE_LAMBDA_POSTMAN_TOKEN="20a60d25-97f8-83bd-8577-80ecbfb009bc"

QUOTE_LAMBDA_URL="49d98nf2r7.execute-api.ap-northeast-1.amazonaws.com"
QUOTE_LAMBDA_EXTENSION_URL="/api/v1/spotquote"
QUOTE_LAMBDA_POSTMAN_TOKEN="80a92761-81cc-e80e-f0b9-ad92d503f0e6"
QUOTE_LAMBDA_METHOD="POST"  


#       Table details 
HISTORY_TABLE='history'       #  Used in filling drop down list
TABLE_DISTINCT="quote_master" #  Used for drop downlist to details like make,model,year,chasis id,grade and eng_v (inorder to fast response time)
FUTURE_TABLE="future"         #  Used infetching data based on search and display in recommendations
VESSEL_TABLE="vessel"         #  Used to fill vessel drop down list 
CARDETAIL_TABLE="carDetails"  #  Used to get cbm value
FREIGHT_TABLE="freight"       #  Used to get freight charge
INSPECTION_TABLE="inspection" #  Used to get inspection fee
LETTEROFCREDIT_TABLE="lc"     #  Used to get lc charge
CONSTANT_TABLE="constant"     #  Used to get charges like forwardvanning
COUNTRY_TABLE="country"       #  Used to get countries
PORT_TABLE="port"             #  Used to get ports
MAKE_MODEL_TABLE="history"    #  Used to get make and model based on count.(For returning top 15 makes amd models)

#       Special countries slab rate 
MALTA_SLAB_RATE=70000       #  Fixed slab rate for malta
NEW_ZEALAND_SLAB_RATE=70000 #  Fixed slab rate for newzealand
CYPRUS_SLAB_RATE=180000     #  Fixed slab rate for cyprus

#       Live exchange rate
EXCHANGE_RATE=0     #  To store live exchange rate

#       Standard charges 
STANDARD_MISC_CHARGE=5000       #  Fixed miscellaneous charge
STANDARD_MARGIN_PERCENTAGE=8    #  Fixed magin %
PRICE_DIFF=500000               #  Price difference to get slab rate 
INSURANCE=5000                  #  Fixed insurance fee

#       CSV file details (used in storing and retrieving history details) 
HISTORY_CSV_FILE="history.csv"                      #  Csv file name
CSV_FOLDER_DIR="./"                                 #  Csv folder directory
CSV_FOLDER="history_view/csv"                     #  Csv folder path  
# CSV_FOLDER="src/front_end/V-4.0/history_view/csv"   #  Csv folder path

#-------------------------- Display tags for standards-------------
# DISPLAY_TERMS=['bidPrice','auctionFee','inspectionfee','transportFee','forwordingVanning','LCCharge','oceanFreight','margin','misl_charge']

# #-------------------------- Tags for standards to be shown with charges-------------
# DISPLAY_TERMS_SHOWN=["bidPrice","oceanFreight"]

# #-------------------------- Tags for standards to hide charges-------------
# DISPLAY_TERMS_HIDDEN=["transportFee","inspectionfee","forwordingVanning","LCCharge","margin","misl_charge","auctionFee"]
# TAG_DIC={"bidPrice":AVG_TAG,"auctionFee":AUCTION_TAG,"oceanFreight":FREIGHT_TAG,"transportFee":TRANSPORT_TAG,"inspectionfee":INSPECTION_TAG,"forwordingVanning":FORWORDVANNING_TAG,"LCCharge":LC_CHARGE_TAG,"margin":MARGIN_TAG,"misl_charge":MISL_TAG}

#       Display tags for quote price 
COUNTRY_TAG=        "Country            : "
PORT_TAG=           "Port               : "
VESSEL_TAG=         "Vessel             : "
MAKE_TAG=           "Make               : "
MODEL_TAG=          "Model              : "
CHASSIS_TAG=        "Chassis ID         : "
YEAR_TAG=           "Year               : "
MILEAGE_TAG=        "Mileage            : "
GRADE_TAG=          "Vehicle Grade      : "
ENGINE_CC_TAG=      "Engine CC          : "
RATE_TAG=           "Grade              : "
COLOR_TAG=          "Color              : "

DATA_COUNT_TAG=     "Data point count   : "

AVG_TAG=            "Average Price      : "
AUCTION_TAG=        "Auction Fee        : "
FREIGHT_TAG=        "Ocean Freight      : "
TRANSPORT_TAG=      "Transport Cost     : "
INSPECTION_TAG=     "Inspection Fee     : "
FORWORDVANNING_TAG= "Forwarding/Vanning : "
LC_CHARGE_TAG=      "LC Charge          : "
MARGIN_TAG=         "Margin             : "
MISL_TAG=           "Miscellaneous Fee  : "
INSURANCE_TAG=      "Insurance Fee      : "
SLAB_TAG=           "Slab Rate          : "

FOB_TAG="FOB        : "
CNF_TAG="C&F        : "
CIF_TAG="CIF        : "

#       PDF details 
#       Deployment path (Enable when project go to deployment/Disable when running local system level) 
# PDF_FILE_NAME="src/front_end/V-4.0/static/pdf/"     #  PDF file path
# PDF_FILE_NAME_EMAIL="src/front_end/V-4.0/mail/"     #  PDF file path to send in mail
# PDF_LOGO="src/front_end/V-4.0/static/pdf/logo.jpg"  #  PDF logo image path
# PDF_SIGN="src/front_end/V-4.0/static/pdf/sign.jpg"  #  PDF sing image path

      # Local path (Enable when running local system level/Disable when project go to deployment) 
PDF_FILE_NAME="static/pdf/"
PDF_FILE_NAME_EMAIL="mail/"
PDF_LOGO="static/pdf/logo.jpg"
PDF_SIGN="static/pdf/sign.jpg"


#       Invoice header color
HEADER_RED=205          
HEADER_GREEEN=205   
HEADER_BLUE=205


#--Constants for recommendations---
#---Server credentials---
HOST_SPARK= "spark.vmokshagroup.com"
USER_SPARK="root"
PASSWORD_SPARK="Vmmobility@1234"
SOURCE_DATABASE_SPARK='recommendation_model'
FUTURE_RECOMMENDATION_TABLE="future_recommendation_preprocess"

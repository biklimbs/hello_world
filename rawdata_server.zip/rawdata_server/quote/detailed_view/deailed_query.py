# Description: detailed_query deals with fetching records from table related to selection criterion.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:

from main_view.sql_helper import *    
import main_view.logger_config 
from main_view.logger_config import *
from .detailed_html import *
import os

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		To get rows which are responsibleto create Detailed view Html based on user selection and used to show in detailed view        
def get_Detailed_view(search_dic):
	try:
		connection_to_db=connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			company=search_dic['company']
			model=search_dic['model']
			s_year=search_dic['s_year']
			e_year=search_dic['e_year']
			if('mileage' in search_dic):
				mileage=search_dic['mileage']
			else:
				mileage="MILEAGE"
			kuzov=search_dic['kuzov']
			sql_where = "select * FROM "+HISTORY_TABLE+" Where AUCTION not like 'JU%' and FINISH != 0 and STATUS not in ('NOT SOLD','CANCELLED','Not Sold','')  and  "
					# sql = sql_empty
			if (company == "" and model == "" and s_year == "" and e_year == "" and mileage == "" and kuzov == ""):
				#sql = sql_empty
				price = 0
				success = False
				message = "No Configuration Selected."
				return price, success, message
			else:
				sql = sql_where
				if (company != "MAKE"):
					sql = sql+"MARKA_NAME = \""+company+"\""+" and "

				if (model != "MODEL"):
					sql = sql+"MODEL_NAME = \""+model+"\""+" and "

				if (e_year != "YEAR"):
					sql = sql+"YEAR between "+s_year+" and "+e_year+" and "

				if (mileage != "MILEAGE"):
					mil_resp=mileage_converter(mileage," and ")
					if(mil_resp!="0 and 0"):
						sql = sql+"MILEAGE between "+mileage_converter(mileage," and ")+" and "
					else:
						sql = sql
					
				if (kuzov != "KUZOV"):
					sql = sql+"KUZOV = \""+kuzov+"\""+" and "

				if ('rate' in search_dic):
					if(len(array_parram(search_dic,'rate'))>0):
						sql = sql+"RATE in ("+array_parram(search_dic,'rate')+") and "
					else:
						sql = sql

				if ('color' in search_dic):
					if(len(array_parram(search_dic,'color'))>0):
						sql = sql+"COLOR in ("+array_parram(search_dic,'color')+") and "
					else:
						sql= sql

				cursor.execute(str(sql[0:-4]).replace('*',"AUCTION,AVG_PRICE,COLOR,ENG_V,EQUIP,FINISH,KPP,KUZOV,MARKA_NAME,MILEAGE,MODEL_NAME,PRIV,RATE,YEAR"))
				response_code = cursor.fetchall()
				# table_formated(response_code)
	except Exception as e:
		log.info(str(e))
		print(e)
	return table_formated(response_code),str(len(response_code))

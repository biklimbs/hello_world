import pymysql.cursors
import pandas as pd
from datetime import datetime
import time as t
import traceback
import os
import sys
import random
import urllib.request
import warnings
warnings.filterwarnings('ignore')
# from fake_useragent import UserAgent
from termcolor import colored
try:
	from recommedation.logger_config import log
	#from logger_config import log
	# import logger_config
except:
	print("logger_config.py file not found.")

try:
	from recommedation.constants import *
	#from constants import *
except:
	print("constants.py file not found.")




def connect_to_db(host, user, password, db):
	connection = 0
	while (connection == 0):
		try:
			connection = pymysql.connect(host=host,
                                user=user,
                                password=password,
                                db=db,
                                charset='utf8mb4',
                                cursorclass=pymysql.cursors.DictCursor)
		except Exception as e:
			print(e)
			t.sleep(5)

	return connection


def check_if_Table_exits(connection_to_db, table):
	try:
		with connection_to_db.cursor() as db_cursor:
			sql_query = "desc "+table+" ;"
			db_cursor.execute(sql_query)
			table_check_result = db_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		print(e)
		# traceback.print_stack()
		return False


def fetch_all_data():

	empty_df = pd.DataFrame()
	current_date = datetime.now()
	current_date, temp = str(current_date).split('.')

	try:
		connection = connect_to_db(
			MY_SQL_HOST_NAME, MY_SQL_USER_NAME, MY_SQL_PASSWORD, MY_SQL_DB_NAME)
		if(check_if_Table_exits(connection, TABLE) != True):

			return empty_df, "Table "+TABLE+" is not in the "+MY_SQL_DB_NAME+" Database.", False
		# connection_to_db.set_character_set('utf8')
	except Exception as e:

		print("Database "+MY_SQL_DB_NAME+" connection not established.")
		return empty_df, "Database "+MY_SQL_DB_NAME+" connection not established.", False

	try:

		price = 0
		success = False
		message = ""
		# connection = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		sql = "select * FROM "+TABLE + \
			" Where AUCTION_DATE > \'"+str(current_date)+"\' and AVG_PRICE>0;"

		print(sql)
		# sys.exit()

		with connection.cursor() as db_cursor:
			# sql="select FINISH FROM "+TABLE+" where MARKA_NAME='"+company+"' and MODEL_NAME ='"+model+"' and YEAR >="+year+" and MILEAGE>="+mileage+" and KUZOV =\""+kuzov+"\" and  AUCTION not like 'USS%' and FINISH != 0;"
			db_cursor.execute(sql)
			car_details = db_cursor.fetchall()
			car_details = pd.DataFrame(car_details)
	except Exception as e:
		print(str(e))
		return empty_df, "Error in creating query...", False
		# traceback.print_exc()
	return car_details, sql, True



def fetch_data(company, model):

	empty_df = pd.DataFrame()
	current_date = datetime.now()
	current_date, temp = str(current_date).split('.')

	try:
		connection = connect_to_db(
			MY_SQL_HOST_NAME, MY_SQL_USER_NAME, MY_SQL_PASSWORD, MY_SQL_DB_NAME)
		if(check_if_Table_exits(connection, TABLE) != True):

			return empty_df, "Table "+TABLE+" is not in the "+MY_SQL_DB_NAME+" Database.",False
		# connection_to_db.set_character_set('utf8')
	except Exception as e:

		print("Database "+MY_SQL_DB_NAME+" connection not established.")
		return empty_df, "Database "+MY_SQL_DB_NAME+" connection not established.",False

	try:
		
		price = 0
		success = False
		message = ""
		# connection = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		sql = "select * FROM "+TABLE+" Where AUCTION_DATE > \"" + \
			str(current_date)+"\" and AVG_PRICE>0 and "
		
		
		if (company != ""):
			sql = sql+"MARKA_NAME = \""+company+"\""+" and "

		if (model != ""):
			sql = sql+"MODEL_NAME = \""+model+"\""+" and "

		sql = sql[0:-4]
		print(sql)
		# sys.exit()

		with connection.cursor() as db_cursor:
			# sql="select FINISH FROM "+TABLE+" where MARKA_NAME='"+company+"' and MODEL_NAME ='"+model+"' and YEAR >="+year+" and MILEAGE>="+mileage+" and KUZOV =\""+kuzov+"\" and  AUCTION not like 'USS%' and FINISH != 0;"
			db_cursor.execute(sql)
			car_details = db_cursor.fetchall()
			car_details= pd.DataFrame(car_details)
	except Exception as e:
		print(str(e))
		return empty_df, "Error in creating query...",False
		# traceback.print_exc()
	return car_details, sql,True


def filter_with_all(recmd_df, year,mileage_range, kuzov, veh_grade, veh_cc, rate, color):
	try:
		#  year 
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] == int(year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of YEAR...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['MILEAGE'] == int(mileage_range))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'] == str(rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['GRADE'] == str(veh_grade))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of GRADE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['COLOR'] == str(color))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of COLOR...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['ENG_V'] == str(veh_cc))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of ENG_V...", 'cyan'))

		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc(recmd_df, year,mileage_range, kuzov, veh_grade, rate, color):
	try:
		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] == int(year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of YEAR...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['MILEAGE'] == int(mileage_range))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'] == str(rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['GRADE'] == str(veh_grade))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of GRADE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['COLOR'] == str(color))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of COLOR...", 'cyan'))


		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color(recmd_df, year,
                    mileage_range, kuzov, veh_grade, rate):
	try:
		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] == int(year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of YEAR...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['MILEAGE'] == int(mileage_range))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'] == str(rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['GRADE'] == str(veh_grade))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of GRADE...", 'cyan'))


		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color_mil_mod(recmd_df, year,
                            mileage_range, kuzov, veh_grade, rate):
	try:
		start_mileage = int(mileage_range)-LIMIT_MIL
		end_mileage = int(mileage_range)+LIMIT_MIL

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] == int(year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of YEAR...", 'cyan'))

		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['MILEAGE'] >= int(
			start_mileage)) & (recmd_df['MILEAGE'] <= int(end_mileage))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'] == str(rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['GRADE'] == str(veh_grade))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of GRADE...", 'cyan'))

		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color_mil_yr_mod(recmd_df, year,
                                    mileage_range, kuzov, veh_grade, rate):
	try:
		start_mileage = int(mileage_range)-LIMIT_MIL
		end_mileage = int(mileage_range)+LIMIT_MIL

		start_year = int(year)-LIMIT_YR
		end_year = int(year)+LIMIT_YR

		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] >= int(
			start_year)) & (recmd_df['YEAR'] <= int(end_year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['MILEAGE'] >= int(
			start_mileage)) & (recmd_df['MILEAGE'] <= int(end_mileage))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'] == str(rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['GRADE'] == str(veh_grade))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of GRADE...", 'cyan'))

		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color_mil_yr_rate_mod(recmd_df, year,
                                       mileage_range, kuzov, veh_grade, rate):
	try:
		start_mileage = int(mileage_range)-LIMIT_MIL
		end_mileage = int(mileage_range)+LIMIT_MIL

		start_year = int(year)-LIMIT_YR
		end_year = int(year)+LIMIT_YR

		list_rate = []
		try:
			index_rate= RATE_LIST.index(rate)
			# print(index_rate)

			
			if index_rate >0:
				if index_rate < len(RATE_LIST):
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
					list_rate.append(RATE_LIST[index_rate+1])
				else:
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
			else:
				list_rate.append(RATE_LIST[index_rate])
				list_rate.append(RATE_LIST[index_rate+1])

			# print(list_rate)
			
		except Exception as e:
			print(str(e))
			traceback.print_exc()
			list_rate.append(rate)

		# sys.exit()
		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] >= int(
			start_year)) & (recmd_df['YEAR'] <= int(end_year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['MILEAGE'] >= int(
			start_mileage)) & (recmd_df['MILEAGE'] <= int(end_mileage))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'].isin(list_rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['GRADE'] == str(veh_grade))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of GRADE...", 'cyan'))

		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color_grade_mil_yr_rate_mod(recmd_df, year,
                                            mileage_range, kuzov, rate):
	try:
		start_mileage = int(mileage_range)-LIMIT_MIL
		end_mileage = int(mileage_range)+LIMIT_MIL

		start_year = int(year)-LIMIT_YR
		end_year = int(year)+LIMIT_YR

		list_rate = []
		try:
			index_rate = RATE_LIST.index(rate)
			# print(index_rate)

			if index_rate > 0:
				if index_rate < len(RATE_LIST):
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
					list_rate.append(RATE_LIST[index_rate+1])
				else:
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
			else:
				list_rate.append(RATE_LIST[index_rate])
				list_rate.append(RATE_LIST[index_rate+1])

			# print(list_rate)

		except Exception as e:
			print(str(e))
			traceback.print_exc()
			list_rate.append(rate)

		# sys.exit()
		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] >= int(
			start_year)) & (recmd_df['YEAR'] <= int(end_year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of year...", 'cyan'))

		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['MILEAGE'] >= int(
			start_mileage)) & (recmd_df['MILEAGE'] <= int(end_mileage))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of MILEAGE...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'].isin(list_rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))


		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color_grade_mil_mil_yr_rate_mod(recmd_df, year,
                                                  kuzov, rate):
	try:
		# start_mileage = int(mileage_range)-LIMIT_MIL
		# end_mileage = int(mileage_range)+LIMIT_MIL

		start_year = int(year)-LIMIT_YR
		end_year = int(year)+LIMIT_YR

		list_rate = []
		try:
			index_rate = RATE_LIST.index(rate)
			# print(index_rate)

			if index_rate > 0:
				if index_rate < len(RATE_LIST):
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
					list_rate.append(RATE_LIST[index_rate+1])
				else:
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
			else:
				list_rate.append(RATE_LIST[index_rate])
				list_rate.append(RATE_LIST[index_rate+1])

			# print(list_rate)

		except Exception as e:
			print(str(e))
			traceback.print_exc()
			list_rate.append(rate)

		# sys.exit()
		# Start mileage and end mileage
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['YEAR'] >= int(
			start_year)) & (recmd_df['YEAR'] <= int(end_year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of Year...", 'cyan'))


		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'].isin(list_rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV in mileage removed...", 'cyan'))

		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color_grade_mil_yr_mil_yr_rate_mod(recmd_df,
                                                      kuzov, rate):
	try:
		# start_mileage = int(mileage_range)-LIMIT_MIL
		# end_mileage = int(mileage_range)+LIMIT_MIL

		# start_year = int(year)-LIMIT_YR
		# end_year = int(year)+LIMIT_YR

		list_rate = []
		try:
			index_rate = RATE_LIST.index(rate)
			# print(index_rate)

			if index_rate > 0:
				if index_rate < len(RATE_LIST):
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
					list_rate.append(RATE_LIST[index_rate+1])
				else:
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
			else:
				list_rate.append(RATE_LIST[index_rate])
				list_rate.append(RATE_LIST[index_rate+1])

			# print(list_rate)

		except Exception as e:
			print(str(e))
			traceback.print_exc()
			list_rate.append(rate)

		# sys.exit()
		# Start mileage and end mileage
		# print(len(recmd_df))
		# recmd_df = recmd_df.loc[(recmd_df['YEAR'] >= int(
		# 	start_year)) & (recmd_df['YEAR'] <= int(end_year))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of Year...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['RATE'].isin(list_rate))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of rate...", 'cyan'))

		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_without_cc_color_grade_mil_yr_rate_mil_yr_rate_mod(recmd_df,
                                                         kuzov):
	try:
		# start_mileage = int(mileage_range)-LIMIT_MIL
		# end_mileage = int(mileage_range)+LIMIT_MIL

		# start_year = int(year)-LIMIT_YR
		# end_year = int(year)+LIMIT_Y


		#  year
		# print(len(recmd_df))
		recmd_df = recmd_df.loc[(recmd_df['KUZOV'] == str(kuzov))]
		# print(len(recmd_df))
		# log.info(colored("Filtered on basis of KUZOV...", 'cyan'))

		return recmd_df, True

	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def get_filtered_data(recmd_df, year,
                      mileage_range, kuzov, veh_grade, veh_cc, rate, color):
	try:
		if len(recmd_df) > LIMIT_COUNT:
			log.info(colored("Filtering with all parameters...", 'cyan'))
			recmd_df_modf,status= filter_with_all(recmd_df, year,
						mileage_range, kuzov, veh_grade, veh_cc, rate, color)

			if status==True:
				if len(recmd_df_modf) > LIMIT_COUNT:
					return recmd_df_modf, True
				else:
					log.info(colored("Filtering without cc...", 'cyan'))
					recmd_df_modf, status = filter_without_cc(recmd_df, year,
												mileage_range, kuzov, veh_grade, rate, color)
					if status == True:
						if len(recmd_df_modf) > LIMIT_COUNT:
							return recmd_df_modf, True
						else:
							log.info(colored("Filtering without cc and color...", 'cyan'))
							recmd_df_modf, status = filter_without_cc_color(recmd_df, year,
															mileage_range, kuzov, veh_grade, rate)
							if status == True:
								if len(recmd_df_modf) > LIMIT_COUNT:
									return recmd_df_modf, True
								else:
									log.info(colored("Filtering without cc , color and modified mileage...", 'cyan'))
									recmd_df_modf, status = filter_without_cc_color_mil_mod(recmd_df, year,
																	mileage_range, kuzov, veh_grade, rate)
									if status == True:
										if len(recmd_df_modf) > LIMIT_COUNT:
											return recmd_df_modf, True
										else:
											log.info(colored("Filtering without cc, color, and modified mileage and year...", 'cyan'))
											recmd_df_modf, status = filter_without_cc_color_mil_yr_mod(recmd_df, year,
																			mileage_range, kuzov, veh_grade, rate)
											if status == True:
												if len(recmd_df_modf) > LIMIT_COUNT:
													return recmd_df_modf, True
												else:
													log.info(colored(
														"Filtering without cc, color, and modified mileage and year and rate...", 'cyan'))
													recmd_df_modf, status = filter_without_cc_color_mil_yr_rate_mod(recmd_df, year,
																								mileage_range, kuzov, veh_grade, rate)
													if status == True:
														if len(recmd_df_modf) > LIMIT_COUNT:
															return recmd_df_modf, True
														else:
															log.info(colored(
																"Filtering without cc, color, grade and modified mileage and year and rate...", 'cyan'))
															recmd_df_modf, status = filter_without_cc_color_grade_mil_yr_rate_mod(recmd_df, year,
																													mileage_range, kuzov, rate)
															if status == True:
																if len(recmd_df_modf) > LIMIT_COUNT:
																	return recmd_df_modf, True
																else:
																	log.info(colored(
																		"Filtering without cc, color, grade, mileage and modified mileage and year and rate...", 'cyan'))
																	recmd_df_modf, status = filter_without_cc_color_grade_mil_mil_yr_rate_mod(recmd_df, year,
																																	kuzov, rate)
																	if status == True:
																		if len(recmd_df_modf) > LIMIT_COUNT:
																			return recmd_df_modf, True
																		else:
																			log.info(colored(
																				"Filtering without cc, color, grade, mileage, year and modified mileage and year and rate...", 'cyan'))
																			recmd_df_modf, status = filter_without_cc_color_grade_mil_yr_mil_yr_rate_mod(recmd_df,
																																					kuzov, rate)
																			if status == True:
																				if len(recmd_df_modf) > LIMIT_COUNT:
																					return recmd_df_modf, True
																				else:
																					log.info(
																						colored("Filtering without cc, color, grade, mileage, year, rate and modified mileage and year and rate...", 'cyan'))
																					recmd_df_modf, status = filter_without_cc_color_grade_mil_yr_rate_mil_yr_rate_mod(recmd_df,
																																									kuzov)
																					if status == True:
																						if len(recmd_df_modf) > LIMIT_COUNT:
																							return recmd_df_modf, True
																						else:
																							return recmd_df, True
																					else:
																						return recmd_df, True
																			else:
																				return recmd_df, True
																	else:
																		return recmd_df, True
															else:
																return recmd_df, True
													else:
														return recmd_df, True
											else:
												return recmd_df, True
									else:
										return recmd_df, True
							else:
								return recmd_df, True
					else:
						return recmd_df, True
			else:
				return recmd_df, True
		else:
			return recmd_df, True
	except Exception as e:
		print(str(e))
		traceback.print_exc()
		return recmd_df, False


def filter_make_df(make_df, mileage_range, rate, year):
	try:

		start_mileage = int(mileage_range)-LIMIT_MIL
		end_mileage = int(mileage_range)+LIMIT_MIL

		start_year = int(year)-LIMIT_YR_MAKE
		end_year = int(year)+LIMIT_YR_MAKE


		list_rate = []
		try:
			index_rate = RATE_LIST.index(rate)
			# print(index_rate)

			if index_rate > 0:
				if index_rate < len(RATE_LIST):
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
					list_rate.append(RATE_LIST[index_rate+1])
				else:
					list_rate.append(RATE_LIST[index_rate])
					list_rate.append(RATE_LIST[index_rate-1])
			else:
				list_rate.append(RATE_LIST[index_rate])
				list_rate.append(RATE_LIST[index_rate+1])

			# print(list_rate)

		except Exception as e:
			print(str(e))
			traceback.print_exc()
			list_rate.append(rate)

		# print(make_df)

		make_df_new = make_df.loc[(make_df['YEAR'] >= int(
			start_year)) & (make_df['YEAR'] <= int(end_year))]
		# print(make_df_new)
		if make_df_new.empty or len(make_df_new)<2:
			return make_df, True
		else:
			make_df_new_1 = make_df_new.loc[(make_df_new['MILEAGE'] >= int(
                            start_mileage)) & (make_df_new['MILEAGE'] <= int(end_mileage))]
			# print(make_df_new_1)
			if make_df_new_1.empty or len(make_df_new_1) < 2:
				return make_df_new, True
			
			else:
				make_df_new_2 = make_df_new_1.loc[(
					make_df_new_1['RATE'].isin(list_rate))]
				# print(make_df_new_2)
				if make_df_new_2.empty or len(make_df_new_2) < 2:
					return make_df_new_1, True
				else:
					return make_df_new_2, True

	except Exception as e:
		print(str(e))
		return make_df, True


def get_recommend_cars_with_orig_make(make, model,year,
                                      mileage_range, kuzov, veh_grade, veh_cc, rate, color):
	try:
		recmd_df,resp, status= fetch_data(make, model)
		print(recmd_df["YEAR"].head())
		print(len(recmd_df))
		# sys.exit()
		if status==True:
			recmd_df_mod, status= get_filtered_data(recmd_df, year,
						mileage_range, kuzov, veh_grade, veh_cc, rate, color)

			recmd_df_mod= recmd_df_mod[["AUCTION_DATE","AUCTION","MARKA_NAME","MODEL_NAME","YEAR","MILEAGE","KUZOV","GRADE","ENG_V","RATE","COLOR","s3_front_images","AVG_PRICE"]].head()
			recmd_df_mod = recmd_df_mod.reset_index(drop=True)
			return recmd_df_mod, True
		else:
			return pd.DataFrame(), False
	except Exception as e:
		print(str(e))
		return pd.DataFrame(), False

def get_recommend_cars_with_avg_price(make_name, future_df, avg_price):
	try:
		max_avg_price = int(avg_price)+LIMIT_AVG_PRICE
		min_avg_price = int(avg_price)-LIMIT_AVG_PRICE

		future_df= future_df.loc[future_df["MARKA_NAME"] == make_name]
		future_df= future_df.loc[((future_df["AVG_PRICE"] < max_avg_price) & (
			future_df["AVG_PRICE"] > min_avg_price))]
		future_df= future_df[["AUCTION_DATE","AUCTION","MARKA_NAME", "MODEL_NAME", "YEAR", "MILEAGE",
                    "KUZOV", "GRADE", "ENG_V", "RATE", "COLOR","s3_front_images", "AVG_PRICE"]].head()
		future_df = future_df.reset_index(drop=True)
		# print(future_df)
		# sys.exit()
		return future_df, True
	except Exception as e:
		print(str(e))
		return pd.DataFrame(), False

def get_recommend_cars(make, model, year,
                       mileage_range, kuzov, veh_grade, veh_cc, rate, color, avg_price):
	try:
		if "-" in mileage_range:
				start_mileage, end_mileage = mileage_range.split("-")
				mileage_range=(int(start_mileage)+int(end_mileage))/2
				mileage_range=str(mileage_range)
		else:
			pass
		final_recmnd_df=pd.DataFrame()
		future_df,resp, status= fetch_all_data()

		if status==True:

			
			# make_counts=future_df["MARKA_NAME"].value_counts()
			# print(make_counts)
			alike_make_list=[]
			if make in MAKE_LIST:
				print(make)
				recmd_df_mod, status = get_recommend_cars_with_orig_make(make, model, year,
																mileage_range, kuzov, veh_grade, veh_cc, rate, color)
				if status == True:
					final_recmnd_df = final_recmnd_df.append(recmd_df_mod)
				else:
					pass

				for index in MAKE_DICT:
					if make in MAKE_DICT[index]:
						cat_make_list = MAKE_DICT[index]
						cat_make_list=list(cat_make_list)
						cat_make_list.remove(make)
						# print(cat_make_list)
						alike_make_list= cat_make_list.copy()
						print(alike_make_list)
					else:
						pass
				for make_name in alike_make_list:
					make_df, status= get_recommend_cars_with_avg_price(make_name, future_df, avg_price)
					if status==True:
						# here filter with the rate and year
						make_df, status = filter_make_df(make_df, mileage_range, rate, year)
						final_recmnd_df=final_recmnd_df.append(make_df.head(2))
					else:
						pass
				final_recmnd_df = final_recmnd_df.reset_index(drop=True)
				print(final_recmnd_df)
				if final_recmnd_df.empty:
					final_recmnd_json= final_recmnd_df.to_json(orient='records')
					print(final_recmnd_json)
					return final_recmnd_json, False
				else:
					final_recmnd_json = final_recmnd_df.to_json(orient='records')
					print(final_recmnd_json)
					return final_recmnd_json, True
				# sys.exit()
			else:
				# sys.exit()
				recmd_df_mod, status = get_recommend_cars_with_orig_make(make, model, year,
                                                             mileage_range, kuzov, veh_grade, veh_cc, rate, color)

				if status== True:
					final_recmnd_df = final_recmnd_df.append(recmd_df_mod)
					print(final_recmnd_df)
					final_recmnd_json = final_recmnd_df.to_json(orient='records')
					return final_recmnd_json, True
				else:
					empty_df = pd.DataFrame()
					final_recmnd_json = empty_df.to_json(orient='records')
					return final_recmnd_json, False
					
				
		else:
			empty_df = pd.DataFrame()
			final_recmnd_json = empty_df.to_json(orient='records')
			return final_recmnd_json, False
	except Exception as e:
		print(str(e))
		traceback.print_exc()
		empty_df = pd.DataFrame()
		final_recmnd_json = empty_df.to_json(orient='records')
		return final_recmnd_json, False



def main():
	try:
		make = "TOYOTA"
		model = "AQUA"
		year = '2016'
		mileage = '20000'
		kuzov = 'NHP10'
		veh_grade = ""
		veh_cc=""
		rate="3.5"
		color=""
		avg_price="175000"
		get_recommend_cars(make, model, year,
                     mileage, kuzov, veh_grade, veh_cc, rate, color, avg_price)
	except Exception as e:
		print(str(e))

if __name__ == "__main__":
	main()

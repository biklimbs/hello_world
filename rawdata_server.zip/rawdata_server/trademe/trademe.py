import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import requests
import time as t
import pymysql.cursors
import pandas as pd
import json
from flask import Flask, render_template, request,Response,redirect,url_for,Markup,jsonify

#----------------------- Server and db details -----------------
HOST_NAME = 'spark.vmokshagroup.com'
USER_NAME = 'root'
PASSWORD = 'Vmmobility@1234'
DB_NAME = 'trademe_data'
CHARSET='utf8mb4'
SCRAP_TABLE='scrap_data'


#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_to_db=0
	while (connection_to_db==0):
		try:
			connection_to_db = pymysql.connect(host=host,
				user=user,
				password=password,
				db=db,
				charset=CHARSET,
				cursorclass=pymysql.cursors.DictCursor)
		except Exception as e:
			print(str(e))
			t.sleep(30)
	return connection_to_db


#-----------To get distinct dealers  ----------      
def get_delalers():
	try:
		dealers_list=[]
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			sql="SELECT distinct dealer_name as dealers FROM "+SCRAP_TABLE+" order by dealers;"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			if(len(response_code)>0):
				dealers=sorted(list(pd.DataFrame(response_code)['dealers']))
				for dealer in dealers:
					dealers_list.append(dealer)
				return dealers_list
			else:
				return []
	except Exception as e :
		print(str(e))
		return []

#-----------To get whole records available based on dealer  ----------      
def get_car_details(dealer):
	res_error=""
	try:
		dealers_dic={}
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			sql="SELECT * FROM "+SCRAP_TABLE+" where dealer_name=\""+dealer+"\";"
			cursor.execute(sql)
			response_code = cursor.fetchall()
			res=""
			print(len(response_code))
			for row in response_code:
				make,model,year,title,kms,body,fuel,eng_cc,model_detail,transmission,price,url,date_of_listing=table_details(row)			
				res="<tr bgcolor='#99ddff' ><td style=\"width: 102px\">"+make+"</td><td style=\"width: 102px\">"+model+"</td><td style=\"width: 102px\">"+year+"</td><td style=\"width: 102px\">"+title+"</td><td style=\"width: 102px\">"+kms+"</td><td style=\"width: 102px\">"+body+"</td><td style=\"width: 102px\">"+fuel+"</td><td style=\"width: 104px\">"+eng_cc+"</td><td style=\"width: 103px\">"+model_detail+"</td><td style=\"width: 103px\">"+transmission+"</td><td style=\"width: 103px\">"+str(price)+"</td><td style=\"width: 304px\">"+"<a href='"+url+"' style=\"display: block;text-decoration: none;\" target=\"_blank\"><p>"+url+"</p></a>"+"</td><td style=\"width: 102px\">"+date_of_listing+"</td></tr>"+res
				res_error="<tr bgcolor='#99ddff' ><td style=\"width: 102px\">"+make+"</td><td style=\"width: 102px\">"+model+"</td><td style=\"width: 102px\">"+year+"</td><td style=\"width: 102px\">"+title+"</td><td style=\"width: 102px\">"+kms+"</td><td style=\"width: 102px\">"+body+"</td><td style=\"width: 102px\">"+fuel+"</td><td style=\"width: 104px\">"+eng_cc+"</td><td style=\"width: 103px\">"+model_detail+"</td><td style=\"width: 103px\">"+transmission+"</td><td style=\"width: 103px\">"+str(price)+"</td><td style=\"width: 304px\">"+"<a href='"+url+"' style=\"display: block;text-decoration: none;\"><p>"+url+"</p></a>"+"</td><td style=\"width: 102px\">"+date_of_listing+"</td></tr>"
				dealers_dic['phone']=str(row['phone']) 
				dealers_dic['address']=str(row['address']) 
				dealers_dic['websitelink']=str(row['websitelink']) 
				dealers_dic['location']=str(row['location']) 
				dealers_dic['table']=str(res)
			return dealers_dic
	except Exception as e :
		print(str(res_error))
		return {}

#-----------To return parameters after validating with NULL or not for all fields  ----------      
def table_details(row):
	try:
		price=validate_price(row)
		make=str(row['make']) if(row['make']!=None) else "Null"
		model=str(row['model']) if(row['model']!=None) else "Null"
		year=str(row['year']) if(row['year']!=None) else "Null"
		title=str(row['title'].encode('ascii', 'ignore')) if(row['title']!=None) else "Null"
		kms=str(row['kilometres']) if(row['kilometres']!=None) else "Null"
		body=str(row['body'])  if(row['body']!=None) else "Null"
		fuel=str(row['fuel_type']) if(row['fuel_type']!=None) else "Null"
		eng_cc=str(row['engine_size']) if(row['engine_size']!=None) else "Null"
		model_detail=str(row['model_detail'].encode('ascii', 'ignore')) if(row['model_detail']!=None) else "Null"
		transmission=str(row['transmission']) if(row['transmission']!=None) else "Null"
		url=str(row['url']) if(row['url']!=None) else "Null"
		date_of_listing=str(row['listed_date']) if(row['listed_date']!=None) else "Null"

		return make,model,year,title,kms,body,fuel,eng_cc,model_detail,transmission,price,url,date_of_listing
	except Exception as e:
		print (str(e))
		return ""

#-----------To return price value with on road included or not  ----------      
def validate_price(row):
	try:
		price=row['price']
		included_not=str(row['on_road'])
		
		if(included_not=="Included"):
			if(price!=None and str(price)!="unknown"):
				return str(row['price'])+" "+"On road cost included"
			else:
				return "Null"
		else:
			if(price!=None and str(price)!="unknown"):
				return str(row['price'])
			else:
				return "Null"
	except Exception as e:
		price(str(e))
		return "Null"




#--------------- Flask tasks starts from here ---------

app = Flask(__name__,static_url_path='/static')

#-----------Page loads on lanch of application  ----------    
@app.route("/", methods = ["GET",'POST'])
def index():
	try:
		return render_template("index.html")
	except Exception as e:
		# print("--------------------------")
		print(str(e))
		return 'something went wrong : '+str(e)


#-----------Calls to get whole dealers avialable in table ----------    
@app.route('/dealer', methods=["POST"])
def convert_dealer_list_to_json():
	try:
		# print(request.form)
		return jsonify(get_delalers())
	except Exception as e:
		print(str(e))

#-----------Calls to get records available in table based on dealer selected ----------    
@app.route('/detail', methods=["POST"])
def details():
	try:
		request_dic=request.form
		response=get_car_details(str(request_dic['dealer']))
		# print(str(response))
		return jsonify(response)
	except Exception as e:
		print(str(e))
		

#----------- apllication start point ----------    
if __name__ == "__main__":
	app.run(host='0.0.0.0' ,port=89)

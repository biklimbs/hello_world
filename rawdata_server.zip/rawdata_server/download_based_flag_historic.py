import datetime
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import time as t
import json
from time import sleep
from datetime import datetime, time
from logger_config import log
from datetime import date, timedelta
import random
from termcolor import colored
import requests
MY_SQL_HOST_NAME = '172.16.10.6'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME_historic = 'cawm_rawdata'
MY_SQL_DB_NAME_flag = 'cawm_download_plan'


TABLE='history'
DOWNLOADFLAGTABLE='download_plan_historic'
BASE_URL="http://75.125.226.218/xml/json?&ip=10.10.0.0&code=y19Hfrte_Dm&sql="


#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME_historic+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()
			return db_check_result
	except:
		return None

#----------- Rest API based on marka and model, where returns response in json fromat ----------
def api_call_model(marka,model,s_date,e_date,st_limt,end_limt):
    response  = ""
    while (response == ""):
        try:
        	response = requests.get(BASE_URL+"select+*+from+stats+where+MARKA_NAME%3D%27"+marka+"%27+and+MODEL_NAME%3D%27"+model+"%27"+"and TIME+between++%27"+s_date+"%25%27+and+%27"+e_date+"+23%3A%25%27+and+AUCTION+not+like+%27USS%25%27+LIMIT+"+str(st_limt)+"%2C+"+str(end_limt),timeout = 6000)
        	# print(BASE_URL+"select+*+from+stats+where+MARKA_NAME%3D%27"+marka+"%27+and+MODEL_NAME%3D%27"+model+"%27"+"and TIME+between++%27"+s_date+"%25%27+and+%27"+e_date+"+23%3A%25%27+and+AUCTION+not+like+%27USS%25%27+LIMIT+"+str(st_limt)+"%2C+"+str(end_limt))
        except Exception as e:
        	print("API CALL TIME OUT",e)
    return response.json()
#----------- Rest API based on marka and model, where returns response in json fromat ----------
def get_count(marka,model,s_date,e_date):
    response  = ""
    while (response == ""):
        try:
        	response = requests.get(BASE_URL+"select+count%28*%29+from+stats+where+MARKA_NAME%3D%27"+marka+"%27+and+MODEL_NAME%3D%27"+model+"%27"+"and TIME+between++%27"+s_date+"%25%27+and+%27"+e_date+"+23%3A%25%27+and+AUCTION+not+like+%27USS%25%27",timeout = 6000)
        	# print(BASE_URL+"select+count%28*%29+from+stats+where+MARKA_NAME%3D%27"+marka+"%27+and+MODEL_NAME%3D%27"+model+"%27"+"and TIME+between++%27"+s_date+"%25%27+and+%27"+e_date+"+23%3A%25%27+and+AUCTION+not+like+%27USS%25%27")        	
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+DOWNLOADFLAGTABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	db_connection_obj = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return db_connection_obj
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)

	return connection_hadoop_check

def check_ID(db_connection_obj,id):
	with db_connection_obj.cursor() as hadoop_cursor:
		sql="SELECT * FROM "+TABLE+" where ID = \""+ id+"\" ;"
		hadoop_cursor.execute(sql)
		res_=hadoop_cursor.fetchone()
		if(str(res_)=='None'):
			return True
		else:
			return False

def stock_id(db_connection_obj):
	try:
		with db_connection_obj.cursor() as hadoop_cursor:
			sql="select max(STOCK_ID) as id from "+TABLE
			log.info(sql)
			hadoop_cursor.execute(sql)
			response = hadoop_cursor.fetchall()
			return response
	except Exception as e :
		log.error(e)



#-----------Updating  execute_flag done here  ----------      
def update_execute_flag(company,model,today_date,count):
	try:
		db_connection_obj = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME_flag)
		with db_connection_obj.cursor() as hadoop_cursor:
			today_date=str(datetime.now().strftime("%Y-%m-%d"))
			sql1="SET SQL_SAFE_UPDATES=0;"
			sql="update "+DOWNLOADFLAGTABLE+" set execute_flag= 1,count="+str(count)+",local_time ='"+str(datetime.now().strftime("%Y-%m-%d %H:%M"))+"' where make= \""+company+"\" and time like '"+today_date+"%' and model= \""+model+"\";"
			hadoop_cursor.execute(sql1)
			hadoop_cursor.execute(sql)
		db_connection_obj.commit()
		db_connection_obj.close()

	except Exception as e :
		log.error(e)



#----------- Inserting data to car_future_all table for each car done here  ----------
def insert_to_table(db_connection_obj,ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,EQUIP,RATE,START,FINISH,STATUS,TIME,AVG_PRICE,AVG_STRING,IMAGES,stock_id_):
	try:
		sql_=""
		with db_connection_obj.cursor() as hadoop_cursor:
			today_=str(str(datetime.today())[:16])
			if(check_ID(db_connection_obj,ID)):
				sql = "insert into "+TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,EQUIP,RATE,START,FINISH,STATUS,TIME,AVG_PRICE,AVG_STRING,IMAGES,LOCAL_TIME,STOCK_ID) VALUES(\""+ID+"\","+LOT+",\""+AUCTION_DATE+"\",\""+AUCTION+"\","+MARKA_ID+","+MODEL_ID+",\""+MARKA_NAME+"\",\""+MODEL_NAME+"\","+YEAR+",\""+ENG_V+"\",\""+str(PW)+"\",\""+KUZOV+"\",\""+GRADE+"\",\""+COLOR+"\",\""+KPP+"\","+KPP_TYPE+",\""+PRIV+"\","+MILEAGE+",\""+EQUIP+"\",\""+RATE+"\","+START+",\""+FINISH+"\",\""+STATUS+"\",\""+TIME+"\","+AVG_PRICE+",\""+AVG_STRING+"\",\""+IMAGES+"\",\""+today_+"\","+str(stock_id_)+")"
				hadoop_cursor.execute(sql)
				db_connection_obj.commit()
	except Exception as e:
		log.error(e)
		log.error(sql_)
#----------- Get cars based on MARKA and MODEL and Inserted to table done here ----------
def download_car_info_(json_):
	try:
		db_connection_obj = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME_historic)
		start_time=t.time()
		stock_id_=int(stock_id(db_connection_obj)[0]['id'])
		for car_model in range(int(len(json_))):
			stock_id_=stock_id_+1
			today_=str(str(datetime.today())[:16])
			car_model_details=json_[car_model]
			if('AVG_PRICE' in car_model_details and 'AVG_STRING' in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],car_model_details['AVG_PRICE'],car_model_details['AVG_STRING'],car_model_details['IMAGES'],stock_id_)
			if('AVG_PRICE' not in car_model_details and 'AVG_STRING' not in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],'0','NULL',car_model_details['IMAGES'],stock_id_)
			elif('AVG_STRING' not in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],car_model_details['AVG_PRICE'],'NULL',car_model_details['IMAGES'],stock_id_)
			elif('AVG_PRICE' not in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],'0',car_model_details['AVG_STRING'],car_model_details['IMAGES'],stock_id_)

		end_time=t.time()-start_time
		log.info("time taken to download is "+str(end_time))
		
	except Exception as e:
		log.error(e)	
		log.error(e)


#----------- Get cars based on MARKA and MODEL and Inserted to table done here ----------
def download_car_info(marka,model):
	try:
		e_date=datetime.now().strftime("%Y-%m-%d")
		s_date=str(str(datetime.today() - timedelta(days=2))[:10])
		get_count_=int(str(get_count(marka,model,s_date,e_date)[0]['TAG0']))
		if(get_count_>250):
			count = get_count_/250
			loop_int=int(count)+1 if(int(count)<count) else int(count)
			st_limt=0
			end_limt=0
			for let in loop_int:
				st_limt=st_limt
				end_limt=st_limt+250
				download_car_info_(api_call_model(marka,model,s_date,e_date,st_limt,end_limt))
				st_limt=end_limt
				end_time=t.time()-start_time
				log.info("time taken to download "+str(model)+"   "+str(end_time))
				log.info(model)
				return True,get_count_
		else:
			start_time=t.time()
			download_car_info_(api_call_model(marka,model,s_date,e_date,'0','250'))
			# st_limt=end_limt
			end_time=t.time()-start_time
			log.info("time taken to download "+str(model)+"   "+str(end_time))
			log.info(model)
			return True,get_count_	
		
	except Exception as e:
		log.error(e)
		return False
		
#-----------Checking date,inserting data and updating flag done here ----------                 
def download_scheduler(car_details_json,today_date):
	try:
		status=True
		flag=True
		log.info(colored("Next scheduled Download is at "+str(car_details_json['time'])+" for "+str(car_details_json['make'])+"-"+str(car_details_json['model']),'red'))
		while status:
			if(datetime.now() >= car_details_json['time']):
				status=False
				log.info("Comparing Time :"+str(datetime.now().strftime("%Y-%m-%d %H:%M"))+"   "+str(str(car_details_json['time'])[:16]))
				if(str(datetime.now().strftime("%Y-%m-%d %H:%M")) == str(str(car_details_json['time'])[:16])):
					flag=False
					status_,count=download_car_info(str(car_details_json['make']),str(car_details_json['model']))
					if(status_):
						update_execute_flag(str(car_details_json['make']),str(car_details_json['model']),today_date,count)
						log.info(colored('downloaded for '+str(car_details_json['make'])+" "+str(car_details_json['model']),'green'))
					else:
						log.info(colored('data not downloaded for '+str(car_details_json['make'])+" "+str(car_details_json['model']),'red'))
				else:
					pass
		if(flag):
			log.info("time in downloaded plan is"+str(car_details_json['time'])+". which is less than current time ("+str(datetime.now().strftime("%Y-%m-%d %H:%M"))+") hence skipping download")
		else:
			pass
	except Exception as e:
		log.error(e)


#-----------Getting data based on execute_flag from DataBase----------      
def load_download_plan(today_date):
		try:			
			db_connection_obj = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME_flag)
			with db_connection_obj.cursor() as hadoop_cursor:
				sql="select * FROM "+DOWNLOADFLAGTABLE+" where run_flag=1 and execute_flag=0 order by time;"
				hadoop_cursor.execute(sql)
				response = hadoop_cursor.fetchall()
				db_connection_obj.close()
				return response
		except Exception as e:
			log.error(e)
			return "[]"


#----------- Main starts from here----------      
def main():
	try:
		check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
		today_date=str(datetime.now().strftime("%Y-%m-%d"))
		for row in load_download_plan(today_date):
			download_scheduler(row,today_date)
		log.info("downloaded done for "+today_date)

	except Exception as e:
		log.error(e)



#----------- Main ----------      
if __name__ == "__main__":
	main()


	

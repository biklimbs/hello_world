import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time
import random
import json
import csv
import pandas as pd
from datetime import datetime, timedelta
import traceback
from logger_config import log

MY_SQL_HOST_NAME = 'hadoop.vmoksha.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Power@1234'
MY_SQL_DB_NAME = 'beerboardLocalDb'
NORMILIZED_TABLE = 'v3_norm_poured_sold_ln'
LINE_CLEANING_TABLE = 'poured_sold'
LOCATION_TABLE= 'v3_location_date_table'
LINE_NUMBER_PREV= 0

VAR_MIN=20
START_TIME_CONST=" 00:00:00"


def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)
	return connection_hadoop_internal

# def get_date(var1,connection_hadoop_internal):
# 		try:
# 			with connection_hadoop_internal.cursor() as hadoop_cursor:
# 				#sql = "select date,user_id,location_id, location_name, product_id, product_name, poured, sold from linecleaningTable ORDER BY date LIMIT 10, 5;"
# 				sql="SELECT date from (SELECT  *, STR_TO_DATE(date, '%Y-%m-%d %H:%i') as DATE1 FROM "+LINE_CLEANING_TABLE+")AS derivTable order by DATE1 "+var1+" limit 1;"
# 				hadoop_cursor.execute(sql)
# 				#time_interval=hadoop_cursor.fetchall()
# 				#print(time_interval)
# 				time_ret=hadoop_cursor.fetchall()
# 				start_date,start_time=(time_ret[0]["date"]).split(" ")
# 				time_ret=start_date+START_TIME_CONST
# 				#print(time_ret)
# 				return (time_ret)

# 		except:
# 			print("error1")
# 			traceback.print_exc()

# def get_table_data(i,j,date_list,connection_hadoop_internal):
# 	with connection_hadoop_internal.cursor() as hadoop_cursor:
# 		sql="SELECT * from (SELECT  *, STR_TO_DATE(date, '%Y-%m-%d %H:%i') as DATE1 FROM "+LINE_CLEANING_TABLE+")AS derivTable where DATE1 between '"+date_list[i]+"' and (SELECT SUBTIME ('"+date_list[j]+"','0 0:0:1'));"
# 		hadoop_cursor.execute(sql)
# 		time_interval=hadoop_cursor.fetchall()
# 		time_interval_df=pd.DataFrame(time_interval)

# 	return(time_interval_df)


def write_data(date_var,time_var,user_var,loc,loc_var,prod_id,product_name,line_number_data,line_number_flag,poured_tot,sold_tot,hadoop_cursor):
	try:
		sql = "insert into "+NORMILIZED_TABLE+" (date, time, user_id, location_id,location_name, product_id,product_name,line_number,multi_line, poured, sold) VALUES ('"+str(date_var)+"','"+str(time_var)+"',"+str(user_var)+","+str(loc)+",\""+loc_var+"\","+str(prod_id)+",\""+product_name+"\",'"+str(line_number_data)+"','"+str(line_number_flag)+"','"+str(poured_tot)+"','"+str(sold_tot)+"')"
		hadoop_cursor.execute(sql)

	except:
		print("error4")
		traceback.print_exc()

def write_null_data(i,date_list,hadoop_cursor):
	try:
		date_var=date_list[i]
		#print(".........",date_var)
		date_var,time_var=date_var.split(" ")
		print(date_var, time_var)
		user_var="0"
		loc="0"
		loc_var="0"
		prod_id = "0"
		prod_value = "0"
		line_number_data= "0"
		line_number_flag= 0
		poured_tot="0"
		sold_tot="0"
		sql = "insert into "+NORMILIZED_TABLE+" (date, time, user_id, location_id,location_name, product_id,product_name,line_number,multi_line,poured, sold) VALUES ('"+str(date_var)+"','"+str(time_var)+"',"+str(user_var)+","+str(loc)+",'"+loc_var+"',"+str(prod_id)+",'"+prod_value+"','"+str(line_number_data)+"','"+str(line_number_flag)+"','"+str(poured_tot)+"','"+str(sold_tot)+"')"
		hadoop_cursor.execute(sql)
		#print("0 data updated")
	except:
		traceback.print_exc()
		print("error5")
	

def split_data(time_interval_df,temp_poured_sold):
	for t in range(0,len(time_interval_df[temp_poured_sold])):
		try:
			time_interval_df.loc[t,temp_poured_sold+'_list'], time_interval_df.loc[t,'waste'] = time_interval_df.loc[t,temp_poured_sold].split(" ")
		except:
			time_interval_df.loc[t,temp_poured_sold+'_list']=time_interval_df.loc[t,temp_poured_sold]
	return (time_interval_df)

def single_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor):
	global LINE_NUMBER_PREV
	
	time_interval_df_temp_prod_ln= time_interval_df_temp_prod
	#print(time_interval_df_temp_prod_ln)
	time_interval_df_temp_prod_ln = time_interval_df_temp_prod_ln.reset_index(drop=True)
	#print(time_interval_df_temp_prod_ln)
	user_var=time_interval_df_temp_prod_ln.loc[0,"user_id"]
	print("user id=",user_var)
	loc=time_interval_df_temp_prod_ln.loc[0,"location_id"]
	print("location id=",loc)
	loc_var=time_interval_df_temp_prod_ln.loc[0,"location_name"]
	print("location name=",loc_var)
	prod_id = time_interval_df_temp_prod_ln.loc[0,"product_id"]
	print("product id=",prod_id)
	prod_value = time_interval_df_temp_prod_ln.loc[0,"product_name"]
	print("product name=",prod_value)
	if len(unique_line_number)>1  and 0 in unique_line_number:
		unique_line_number.remove(0)
	if len(unique_line_number)==1  and 0 in unique_line_number:
		unique_line_number[0]= LINE_NUMBER_PREV			### previous line number
	line_number_data= unique_line_number[0]
	LINE_NUMBER_PREV= line_number_data					### previous line number
	print("line number previous= ",LINE_NUMBER_PREV)
	print("line number= ",line_number_data)
	poured_tot= pd.to_numeric(time_interval_df_temp_prod_ln.poured_list).sum()
	poured_tot=round(poured_tot,2)
	sold_tot=pd.to_numeric(time_interval_df_temp_prod_ln.sold_list).sum()
	sold_tot=round(sold_tot,2)
	print("poured=",poured_tot)
	print("sold=",sold_tot)
	write_data(date_var,time_var,user_var,loc,loc_var,prod_id,prod_value,line_number_data,0,poured_tot,sold_tot,hadoop_cursor)

def multi_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor):
	print ("------------------------------------------------------------------------")
	print ("------------------------------------------------------------------------")
	print ("------------------------------------------------------------------------")
	print (unique_line_number)
	sold_tot=0
	if 0 in unique_line_number:
		zero_line_df= time_interval_df_temp_prod.loc[time_interval_df_temp_prod["line_number"]==0]
		sold_tot=pd.to_numeric(zero_line_df.sold_list).sum()
		unique_line_number.remove(0)
	
	for line_number_uniq in unique_line_number:
		print("line number=======",line_number_uniq)
		time_interval_df_temp_prod_ln= time_interval_df_temp_prod[time_interval_df_temp_prod["line_number"]== line_number_uniq]
		#print(time_interval_df_temp_prod_ln)
		time_interval_df_temp_prod_ln = time_interval_df_temp_prod_ln.reset_index(drop=True)
		#print(time_interval_df_temp_prod_ln)
		user_var=time_interval_df_temp_prod_ln.loc[0,"user_id"]
		print("user id=",user_var)
		loc=time_interval_df_temp_prod_ln.loc[0,"location_id"]
		print("location id=",loc)

		loc_var=time_interval_df_temp_prod_ln.loc[0,"location_name"]
		print("location name=",loc_var)
		prod_id = time_interval_df_temp_prod_ln.loc[0,"product_id"]
		print("product id=",prod_id)
		prod_value = time_interval_df_temp_prod_ln.loc[0,"product_name"]
		print("product name=",prod_value)
		line_number_data= time_interval_df_temp_prod_ln.loc[0,"line_number"]
		print("line number= ",line_number_data)
		poured_tot= pd.to_numeric(time_interval_df_temp_prod_ln.poured_list).sum()
		poured_tot=round(poured_tot,2)
		print("poured=",poured_tot)
		print("sold=",sold_tot)
		write_data(date_var,time_var,user_var,loc,loc_var,prod_id,prod_value,line_number_data,1,poured_tot,sold_tot,hadoop_cursor)

def line_number_condn(date_var,time_var,unique_line_number,time_interval_df_temp_prod,hadoop_cursor):
	#print (unique_line_number)
	if len(unique_line_number)<=2 and 0 in unique_line_number:
		single_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor)
	elif (len(unique_line_number)== 1 and 0 not in unique_line_number):
		single_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor)
	elif (len(unique_line_number)== 1 and 0 in unique_line_number):
		single_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor)
	else:
		multi_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor)


def get_raw_data(connection_hadoop_internal,loc_tuple,update_to_date):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		sql="SELECT * from (SELECT  *, STR_TO_DATE(date, '%Y-%m-%d %H:%i') as Date1 FROM "+LINE_CLEANING_TABLE+")AS derivTable where location_id in ("+str(loc_tuple)+") and date like '"+update_to_date+"';"
		#print(sql)
		hadoop_cursor.execute(sql)
		time_interval=hadoop_cursor.fetchall()
		#print(len(time_interval))
		if(len(time_interval)):
			time_interval_df=pd.DataFrame(time_interval)
			time_interval_df=time_interval_df.sort_values(by=["date","location_id"], ascending=True)
			#print(time_interval_df)

			#time_interval_df=time_interval_df.drop(["date"],axis=1)
			#time_interval_df = time_interval_df.rename(columns = {'Date1':'date'})

			time_interval_df['poured_list']= time_interval_df['poured'].str.split(' ',1).str[0]
			time_interval_df['sold_list'] = time_interval_df['sold'].str.split(' ',1).str[0]
			time_interval_df=time_interval_df.drop(["Date1","sold","poured"],axis=1)

		else:
			time_interval_df=pd.DataFrame()

	return(time_interval_df)

def update_flag(connection_hadoop_internal,date,location_id):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		permission_sal="SET SQL_SAFE_UPDATES = 0;"
		hadoop_cursor.execute(permission_sal)
		connection_hadoop_internal.commit()
		sql = "UPDATE "+LOCATION_TABLE+" SET normflag= 1 WHERE date='"+date+"'  and location_id="+location_id+";"
		print(sql)
		hadoop_cursor.execute(sql)
	connection_hadoop_internal.commit()

	return " Normalization FLAG Updated "


def update_line_number(time_interval_df_temp_prod):
	#print(time_interval_df_temp_prod)
	count=0
	for index in range(0,len(time_interval_df_temp_prod)):
		if time_interval_df_temp_prod.loc[index,"line_number"]==0:
			count=count+1
		else:
			break
	#print(count)
	if count==0 or count==len(time_interval_df_temp_prod):
		pass
	else:
		for index in range(0,count):
			#print(time_interval_df_temp_prod.loc[count,"line_number"],time_interval_df_temp_prod.loc[index,"line_number"])
			time_interval_df_temp_prod.loc[index,"line_number"]= time_interval_df_temp_prod.loc[count,"line_number"]
	#print(time_interval_df_temp_prod)
	return time_interval_df_temp_prod


def get_range_data(i,j,date_list,base_df):
	# print(date_list[i],date_list[j])
	base_df_local= base_df.sort_values(by="date", ascending=True)
	base_df_local= base_df_local.loc[base_df_local["date"]>=date_list[i]]
	base_df_local= base_df_local.loc[base_df_local["date"]<date_list[j]]
	#print(base_df_local)
	return base_df_local

def get_start_date(base_df):
	base_df_local= base_df.sort_values(by="date", ascending=True)
	base_df_local= base_df_local.reset_index(drop=True)
	start_date= base_df_local.loc[0,"date"]
	start_date,start_time=start_date.split(" ")
	time_ret=start_date+START_TIME_CONST
	return time_ret

def get_end_date(base_df):
	base_df_local= base_df.sort_values(by="date", ascending=False)
	base_df_local= base_df_local.reset_index(drop=True)
	end_date= base_df_local.loc[0,"date"]
	return end_date

def get_locations(connection_hadoop_internal):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		sql="SELECT * FROM "+LOCATION_TABLE+" where rawflag=1 and normflag=0;"
		# print(sql)		
		hadoop_cursor.execute(sql)
		loc_df=hadoop_cursor.fetchall()
		#print(loc_df)
		try:
			loc_df_temp=pd.DataFrame(loc_df)
		except:
			loc_df_temp= pd.DataFrame()
	return loc_df_temp

def main():
	log.info("Normalization starts line wise")
	pd.options.display.max_columns=100
	pd.options.display.max_rows=10000
	pd.set_option('expand_frame_repr', False)
	connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	time_interval={}

	loc_df=get_locations(connection_hadoop_internal)			### getting all locations from location table for end date
	#print(loc_df)
	
	try:
		if len(loc_df):
			loc_to_normalize=loc_df.reset_index(drop=True)
			#print(loc_to_normalize)
			log.info(loc_to_normalize)
			for index in range(len(loc_to_normalize)):
				to_date= loc_to_normalize.loc[index,"date"]
				update_to_date= to_date+"%"
				loc_tuple=loc_to_normalize.loc[index,"location_id"]
				#print(loc_tuple)
				#loc_tuple=np.(loc_tuple)
				log.info("Starts for location id=%s and Date=%s" %(loc_tuple,to_date))
				base_df=get_raw_data(connection_hadoop_internal,loc_tuple,update_to_date)   ### getting the raw table data into dataframe for locations
				start_time1 = time.time()
				if len(base_df):
					time_interval_df_temp = base_df.reset_index()

					unique_product_list = time_interval_df_temp["product_id"].unique()
					for product_id_unique in unique_product_list:
						log.info("New product starts.....")
						global LINE_NUMBER_PREV
						LINE_NUMBER_PREV= 0
						#print(".........................................",time_interval_df_temp)
						time_interval_df_temp_prod = time_interval_df_temp[time_interval_df_temp["product_id"] == product_id_unique]
						#print("..................,,,,,,,,,,,,,,,,,,",time_interval_df_temp)
						time_interval_df_temp_prod = time_interval_df_temp_prod.reset_index(drop=True)
						#print(time_interval_df_temp_prod)
						time_interval_df_temp_prod= update_line_number(time_interval_df_temp_prod)
						
						start_time=get_start_date(time_interval_df_temp_prod)					### getting the start date 
						#print("Start time............",start_time)
						end_time=get_end_date(time_interval_df_temp_prod)						### getting the end date
						end_time=pd.to_datetime(end_time)
						#print("End time.............",end_time)
						date_list=[]
						
						datetime_temp=pd.to_datetime(start_time)
						date_list.append(str(datetime_temp))
						while(str(datetime_temp)<str(end_time)):
							datetime_temp = (datetime_temp + timedelta(minutes=VAR_MIN))
							date_list.append(str(datetime_temp))
					
						time_prod=[]
						time_loc=[]
						#print(date_list)
						for i in range(0,len(date_list)-1):
							j=i+1
							#print(i)
							
							try:
								# date_temp, waste= str(date_list[i]).split(' ')
								# loc_df_temp= loc_df.loc[loc_df["date"]==date_temp]
								# if loc_df_temp["normflag"]==1:
								time_interval_df=get_range_data(i,j,date_list,time_interval_df_temp_prod)
								#print(time_interval_df)
								
								if len(time_interval_df):

									date_var=date_list[i]
									
									date_var,time_var=date_var.split(" ")
									#print("date=",date_var)
									#print("time=",time_var)
									# unique_loc=time_interval_df["location_id"].unique()
									# print("..................",len(unique_loc),unique_loc)
									#print(unique_loc)
									#print (time_interval_df)
									
									# for loc in unique_loc:
									# 	time_interval_df_temp = time_interval_df[time_interval_df["location_id"] == loc]
									# 	#print("..................,,,,,,,,,,,,,,,,,,",time_interval_df_temp)
									
									#print ("unique product list..................=",unique_product_list)
									
									

									time_interval_df = time_interval_df.reset_index(drop=True)
									# if time_interval_df.loc[0,"product_id"]==31371:
									# 	sys.exit()
									unique_line_number= time_interval_df["line_number"].unique()
									log.info(unique_line_number)
									unique_line_number= list(unique_line_number)
									with connection_hadoop_internal.cursor() as hadoop_cursor:
										line_number_condn(date_var,time_var,unique_line_number,time_interval_df,hadoop_cursor)
									connection_hadoop_internal.commit()
								else:
									pass
							except Exception as e:
								traceback.print_exc()
								log.info(str(e))

						update_flag(connection_hadoop_internal,str(to_date),str(loc_tuple))
					log.info("Ends for (date= %s, location= %s)" %(str(to_date),str(loc_tuple)))
				else:
					#print("Data not available in Raw table")
					log.error("Data not available in Raw table")

				log.info("Average time for one location to run= %.3f ms\n" % (((time.time() - start_time1)*1000)))

		else:
			#print("No locations available")
			log.error("No locations available")
			return "False"

	except Exception as e:
		#traceback.print_exc()
		#print(e)
		log.error(str(e))
		return str(e)
if __name__=='__main__':
	main()

import pandas as pd 
from datetime import datetime, timedelta
import time as t
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
sys.path.append('./Ground Truth/')
ERROR=""
CHECK_FILE=True

try:
	from logger_config import log
except:
	log.error("logger_config.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+"logger_config.py file not found."
	#print("linecleaning_location.py file not found.")

try:
	from  call_all_files import get_gt
except Exception as e:
	print(str(e))
	log.error("call_all_files.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+"call_all_files.py file not found."
	#print("linecleaning_location.py file not found.")

try:
	from accuracy import get_accuracy
except Exception as e:
	print(str(e))
	log.error("accuracy.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+"accuracy.py file not found."
	#print("linecleaning_location.py file not found.")

try:
	from call_all_locations import call_all_location
except Exception as e:
	print(str(e))
	log.error("call_all_location.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+"call_all_location.py file not found."
	#print("linecleaning_location.py file not found."


def increment_date(date):
	date = datetime.strptime(date, "%Y-%m-%d")
	modified_date = date + timedelta(days=1)
	date = datetime.strftime(modified_date, "%Y-%m-%d")
	return date

def run_all_files(from_date,to_date):
	while from_date<=to_date:	
		# print(from_date)
		log.info("Running  algorithm...")
		resp_json=call_all_location(from_date)
		from_date=increment_date(from_date)
	log.info("Ground Truth calculating...")
	resp=get_gt()
	log.info("Accuracy calculating...")
	resp=get_accuracy()
	return resp



def main():
	if len(sys.argv)==1:
		log.info("Date arguements not given")
	elif len(sys.argv)==2:
		if CHECK_FILE==True:
			from_date=sys.argv[1]
			to_date= sys.argv[1]
			res_str=run_all_files(from_date,to_date)
			return res_str
		else:
			#print(CHECK_FILE, ERROR)
			return ERROR
		
	elif len(sys.argv)==3:
		if CHECK_FILE==True:
			from_date=sys.argv[1]
			to_date= sys.argv[2]
			res_str=run_all_files(from_date,to_date)
			return res_str
		else:
			#print(CHECK_FILE, ERROR)
			return ERROR
	

	
if __name__=="__main__":
	main()
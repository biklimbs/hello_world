"""
Title: Compute Sold Null

Description: Computing the sold data for the pored data for all the datapoints
"""


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
try:
	from constants import *
except:
	log.error("constants.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()


def sold_null_main(base_data_df):
	try:
		for index, row_val in base_data_df.iterrows():
			if row_val["sold"]==0 or row_val["sold"]<(row_val["poured"]/100):
				base_data_df.loc[index,"sold_f"]= W_SOLD_FULL
				base_data_df.loc[index,"weight"]=base_data_df.loc[index,"weight"]+W_SOLD_FULL
			else:
				base_data_df.loc[index,"sold_f"]=0
				base_data_df.loc[index,"weight"]=base_data_df.loc[index,"weight"]+0
		base_data_df= base_data_df.reset_index(drop=True)
		base_data_df = base_data_df.drop(['index'], axis=1)
		return base_data_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)


def get_sold_null(base_data_df):
	return sold_null_main(base_data_df)
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
from logger_config import log
from termcolor import colored
import time as t

MY_SQL_HOST_NAME = 'hadoop.vmoksha.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Power@1234'
MY_SQL_DB_NAME = 'beerboardLocalDb'


LINE_CLEANING_PLU_TABLE = '68_nagitive_variance_plu'
LINE_CLEANING_TABLE = '68_nagitive_variance'
NORMALIZATION_TABLE = '68_normalizedPouredSold'
INSERT_ZERO_NORMILIZATION_TABLE = '68_normalized_with_zeros'

PLU_MISSING_WEIGHT = 2

IDEAL_LOSS_SOLD_MAGIC_NUM=5
IDEAL_LOSS_POSITIVE_LOSS_MAGIC_NUM= 1000
IDEAL_LOSS_POURED_THRESHOLD= 5
IDEAL_LOSS_W_IDEAL_LOSS_COMPARE=2
IDEAL_LOSS_IDEAL_CONFIDENCE_LOSS=60

INET_W_SOLD_FIRST_QUATER=1
INET_W_SOLD_SECOND_QUATER=0.75
INET_W_SOLD_THIRD_QUATER=0.5
INET_W_SOLD_FOURTH_QUATER=0.25

INET_W_DEVIATION_FROM_SD_FIRST_QUATER=0.25
INET_W_DEVIATION_FROM_SD_SECOND_QUATER=0.50
INET_W_DEVIATION_FROM_SD_THIRD_QUATER=0.75
INET_W_DEVIATION_FROM_SD_FOURTH_QUATER=1

INET_W_SOLD_SUM_FIRST_QUATER=0.25
INET_W_SOLD_SUM_SECOND_QUATER=0.5
INET_W_SOLD_SUM_THIRD_QUATER=0.75
INET_W_SOLD_SUM_FOURTH_QUATER=1
INET_MAX=3

LINECLEANING_LOCATION_START_HR_MRN=6
LINECLEANING_LOCATION_START_MIN_MRN=0
LINECLEANING_LOCATION_END_HR_MRN=12
LINECLEANING_LOCATION_END_MIN_MRN=0
LINECLEANING_LOCATION_START_HR_NT=22
LINECLEANING_LOCATION_START_MIN_NT=30
LINECLEANING_LOCATION_END_HR_NT=6
LINECLEANING_LOCATION_END_MIN_NT=0

LINECLEANING_LOCATION_W_SOLD_FULL=1
LINECLEANING_LOCATION_W_SOLD_20=0.75
LINECLEANING_LOCATION_W_SOLD_HALF=0.5
LINECLEANING_LOCATION_W_SOLD_QUATER=0.25

LINECLEANING_LOCATION_W_TIME_START_OF_THE_DAY=1
LINECLEANING_LOCATION_W_TIME_MIDDLE_OF_THE_DAY=1
LINECLEANING_LOCATION_W_TIME_END_OF_THE_DAY=1

LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_FIRST_QUATER=0.25
LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_SECOND_QUATER=0.50
LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_THIRD_QUATER=0.75
LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_FOURTH_QUATER=1

LINECLEANING_LOCATION_W_NEIGHBOURHOOD= 2.95

LINECLEANING_LOCATION_MAX=3
LINECLEANING_LOCATION_DISPLAY_CONFIDENCE_CUT_OFF=95

LINECLEANING_LOCATION_W_LOCATION=1

MIN_VOLUME_W_MIN_VOLUME= 2
MIN_VOLUME_LINECLEANING_MAGIC_NUM= 30

MULTIDAY_W_SOLD_FULL=1

MULTIDAY_W_DEVIATION_FROM_SD_FIRST_QUATER=0.25
MULTIDAY_W_DEVIATION_FROM_SD_SECOND_QUATER=0.50
MULTIDAY_W_DEVIATION_FROM_SD_THIRD_QUATER=0.75
MULTIDAY_W_DEVIATION_FROM_SD_FOURTH_QUATER=1

MULTIDAY_MAX=3
MULTI_LOC_MAX=2.75
MULTIDAY_LIMIT_CHECK=10
MULTIDAY_DISPLAY_CONFIDENCE_CUT_OFF=95

NEIGHBOUR_MAX=3.5
NEIGHBOUR_W_NEIGHBOURHOOD=2.95

SOLD_NULL_W_SOLD_FULL=1
SOLD_NULL_W_SOLD_HALF=0.5
SOLD_NULL_W_SOLD_QUATER=0.25

STAND_DEVAT_W_DEVIATION_FROM_SD_FIRST_QUATER=0.25
STAND_DEVAT_W_DEVIATION_FROM_SD_SECOND_QUATER=0.50
STAND_DEVAT_W_DEVIATION_FROM_SD_THIRD_QUATER=0.75
STAND_DEVAT_W_DEVIATION_FROM_SD_FOURTH_QUATER=1

STAND_DEVAT_START_HR_MRN=6
STAND_DEVAT_START_MIN_MRN=0
STAND_DEVAT_END_HR_MRN=17
STAND_DEVAT_END_MIN_MRN=0
STAND_DEVAT_START_HR_NT=22
STAND_DEVAT_START_MIN_NT=0
STAND_DEVAT_END_HR_NT=6
STAND_DEVAT_END_MIN_NT=0

CONF_MAX=5

def connect_to_db(host,user,password,db):
	connection_hadoop_internal=0
	while (connection_hadoop_internal==0):
		try:
			connection_hadoop_internal = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             db=db,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)
		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#traceback.print_exc()
			t.sleep(10)
	#print(connection_hadoop_internal)
	return connection_hadoop_internal

def check_if_Table_exits(connection_hadoop_internal):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+NORMALIZATION_TABLE+"' LIMIT 1;"
			# hadoop_cursor.execute(sql_quary)
			# normalized_table_result = hadoop_cursor.fetchone()
			normalized_table_result=network_call(sql_quary,hadoop_cursor)

			if(normalized_table_result != None):
				return True
			else:
				return False
	except Exception as e:
		log.warning(e)
		#traceback.print_stack()
		return False

# To Check that the network is connected or not
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(connection_hadoop_check)
			#traceback.print_exc()
			t.sleep(30)

	return connection_hadoop_check


# To check that the Database is there or not
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			#hadoop_cursor.execute(sql)
			db_check_result=network_call(sql,hadoop_cursor)
			#db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None

def network_call(sql,hadoop_cursor):
	#response  = ""
	response_code = 0
	while (response_code==0):
		try:
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall()
		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#traceback.print_exc()
			t.sleep(10)
			#traceback.print_stack()
	return response_code

def display_modified_df (dataframe):
	modified_df = dataframe
	modified_df = modified_df.drop(['loc_name','prod_name','id'], axis=1)
	log.info(modified_df)

def rearrange_data_frame (dataframe):
	return dataframe[["id","date","time","user_id","location_id","location_name","product_id","product_name","poured","sold","loc_f","loc_w","inet_f","inet_w","mday_f","mday_w","sb_loss","id_loss","iloss_f","iloss_w","m_plu_w",	"stdev_f","std_w","sold_w","negbr_w","m_volume","t_weight","confidence"]]
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
from termcolor import colored
import time as t
try:
	from logger_config import log
except:
	log.error("logger_config.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()
	
MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Power@1234'
MY_SQL_DB_NAME = 'beerboardLocalDb_id'

LOCATION_DATE_TABLE='location_date_table_new'
PLU_TABLE = 'plu'
POURED_SOLD_TABLE = 'poured_sold'
NORM_POURED_SOLD_TABLE = 'norm_poured_sold'
INSERT_ZERO_NORMILIZATION_TABLE = '68_normalized_with_zeros'
LINE_CLEANING_RESULTS = 'LineCleaningResults'

W_DEVIATION_FROM_SD_FIRST_QUATER=0.25
W_DEVIATION_FROM_SD_SECOND_QUATER=0.50
W_DEVIATION_FROM_SD_THIRD_QUATER=0.75
W_DEVIATION_FROM_SD_FOURTH_QUATER=1

W_SOLD_FULL=1

MAX_NEIGHBOUR=2

W_LOCATION=1

MISSING_PLU_WEIGHT = 2

LINECLEANING_W_MULTIDAY_MAIN=2
MULTIDAY_LIMIT_CHECK=10

INET_W_FROM_SD_FIRST_QUATER=0.25
INET_W_FROM_SD_SECOND_QUATER=0.50
INET_W_FROM_SD_THIRD_QUATER=0.75
INET_W_FROM_SD_FOURTH_QUATER=1
INET_W_SOLD_FIRST_QUATER=1
INET_W_SOLD_SECOND_QUATER=0.75
INET_W_SOLD_THIRD_QUATER=0.5
INET_W_SOLD_FOURTH_QUATER=0.25
INET_W_SOLD_SUM_FIRST_QUATER=0.5
INET_W_SOLD_SUM_SECOND_QUATER=0.80
INET_W_SOLD_SUM_THIRD_QUATER=0.9
INET_W_SOLD_SUM_FOURTH_QUATER=1
W_INET=2
INET_MAX=3
INET_DISPLAY_CONFIDENCE_CUT_OFF=95


IDEAL_CONFIDENCE_LOSS=60
W_IDEAL_LOSS=2

MIN_VOLUME_MAGIC_NUM= 30
NUMBER_OF_DAYS_TO_RUN_THE_ALGO=3

MIN_VOLUME_WEIGHT = 1

LINECLEANING_ONE_HOUR_MAIN = 2
RANGE=2
VAR_MIN=20

WEIGHT_MAX=3
DISPLAY_CONFIDENCE_CUT_OFF=74

def display_modified_df (dataframe):
	modified_df = dataframe
	modified_df = modified_df.drop(['loc_name','prod_name','id'], axis=1)
	log.info(modified_df)

def rearrange_data_frame (dataframe):
	return dataframe[["id","date","time","user_id","location_id","location_name","product_id","product_name","poured","sold","loc_f","loc_w","inet_f","inet_w","mday_f","mday_w","iloss_f","iloss_w","m_plu_w",	"stdev_f","std_w","sold_w","negbr_w","m_volume","t_weight","confidence"]]





NEGITIVE_VARIENCE_L1_LIMIT=0 
DIR="./"
LOG_DIR = "log"

API_DOWNLOAD_POURED_SOLD_TABLE = "api_download_poured_sold"
# NORM_POURED_SOLD_TABLE='norm_poured_sold'
# PLU_TABLE='lineCleaningPluTable17'
# POURED_SOLD_TABLE='linecleaningTable17'

NORM_POURED_SOLD_TABLE_DUPLICATE='norm_poured_sold_duplicate'
LOCATION_DATE_TABLE_DUPLICATE = 'location_date_table_duplicate'
# LINE_CLEANING_RESULTS = 'LineCleaningResults' 			# To save results for > 75 - 100 confidence range



PRODUCT_TABLE = 'full_products'
PROBLEM_TABLE = 'problem_table_api_download'

URL1 = "http://betaapi.beerboard.com/nodejsserver/getLineCleaningData?"
URL3 = "&locationid="
URL2 = "date="


LINE_CLEANING_PLU_TABLE=PLU_TABLE
LINE_CLEANING_TABLE=POURED_SOLD_TABLE
NORMALIZATION_TABLE=NORM_POURED_SOLD_TABLE

DOWNLOAD_API_TIME_DELAY = 25

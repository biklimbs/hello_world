import sys, traceback
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import csv
from termcolor import colored
from constants import *
from logger_config import log
import pandas as pd
from datetime import datetime, timedelta


FILE_FLAG = True
try:
	import linecleaning_common as lcc
	from linecleaning_common import check_if_Table_exits
	from linecleaning_common import check_connection
	from linecleaning_common import check_if_DB_exists
	from linecleaning_common import connect_to_db
	from linecleaning_common import network_call
	from linecleaning_common import insert_network_call
except Exception as e:
	log.error("linecleaning_common.py file not found.")
	FILE_FLAG=False

OLD_PRODUCT_TABLE = 'product'
NEW_PRODUCT_TABLE = 'all_products'
FILE_EXPORT = 'customer_product/full_product.csv'

def check_table_exits_poured_sold(connection_to_db):
	old_product_table_exists = check_if_Table_exits(connection_to_db,OLD_PRODUCT_TABLE)
	new_product_table_exists = check_if_Table_exits(connection_to_db,NEW_PRODUCT_TABLE)
	return old_product_table_exists,new_product_table_exists

def connect_to_db_check():
	connection_to_db = None
	if (FILE_FLAG == True):
		try:
			connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
		except Exception as e:
			log.error(e)
			log.critical(colored("Network Error.",'red'))
			return "Network Error.",connection_to_db
			
		if(check_if_DB_exists(connection_check)==None):
			return "Database "+MY_SQL_DB_NAME+" not found.",connection_to_db
		try:
			connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		except Exception as e:
			log.critical(e)
			log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
			return "Database "+MY_SQL_DB_NAME+" connection not established.",connection_to_db

		old_product_table_exists,new_product_table_exists = check_table_exits_poured_sold(connection_to_db)

		if(old_product_table_exists!=True):
			return "Table "+OLD_PRODUCT_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database.",connection_to_db
		elif (new_product_table_exists!=True):
			return "Table "+NEW_PRODUCT_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database.",connection_to_db
		return True, connection_to_db
	else:
		return False, connection_to_db

def get_old_product_table(hadoop_cursor):
	sql = "Select * from "+OLD_PRODUCT_TABLE
	log.debug(sql)
	data=network_call(sql,hadoop_cursor)
	if (len(data)>0):
		old_product_df = pd.DataFrame(data)
	else:
		old_product_df = pd.DataFrame()
	return old_product_df

def get_new_product_table(hadoop_cursor):
	sql = "Select * from "+NEW_PRODUCT_TABLE
	log.debug(sql)
	data=network_call(sql,hadoop_cursor)
	if (len(data)>0):
		new_product_df = pd.DataFrame(data)
	else:
		new_product_df = pd.DataFrame()
	return new_product_df

def remove_unwanted_columns_old_table(old_product_df):
	old_product_df = old_product_df[['id','name']]
	return old_product_df

def remove_unwanted_columns_new_table(new_product_df):
	new_product_df = new_product_df[['id','name']]
	return new_product_df

def merge_dataframes(old_product_df,new_product_df):
	product_df = pd.concat([old_product_df,new_product_df])
	return product_df

def identify_duplicate(product_df):
	duplicate_df = product_df[product_df.duplicated(['id','name'], keep='first')]
	return duplicate_df

def check_and_remove_duplicates(product_df):
	product_df = product_df.drop_duplicates(['id','name'], keep='first')
	return product_df

def check_if_duplicate_present_in_merged_df(product_df,dup_df):
	for index,value in dup_df.iterrows():
		check_df = product_df[product_df['name']==value['name']]
		if len(check_df) == 0:
			log.info (value)
		else:
			log.debug ("Value Present")

def main():
	isConnection,connection_to_db = connect_to_db_check()
	if (isConnection == True):
		with connection_to_db.cursor() as hadoop_cursor:
			old_product_df = get_old_product_table(hadoop_cursor)
			new_product_df = get_new_product_table(hadoop_cursor)

			if (len(old_product_df)==0):
				log.error("Table "+OLD_PRODUCT_TABLE+" is empty")
			elif (len(new_product_df)==0):
				log.error("Table "+NEW_PRODUCT_TABLE+" is empty")
			else:
				old_product_df = remove_unwanted_columns_old_table(old_product_df)
				new_product_df = remove_unwanted_columns_new_table(new_product_df)
				if len(old_product_df)>0 and len(new_product_df)>0:
					product_df = merge_dataframes (old_product_df,new_product_df)
					dup_df = identify_duplicate(product_df)
					product_df = check_and_remove_duplicates(product_df)
					check_if_duplicate_present_in_merged_df(product_df,dup_df)
					product_df.to_csv(FILE_EXPORT,index = False)

					


if __name__ == "__main__":
	main()
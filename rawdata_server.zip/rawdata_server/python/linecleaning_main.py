"""
TiTle: Data collection for Linecleaning Algorithm for a given input range.

Desription: First it will fetch all the data which is required to run the algorithm for the given range namely Raw data, Normalized data and PLU data and stored in respective dataframes
	 		Then these dataframes are passed on to another script which will compute all the 10 features.
	 		The dataframe with (Location Id , Location Name, Product Id , Product Name, Poured, Sold, all the 10 features, Confidence , Weight) will be returned from  get_single_line_feature fuction.
	 		After that user Id , User Name, line Number, Start Time, End Time is added to dataframe.
	 		After ordering getting the results above Linecleaning cut off, it that is defined in constants.py.


"""




import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import traceback
import pandas as pd
from termcolor import colored
import datetime
from datetime import datetime, timedelta
import time
import json

ERROR=""
CHECK_FILE=True

try:
	from logger_config import log
except:
	log.error("logger_config.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+"logger_config.py file not found."
	#print("linecleaning_location.py file not found.")


try:
	from constants import *
except:
	log.error("constants.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+", constants.py file not found."
	#print("linecleaning_location.py file not found.")


try:
	from linecleaning_common import *
except:
	log.error("linecleaning_common.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+", linecleaning_common.py file not found."
	#print("linecleaning_common.py file not found.")


try:
	from get_single_line_feature import get_single_line_feature
except:
	traceback.print_exc()
	log.error("get_single_line_feature.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+", get_single_line_feature.py file not found."

try:
	from min_volume import get_min_volume
except Exception as e:
	log.error("min_volume.py file not found.")
	CHECK_FILE=False
	ERROR=ERROR+", min_volume.py file not found."


def get_time_range_linecleaning(single_line_df):
	try:
		uniq_date=single_line_df["date"].unique()
		# print(uniq_date)
		result_df=pd.DataFrame()
		k=0
		for date in uniq_date:
			result_df_local= single_line_df.loc[single_line_df["date"]==date]
			result_df_local=result_df_local.reset_index(drop=True)
			uniq_prod=single_line_df["prod_id"].unique()
			for prod in uniq_prod:
				result_df_local_1= result_df_local.loc[result_df_local["prod_id"]==prod]
				
				result_df_local_1=result_df_local_1.sort_values(by=['date','start_time'],ascending=True)
				result_df_local_1=result_df_local_1.reset_index(drop=True)
				
				if result_df_local_1.loc[result_df_local_1["confidence"]>DISPLAY_CONFIDENCE_CUT_OFF].empty:
					pass
				else:
					sum_poured=0
					start_time_lc_bool=False
					start_time_lc=0
					end_time_lc=0
					date_temp2=0
					confid=0
					conf_num=1
					prod_sb_loss=0
					loc_loss=0
					line_number_temp=0
					k+=1
					for index in range(0,len(result_df_local_1)):
						if result_df_local_1.loc[index,"confidence"]>DISPLAY_CONFIDENCE_CUT_OFF:
							if start_time_lc_bool==False:

								start_time_lc= result_df_local_1.loc[index,"start_time"]
								end_time_lc= result_df_local_1.loc[index,"end_time"]
								sum_poured= result_df_local_1.loc[index,"poured"]
								confid= result_df_local_1.loc[index,"confidence"]
								prod_sb_loss= result_df_local_1.loc[index,"sb_loss"]
								loc_loss= result_df_local_1.loc[index,"loc_loss"]
								line_number_temp= result_df_local_1.loc[index,"line_number"]

								# print(result_df_local_1.loc[index,"confidence"])
								start_time_lc_bool=True
							else:
								end_time_lc= result_df_local_1.loc[index,"end_time"]
								sum_poured+= result_df_local_1.loc[index,"poured"]
								confid+= result_df_local_1.loc[index,"confidence"]
								conf_num+=1

								result_df.loc[k,"date"]=date
								result_df.loc[k,"start_time"]=start_time_lc
								result_df.loc[k,"end_time"]=end_time_lc
								result_df.loc[k,"poured"]= sum_poured
								result_df.loc[k,"line_number"]= line_number_temp
								result_df.loc[k,"sb_loss"] = prod_sb_loss
								result_df.loc[k,"loc_loss"] = loc_loss
								result_df.loc[k,"loc_id"]=result_df_local_1.loc[0,"loc_id"]
								result_df.loc[k,"loc_name"]=result_df_local_1.loc[0,"loc_name"]
								result_df.loc[k,"prod_id"]=result_df_local_1.loc[0,"prod_id"]
								result_df.loc[k,"prod_name"]=result_df_local_1.loc[0,"prod_name"]
								result_df.loc[k,"confidence"]=confid/conf_num
						else:
							start_time_lc_bool=False
							result_df.loc[k,"date"]=date
							result_df.loc[k,"start_time"]=start_time_lc
							result_df.loc[k,"end_time"]=end_time_lc
							result_df.loc[k,"poured"]= sum_poured
							result_df.loc[k,"line_number"]= line_number_temp
							result_df.loc[k,"sb_loss"] = prod_sb_loss
							result_df.loc[k,"loc_loss"] = loc_loss
							result_df.loc[k,"loc_id"]=result_df_local_1.loc[0,"loc_id"]
							result_df.loc[k,"loc_name"]=result_df_local_1.loc[0,"loc_name"]
							result_df.loc[k,"prod_id"]=result_df_local_1.loc[0,"prod_id"]
							result_df.loc[k,"prod_name"]=result_df_local_1.loc[0,"prod_name"]
							result_df.loc[k,"confidence"]=confid/conf_num
							k+=1
							sum_poured=0
							start_time_lc=0
							end_time_lc=0
							date_temp2=0
							conf_num=1
							prod_sb_loss=0
							loc_loss=0
				# print(result_df)
				# if prod==2506:
				# 	sys.exit()			

			# print(uniq_prod)
		if result_df.empty:
			pass
		else:
			result_df=result_df.loc[result_df["poured"]!=0]
			result_df=result_df.reset_index(drop=True)
		return result_df, "Success"
	except Exception as e:
		traceback.print_exc()
		log.error(str(e))
		return single_line_df, str(e)


### Takes the result dataframe and return a dataframe with confidence above the DISPLAY_CONFIDENCE_CUT_OFF.
def get_linecleaning_results(result_df):
	# result_df=single_line_df
	
	result_df=result_df[result_df["confidence"]>DISPLAY_CONFIDENCE_CUT_OFF]
	result_df=result_df.reset_index(drop=True)
	
	return result_df, "Success"

### Order the dataframe 
def get_order_df(single_line_df):
	single_line_df= single_line_df[['user_id', 'user_name' , 'loc_id', 'loc_name','prod_id', 'prod_name','line_number','poured', 'sold', 'date', 'start_time','end_time','loc_loss','sb_loss', 'std_f','sold_f', 'neigh_f', 'loc_f','mult_f', 'inet_f', 'ideal_f','one_hour_sold_f', 'm_plu_w','weight','confidence']]
	return single_line_df

### Add line number to the dataframe.
### Description: Here inputs are 2 dataframes and one is result dataframe and other is raw data dataframe. compare between these two dataframes by (date, time and product) and assign the corresponding line number to result dataframe
def get_line_number(single_line_df,raw_data_df):
	try:
		for index in range(0,len(single_line_df)):
			# print(raw_data_df["date"] ,raw_data_df["product_id"])
			# print("........",str(single_line_df.loc[index,"date"]),single_line_df.loc[index,"prod_id"].astype(int))
			temp_raw_data_df= raw_data_df[((raw_data_df["date"].astype(str))== str(single_line_df.loc[index,"date"])) & (raw_data_df["product_id"]== (single_line_df.loc[index,"prod_id"].astype(int)))]
			temp_raw_data_df=temp_raw_data_df.reset_index(drop=True)
			# print(single_line_df.loc[index,"start_time"])
			# temp_raw_data_df["date"]= temp_raw_data_df["date"].astype(str)
			# temp_raw_data_df["time"]= temp_raw_data_df["date"].astype(str)
			temp_raw_data_df= temp_raw_data_df[((pd.to_datetime(temp_raw_data_df["time"]))>=(pd.to_datetime(single_line_df.loc[index,"start_time"]))) & ((pd.to_datetime(temp_raw_data_df["time"]))<=(pd.to_datetime(single_line_df.loc[index,"end_time"])))]
			# print(temp_raw_data_df)
			line_number= temp_raw_data_df["line_number"].unique()
			line_number= list(line_number)
			# print(line_number)
			if len(line_number)>1 and 0 in line_number:					# if two or more lines are there and 0 is there so remove 0.
				line_number.remove(0)
			else:
				pass
			single_line_df.loc[index,"line_number"]=",".join([str(i) for i in line_number])				# joining multiple lines
			# print(single_line_df.loc[index,"line_number"])
			
		return single_line_df, "Success"
	except Exception as e:
		traceback.print_exc()
		log.error(str(e))
		return single_line_df, str(e)



def get_start_end_time(single_line_df):
	try:
		result_df=single_line_df
		result_df=result_df.rename(columns={'time':'start_time'})
		for index in range(0,len(result_df)):
			# date = datetime.strptime(date, "%Y-%m-%d")
			date= pd.to_datetime(result_df.loc[index,"start_time"])
			modified_date = date + timedelta(minutes=VAR_MIN)
			date = datetime.strftime(modified_date, "%Y-%m-%d %H:%M:%S")
			date, time= date.split(' ')
			result_df.loc[index,"end_time"]= time
		return result_df, "Success"
	except Exception as e:
		traceback.print_exc()
		log.error(str(e))
		return single_line_df, str(e)


### Adding the corresponding user name for the results dataframe
def get_user_name(single_line_df,raw_data_df):
	
	try:
		
		single_line_df["user_name"]= raw_data_df.loc[0,"user_name"]
		
		return single_line_df, "Success"
	except Exception as e:
		log.error(str(e))
		return single_line_df, str(e)

### Adding a confidence column in result dataframe using WEIGHT_MAX from constants.py
def get_confidence(single_line_df):
	
	single_line_df["confidence"]=round((single_line_df["weight"]/(WEIGHT_MAX))*100,2)
	return single_line_df

### increament date by 1 day
def increment_date(date):
	date = datetime.strptime(date, "%Y-%m-%d")
	modified_date = date + timedelta(days=1)
	date = datetime.strftime(modified_date, "%Y-%m-%d")
	return date

### 
def get_linecleaning(loc_id,start_date_main,end_date_main,date_modified):

	pd.options.display.max_rows=10000
	pd.options.display.max_columns=100
	pd.set_option('expand_frame_repr', False)

	# location_id_sys = sys.argv[1]
	# start_date_sys = sys.argv[2]
	# end_date_sys = sys.argv[3]
	location_id_sys=loc_id
	start_date_sys=start_date_main
	end_date_sys=end_date_main

	sys.argv[1]=location_id_sys
	sys.argv.append(start_date_sys)
	sys.argv.append(end_date_main)
	
	
	try:
		
		base_data_df ,res_str= get_normalized_data(location_id_sys,start_date_sys,end_date_sys)						# get normaziled dataframe 
		#print(base_data_df)
		if res_str=="Success":
			
			end_date_sys_updated= increment_date(end_date_sys)															# increament the date

			raw_data_df,raw_data_df_new, res_str= get_line_number_data(location_id_sys,start_date_sys,end_date_sys_updated)			# get raw table data into dataframe

			if res_str=="Success":
				plu_data_df, res_str= get_plu_table_data(location_id_sys,start_date_sys,end_date_sys)						# get plu table data into dataframe

				if res_str=="Success":
					
					single_line_df, res_str=get_single_line_feature(base_data_df,raw_data_df,raw_data_df_new,plu_data_df,start_date_sys,end_date_sys)		### To run all the features
					
					#single_line_df=single_line_df.drop(["index","id","loc_name","prod_name","user_id"],axis=1)
					if res_str=="Success":

						single_line_df= get_confidence(single_line_df)										### Confidence calculation

						single_line_df=single_line_df.drop(["index","id"],axis=1)
						single_line_df=single_line_df.reset_index(drop=True)
						# print(single_line_df)
						# single_line_df, res_str= get_single_line_total_weight(single_line_df)

						single_line_df, res_str= get_user_name(single_line_df,raw_data_df)					# get corresponding user name

						if res_str=="Success":
							if date_modified==True:
								single_line_df=single_line_df.loc[single_line_df["date"]==end_date_sys]			### dividing the dataframe into only given date
								single_line_df=single_line_df.reset_index(drop=True)
								if single_line_df.empty:
									return single_line_df,single_line_df,raw_data_df,"False"
								else:
									single_line_df, resp= get_start_end_time(single_line_df)			# get start and end time
									
									single_line_df, resp= get_line_number(single_line_df,raw_data_df)		# get line number

									single_line_df= get_order_df(single_line_df)							# order the dataframe
									# print(single_line_df)
									result_df, resp=  get_time_range_linecleaning(single_line_df)
									# print(result_df)
									# calling get_min_volume module to calculate the weights for the base_dataframe by checking that the amount of poured is greater than the cut off or not.
									# start_time1 = t.time()
									# log.info("Analysing for minimum volume")
									if result_df.empty:
										pass
									else:
										result_df , resp= get_min_volume(result_df)
										result_df , resp= get_linecleaning_results(result_df)
									# log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))

									# result_df.to_csv('./'+str(location_id_sys)+'_'+str(end_date_sys)+'_dump_result_v4.csv',index = False)
									# single_line_df.to_csv('./'+str(location_id_sys)+'_'+str(end_date_sys)+'_dump_total_v4.csv',index = False)			### To get the results into csv
									# log.info(single_line_df)
									# result_df, resp=get_linecleaning_results(single_line_df)					# get line cleaning results above a cut off
									
									

									# print(result_df)
									return result_df,single_line_df,raw_data_df,resp
								
							else:
								if  single_line_df.empty:
									return single_line_df,single_line_df,raw_data_df,"False"
								else:

									single_line_df, resp= get_start_end_time(single_line_df)				# get start and end time
										
									single_line_df, resp= get_line_number(single_line_df,raw_data_df)		# get line number

									single_line_df= get_order_df(single_line_df)							# order the dataframe

									result_df, resp=  get_time_range_linecleaning(single_line_df)
									
									# single_line_df.to_csv('./'+str(location_id_sys)+'_'+str(end_date_sys)+'_dump1.csv',index = False)			### To get the results into csv
									# log.info(single_line_df)
									result_df, resp=get_linecleaning_results(single_line_df)				# get line cleaning results above a cut off
									# print(result_df)
									return result_df,single_line_df,raw_data_df,resp
									# log.info(single_line_df)
							# multi_line_df=get_multi_line_feature(base_data_df)

							# result_df= join_results(single_line_df,multi_line_df)
							
						else:
							log.error(res_str)
							return None,None,None,res_str
					else:
						log.error(res_str)
						return None,None,None,res_str
				else:
					log.error(res_str)
					return None,None,None,res_str
			else:
				log.error(res_str)
				return None,None,None,res_str
		else:
			log.error(res_str)
			return None,None,None,res_str


	except Exception as e:
		traceback.print_exc()
		log.error(e)
		return None,None,None, str(e)
		
### Main function to call the function get_linecleaning
def linecleaning_main(loc_id,start_date_main,end_date_main):
	date_modified=False
	if start_date_main==end_date_main:
		date_modified=True
		start_date_main= pd.to_datetime(start_date_main)
		#print(start_date_main)
		start_date_main = (start_date_main - timedelta(days=NUMBER_OF_DAYS_TO_RUN_THE_ALGO))
		start_date_main= str(start_date_main)
		start_date_main, temp_time_argv = start_date_main.split(" ")
		#print(start_date_main)
	else:
		pass
	if CHECK_FILE==True:
		result_df,complete_data_df,raw_data_df,res_str=get_linecleaning(loc_id,start_date_main,end_date_main,date_modified)
		return result_df,complete_data_df,raw_data_df, res_str
	else:
		log.error(ERROR)
		return None,None,None, ERROR


### This is main() function to call the script with system arguements 
### Syntax: ***time python linecleaning_main location_id from_date to_date***
def main():
	resp,complete_data_df ,raw_data_df,resp_str= linecleaning_main(sys.argv[1],sys.argv[2],sys.argv[3])
	return resp,complete_data_df,raw_data_df,resp_str
	

if __name__ == "__main__":
	main()


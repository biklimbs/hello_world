"""
Title: Compute Standard Deviation

Description: Computing the standard deviation and assigning the corresponding weights to the data-points in the base dataframe
"""



import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time, timedelta
from termcolor import colored
import os, inspect
import math
from logger_config import log

from constants import *



# find standard deviation for all the data-points
# sd= (poured-mean)
def find_std_dev_diff(df_linecleaning,mean,stdev):
	for i,j in enumerate(df_linecleaning["poured"]):
		df_linecleaning.loc[i,"stdev_diff"]=round((j-(mean)),1)
	return(df_linecleaning)

# Checking standard deviation difference for all the pured data and
# assign the weight accordingly.
def check_std_dev_diff(df_linecleaning_local,i,avg):
	try:
		log.debug(avg)	
		#print(avg)
		#print("std_diff",df_linecleaning_local.loc[i,"stdev_diff"])
		if df_linecleaning_local.loc[i,"stdev_diff"]>0 and df_linecleaning_local.loc[i,"stdev_diff"]<((avg)/2):
			
			df_linecleaning_local.loc[i,"std_f"]=W_DEVIATION_FROM_SD_FIRST_QUATER
			df_linecleaning_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_FIRST_QUATER
			log.debug(df_linecleaning_local.loc[i,"weight"])
			#print(df_linecleaning_local.loc[i,"weight"])

			# df_linecleaning_local=check_time_range(df_linecleaning_local,i)
			return df_linecleaning_local , "Success"

		elif df_linecleaning_local.loc[i,"stdev_diff"]>=((avg)/2) and df_linecleaning_local.loc[i,"stdev_diff"]<avg:
			df_linecleaning_local.loc[i,"std_f"]=W_DEVIATION_FROM_SD_SECOND_QUATER
			df_linecleaning_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_SECOND_QUATER
			
			#print("trueeeeee2222",i)
			#print(df_linecleaning_local.loc[i,"weight"])

			# df_linecleaning_local=check_time_range(df_linecleaning_local,i)
			return df_linecleaning_local, "Success"

		elif df_linecleaning_local.loc[i,"stdev_diff"] >= avg and df_linecleaning_local.loc[i,"stdev_diff"]<(avg*3/2):
			df_linecleaning_local.loc[i,"std_f"]=W_DEVIATION_FROM_SD_THIRD_QUATER
			df_linecleaning_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_THIRD_QUATER
			
			#print("trueeeeee3333",i)
			#print(df_linecleaning_local.loc[i,"weight"])

			# df_linecleaning_local=check_time_range(df_linecleaning_local,i)
			return df_linecleaning_local, "Success"

		elif df_linecleaning_local.loc[i,"stdev_diff"]>=(avg*3/2):
			df_linecleaning_local.loc[i,"std_f"]=W_DEVIATION_FROM_SD_FOURTH_QUATER
			df_linecleaning_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_FOURTH_QUATER
			
			log.debug(df_linecleaning_local.loc[i,"weight"])
			#print("trueeeeee4444",i)
			#print(df_linecleaning_local.loc[i,"weight"])
			# df_linecleaning_local=check_time_range(df_linecleaning_local,i)
			return df_linecleaning_local, "Success"

		else:
			df_linecleaning_local.loc[i,"std_f"]=0
			df_linecleaning_local.loc[i,"weight"]=0
			
			#print("trueeeeee5555",i)
			return df_linecleaning_local, "Success"
	except Exception as e:
		log.info(str(e))
		return df_linecleaning_local, str(e)


def standard_deviation_main(base_data_df):
	#print("SD")
	loc_df = base_data_df
	prod_uniq=base_data_df["prod_id"].unique()
	concat_df=pd.DataFrame()
	for prod in prod_uniq:
		df_linecleaning=loc_df[loc_df["prod_id"]==prod]
		df_linecleaning=df_linecleaning.reset_index()
		mean=df_linecleaning["poured"].mean()
		log.debug("Mean= "+ str(mean))
		stdev=df_linecleaning["poured"].std()
		log.debug("Standard Deviation= "+ str(stdev))
		log.debug("No. Of data points = "+ str(len(df_linecleaning["poured"])))

		df_linecleaning=find_std_dev_diff(df_linecleaning,mean,stdev)

		df_linecleaning=df_linecleaning.sort_values(by="stdev_diff", ascending=False)
		df_linecleaning=df_linecleaning.reset_index(drop=True)
		avg=stdev
		log.debug("average standard deviation difference="+str(avg))

		if avg==0:
				df_linecleaning["std_f"]=0
				resp="Success"
		else:
			for index in range(0,len(df_linecleaning)):
				df_linecleaning, resp=check_std_dev_diff(df_linecleaning,index,avg)
		concat_df=concat_df.append(df_linecleaning)
	concat_df= concat_df.reset_index(drop=True)
	#concat_df=concat_df.rename(columns={'sd_w':'sd_w','sd_f':'sd_f'})
	return concat_df, resp

def get_standard_deviation(base_data_df):
	#print("SD")
	return standard_deviation_main(base_data_df)
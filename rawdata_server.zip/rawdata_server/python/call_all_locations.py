import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
from subprocess import call
from logger_config import log
from termcolor import colored
import traceback
import json
from collections import OrderedDict
from datetime import datetime,timedelta
from constants import *
error=""
FILE_FLAG=True
try:
	from linecleaning_main import linecleaning_main

except:
	error=error+"linecleaning_main.py file not found."
	log.error("linecleaning_main.py file not found.")
	#print("linecleaning_location.py file not found.")
	FILE_FLAG=False

try:
	from linecleaning_common import get_all_locations
	from linecleaning_common import get_all_locations_based_on_date_range
	from linecleaning_common import check_if_details_exsts
	from linecleaning_common import save_line_cleaning_details_to_db
except:
	error=error+",linecleaning_common.py file not found."
	log.error("linecleaning_common.py file not found.")
	#print("linecleaning_location.py file not found.")
	FILE_FLAG=False



def save_results_to_db(res_df):
	try:
		res_df= res_df.reset_index(drop=True)
		
		res_df=res_df.rename(columns={'user_id':'UserID','user_name':'UserName','prod_id':'ProductId','loc_id':'LocationId','date':'LineCleaningDate',
			'start_time':'StartTime','end_time':'EndTime','prod_name':'ProductName','loc_name':'LocationName','line_number':'LineNumber',
			'confidence':'Confidence','sb_loss':'ProductLoss','poured':'ProductLocationLoss'})
		res_df_final=res_df['UserID','UserName','ProductId','LocationId','LineCleaningDate',
			'StartTime','EndTime','ProductName','LocationName','LineNumber',
			'Confidence','ProductLoss','ProductLocationLoss']
		print(res_df_final)
		sys.exit()
		for index in range(0,len(res_df)):


			import pandas as pd
			import mysql.connector
			from sqlalchemy import create_engine

			engine = create_engine('mysql+mysqlconnector://[user]:[pass]@[host]:[port]/[schema]', echo=False)
			data.to_sql(name='sample_table2', con=engine, if_exists = 'append', index=False)
		return "Success"
	except Exception as e:
		traceback.print_exc()
		log.error(str(e))
		return str(e)


def check_if_location_exists(line_cleaning_df,location_unique,raw_data_df):
	
	# print(raw_data_df)
	print(line_cleaning_df)
	if len(line_cleaning_df)>0:
		log.info (colored("Line Cleaning Found\n",'green'))
		for m,line_cleaning in line_cleaning_df.iterrows():

			# print (line_cleaning["poured"])
			if ("," not in line_cleaning["line_number"]):
				user_name_=location_unique.loc[location_unique["location_id"]==line_cleaning["loc_id"],'user_name'].iloc[0]
				user_id_=location_unique.loc[location_unique["location_id"]==line_cleaning["loc_id"],'user_id'].iloc[0]

				# print(type(raw_data_df["date"]),type(raw_data_df["location_id"]),type(raw_data_df["product_id"]),type(raw_data_df["line_number"]))
				# print(type(line_cleaning["date"]),str(int(line_cleaning["loc_id"])),int(line_cleaning["prod_id"]),type(line_cleaning["line_number"]))

				# date_id_df= raw_data_df.loc[((raw_data_df["date"]==line_cleaning["date"]) & (raw_data_df["product_id"]==int(line_cleaning["prod_id"])))]
				# print(date_id_df)
				line_id_df= raw_data_df.loc[(raw_data_df["date"]==line_cleaning["date"]) & (raw_data_df["product_id"]==int(line_cleaning["prod_id"])) & (raw_data_df["line_number"]==int(line_cleaning["line_number"]))]
				line_id_df= line_id_df.reset_index(drop=True)
				line_id=line_id_df.loc[0,"line_id"]
				print(line_id)
				# sys.exit()

				check_table_result,response_flag = check_if_details_exsts(line_cleaning["date"],line_cleaning["prod_id"],line_cleaning["start_time"],line_cleaning["end_time"],line_cleaning["loc_id"],line_cleaning["line_number"])
				if (len(check_table_result) == 0 and response_flag == "Success"):
					save_line_cleaning_details_to_db(line_cleaning["prod_id"],line_cleaning["loc_id"],line_cleaning["date"],line_cleaning["start_time"],line_cleaning["end_time"],line_cleaning["prod_name"],line_cleaning["loc_name"],line_cleaning["line_number"],round(line_cleaning["confidence"],2),round(line_cleaning["sb_loss"],2),round(line_cleaning["poured"],2),datetime.now().strftime('%Y/%m/%d %H:%M:%S'),datetime.now().strftime('%Y/%m/%d %H:%M:%S'),0,user_name_,user_id_,line_id)
			else:
				split_line_cleaning = line_cleaning["line_number"].split(",")

				for line_number in split_line_cleaning:
					print ("------------------------------------------------------")
					print (type(line_cleaning["line_number"]))
					print ("------------------------------------------------------")
					user_name_=location_unique.loc[location_unique["location_id"]==line_cleaning["loc_id"],'user_name'].iloc[0]
					user_id_=location_unique.loc[location_unique["location_id"]==line_cleaning["loc_id"],'user_id'].iloc[0]

					line_id_df= raw_data_df.loc[(raw_data_df["date"]==line_cleaning["date"]) & (raw_data_df["location_id"]==int(line_cleaning["loc_id"])) & (raw_data_df["product_id"]==int(line_cleaning["prod_id"])) & (raw_data_df["line_number"]==int(line_number))]
					line_id_df= line_id_df.reset_index(drop=True)
					line_id=line_id_df.loc[0,"line_id"]
					print(line_id)
					# sys.exit()

					check_table_result,response_flag = check_if_details_exsts(line_cleaning["date"],line_cleaning["prod_id"],line_cleaning["start_time"],line_cleaning["end_time"],line_cleaning["loc_id"],line_number)
					if (len(check_table_result) == 0 and response_flag == "Success"):
						save_line_cleaning_details_to_db(line_cleaning["prod_id"],line_cleaning["loc_id"],line_cleaning["date"],line_cleaning["start_time"],line_cleaning["end_time"],line_cleaning["prod_name"],line_cleaning["loc_name"],line_number,round(line_cleaning["confidence"],2),round(line_cleaning["sb_loss"],2),round(line_cleaning["poured"],2),datetime.now().strftime('%Y/%m/%d %H:%M:%S'),datetime.now().strftime('%Y/%m/%d %H:%M:%S'),0,user_name_,user_id_,line_id)
	else:
		log.info (colored("No Line cleaning found\n",'red'))

def call_all_location(date_sys):
	
	# sys.argv.append(start_date_sys)
	# sys.argv.append(end_date_sys)
	if FILE_FLAG==False:
		empty_dic={}
		empty_dic["Message"] = error
		#print(empty_dic)	
		return empty_dic
	else:
		location_unique,result_str = get_all_locations(date_sys)
		log.info(location_unique)
		log.debug (location_unique)
		
		if len(location_unique)>0:
			# sys.argv.append(end_date_sys)
			# json_all_location = OrderedDict()
			# all_location_list = []
			# i = 0
			# json_all_location["info"]= OrderedDict()
			# json_all_location["info"]["start"]= 0
			# json_all_location["info"]["end"]= 30
			# json_all_location["info"]["limit"]= 30
			# json_all_location["info"]["total"]= 7686
			# json_all_location["info"]["criteria"]= {} #{"start": 0,"end": 30,"limit": 30,"total": 7686,"criteria": {}}
			number=1
			for index, row in location_unique.iterrows():
				# sys.argv[1] = str(row["location_id"])
				# sys.argv[2] = end_date_sys
				# sys.argv[3] = end_date_sys
				loc_id= str(row["location_id"])
				start_date_main= date_sys
				end_date_main= date_sys
				# loc_id= '808'
				# start_date_main= '2018-05-01'
				# end_date_main= '2018-05-01'
				log.info("Total %s running %s... \n" %(len(location_unique), number))
				log.info("%s %s %s" %(loc_id,start_date_main,end_date_main))

				res_df,complete_data_df,raw_data_df,resp_str = linecleaning_main(loc_id,start_date_main,end_date_main)#[1:-1].split("},")
				if (resp_str == 'Success'):
					check_if_location_exists(res_df,location_unique,raw_data_df)
				else:
					log.info(colored("No Line cleaning found\n",'red'))
					log.info (resp_str)
				number+=1
				#resp= save_results_to_db(res_df)
				
			# 	json_data_list = json.loads(json_data_str)
			# 	for json_dic in json_data_list:
			# 		all_location_list.append(json_dic)
			# 	log.debug ("-------------------------------------------------------------------------------------------------------")
			# 	if (len(json_data_list)>0):
			# 		check_if_location_exists(json_data_list,location_unique)

		
			# 	i = i+1
			# json_all_location['ViewModels'] = all_location_list
			# #json_all_location= json.loads(json_all_location,object_pairs_hook=OrderedDict)
			# json_all_location_result = json.dumps(json_all_location)
			# return json_all_location_result

			return resp_str
		else:
			json_all_location = OrderedDict()
			all_location_list = []
			empty_dic=OrderedDict()
			json_all_location["info"]= OrderedDict()
			json_all_location["info"]["start"]= 0
			json_all_location["info"]["end"]= 30
			json_all_location["info"]["limit"]= 30
			json_all_location["info"]["total"]= 7686
			json_all_location["info"]["criteria"]= {}
			empty_dic["Message"] = result_str
			all_location_list.append(empty_dic)
			json_all_location['ViewModels'] = all_location_list
			# log.info("No Line cleaning found during %s to %s for location id %s" %(sys.argv[2],sys.argv[3],sys.argv[1]))
			return json.dumps(json_all_location)
			# return "Location's data is not available for the date " + end_date_sys


def main():
	if len(sys.argv)<=1:
		print("from date required.")
		return "False"
	elif len(sys.argv)==2:
		resp=call_all_location(sys.argv[1])
		return resp
	elif len(sys.argv)==3:
		print("from date required.")
		#resp=call_all_location(sys.argv[1],sys.argv[2])
		return resp
	elif len(sys.argv)==4:
		print("from date required.")
		#resp=call_all_location(sys.argv[1],sys.argv[2],sys.argv[3])
		return resp
	
	

if __name__ == "__main__":
	main()



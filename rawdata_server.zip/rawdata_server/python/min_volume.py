"""
Title: Min Volume feature

Description: Check Min volume  of poured of all the datapoints. (Min volume criteria is 30 oz)

"""


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pandas as pd
from logger_config import log
from constants import *



def compute_min_volume_feature(base_data_df):
	# print(base_data_df)
	base_data_df= base_data_df.sort_values(by="date")
	base_data_df=base_data_df.reset_index(drop=True)
	# base_data_df["min_f"]= 0
	for item in range(0,len(base_data_df)):
		# if base_data_df.loc[item,'weight']<2.8:												### min feature applied only below 2.8 weight
		if base_data_df.loc[item, "poured"]<MIN_VOLUME_MAGIC_NUM:
			# base_data_df.loc[item, "min_f"]= MIN_VOLUME_WEIGHT
			# base_data_df.loc[item,'weight'] = float(base_data_df.loc[item,'weight']) - MIN_VOLUME_WEIGHT
			base_data_df.loc[item,'confidence'] = float(base_data_df.loc[item,'confidence'])/2
			#print("weight decreased due to min volume")
			#print(above_75_df_local.loc[item, "poured"])
	return base_data_df

# def compute_min_volume_weight(base_data_df):
# 	base_data_df["min_w"]= base_data_df["min_f"]
# 	return base_data_df

def min_volume_main(base_data_df):
	try:
		base_data_df= compute_min_volume_feature(base_data_df)
		#base_data_df= compute_min_volume_weight(base_data_df)
		return base_data_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)

def get_min_volume(base_data_df):
	return min_volume_main(base_data_df)


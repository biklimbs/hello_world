	#!/usr/bin/python
import sys, traceback
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time
import random
import json
import csv
import datetime
from datetime import datetime, timedelta
from time import gmtime, strftime
from termcolor import colored
import pandas as pd
import inspect, os
import traceback
from logger_config import log
from collections import OrderedDict	
from constants import *

FILE_FLAG = True
try:
	import linecleaning_common as lcc
	from linecleaning_common import get_location_info_for_row_table
	from linecleaning_common import get_product_id_from_table
except Exception as e:
	log.error("linecleaning_common.py file not found."+str(e))
	FILE_FLAG=False

PRODUCT_NAME_ID_LIST = []

def connect_to_db(host,user,password,db):
	try:
		connection_hadoop_internal = pymysql.connect(host=host,
	                             user=user,
	                             password=password,
	                             db=db,
	                             charset='utf8mb4',
	                             cursorclass=pymysql.cursors.DictCursor)
		return connection_hadoop_internal
	except Exception as e:
		log.error(e)
		return None

def check_if_Table_exits(connection_hadoop_internal):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+API_DOWNLOAD_POURED_SOLD_TABLE+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			line_cleaning_table_result = hadoop_cursor.fetchone()

			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+PLU_TABLE+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			line_cleaning_plu_table_result = hadoop_cursor.fetchone()

			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+PROBLEM_TABLE+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			problem_table = hadoop_cursor.fetchone()
			
			if(line_cleaning_table_result != None and line_cleaning_plu_table_result != None and problem_table != None):
				return True
			else:
				return False
	except Exception as e:
		log.warning(e)
		#traceback.print_stack()
		return False

def api_call(url):
	response  = ""
	response_code = 0
	while (response == "" and response_code != 200):
		try:
			response = requests.get(url,timeout = 60)
			response_code = response.status_code
		except:
			log.error("API CALL TIME OUT. RETRYING ... ")
			time.sleep(300)
			#traceback.print_stack()
	return response

def get_url(url_user_id,url_location_id,url_date):
	return URL1+URL2+url_date+URL3+str(url_location_id)

def increment_date(start_date):
	date = datetime.strptime(start_date, "%Y-%m-%d")
	modified_date = date + timedelta(days=1)
	start_date = datetime.strftime(modified_date, "%Y-%m-%d")
	return start_date

def insert_problem_data(connection_hadoop_internal,date,location_id,location_name,user_id,user_name,error_message,problem_data,field):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		try:
			problem_data = json.dumps(problem_data)
			if ("\\" in problem_data):
				problem_data = problem_data.replace('\\','')
			if ("\"" in problem_data):
				problem_data = problem_data.replace('\"','\\"')
			sql = "insert into "+PROBLEM_TABLE+" (date,location_id,location_name,user_id,user_name,error_message,problem_data,field) VALUES ('"+date+"',"+str(location_id)+",\""+location_name+"\","+str(user_id)+",\""+user_name+"\",\""+error_message+"\",\""+str(problem_data)+"\",\""+field+"\");"
			hadoop_cursor.execute(sql)	
		except Exception as e:
			print (sql)
			log.error(e)
	connection_hadoop_internal.commit()
	log.debug ("Insterted  problem_table_api_download in to db"+" Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

def get_product_id (product_name):
	product_id = -1
	try:
		if any(product_dic["product_name"] == product_name  for product_dic in PRODUCT_NAME_ID_LIST):
			product_id= [product_dic["product_id"] for product_dic in PRODUCT_NAME_ID_LIST if product_dic["product_name"] == product_name][0]
		else:
			if ("\"" in product_name):
				product_name = product_name.replace("\"","\'")
			product_id_list = get_product_id_from_table(product_name)
			if (len(product_id_list)>0):
				product_id = product_id_list[0]['id']
				product_dic = {}
				product_dic["product_id"] = product_id
				product_dic["product_name"] = product_name
				PRODUCT_NAME_ID_LIST.append(product_dic)
			else:
				product_id = -1
	except Exception as e:
		log.error(e)
		product_id = -1
	finally:
		return product_id

def poured_data_insert(connection_hadoop_internal,raw_poured_json_array,user_id,location_id,user_name,location_name,current_date):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		for raw_dic in raw_poured_json_array:
			try:
				date = raw_dic['timekey']
				product_name = raw_dic['product']
				poured =  raw_dic['Poured']
				lineCleaning = raw_dic['lineCleaning']
				lineNo = raw_dic['lineNo']
				lineId = str(raw_dic['lineId'])
				# print(type(lineNo),type(lineId))
				location_name = location_name
				product_id = get_product_id(product_name)
				sold = '0'
				if (product_id == -1):
					log.info("Product Missing : "+product_name)
					insert_problem_data(connection_hadoop_internal,raw_dic['timekey'],location_id,location_name,user_id,user_name,"product id missing",raw_dic,"poured")
				else:
					sql = "insert into "+API_DOWNLOAD_POURED_SOLD_TABLE+" (date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,line_id,quantity,pluNumber) VALUES ('"+date+"',"+str(user_id)+",\""+user_name+"\","+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+","+lineId+",0,0)"
					hadoop_cursor.execute(sql)	
			except Exception as e:
				log.error(e)
				insert_problem_data(connection_hadoop_internal,raw_dic['timekey'],location_id,location_name,user_id,user_name,str(e),raw_dic,"poured")
				
							
	connection_hadoop_internal.commit()
	log.debug ("Insterted  pourd data in to db"+" Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))	

def sold_data_insert(connection_hadoop_internal,raw_sold_json_array,user_id,location_id,user_name,location_name,current_date):
	log.debug ("start sold data parsing Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))	
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		for raw_dic in raw_sold_json_array:
			try:				
				date = raw_dic['timekey']
				product_name = raw_dic['product']
				if (raw_dic['sold'] != 0):
					sold = str(raw_dic['sold'])+" oz"
				else:
					sold = str(raw_dic['sold'])
				lineCleaning = 0
				lineNo = 0
				quantity = raw_dic['quantity']
				pluNumber = raw_dic['pluNumber']
				location_name = location_name
				product_id = get_product_id(product_name)
				poured = '0'
				if (product_id == -1):
					insert_problem_data(connection_hadoop_internal,raw_dic['timekey'],location_id,location_name,user_id,user_name,"product id missing",raw_dic,"sold")
				else:
					sql = "insert into "+API_DOWNLOAD_POURED_SOLD_TABLE+" (date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber) VALUES ('"+date+"',"+str(user_id)+",\""+user_name+"\","+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+str(lineNo)+","+str(quantity)+","+str(pluNumber)+")"
					hadoop_cursor.execute(sql)																			
			except Exception as e:
				log.error(e)
				insert_problem_data(connection_hadoop_internal,raw_dic['timekey'],location_id,location_name,user_id,user_name,str(e),raw_dic,"sold")
							
	connection_hadoop_internal.commit()
	log.debug ("Insterted sold data in to db Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

def plu_data_insert(connection_hadoop_internal,plu_data_json_obj,user_id,location_id,user_name,location_name,current_date):
	log.debug ("start plu parsing Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		for plu_dic in plu_data_json_obj:
			try:						
				product_name = plu_dic['name']
				plu_num=plu_dic["plu"]
				plu_num = plu_num.replace("$","")
				plu_size=plu_dic["size"]
				location_name = location_name
				product_id = get_product_id(product_name)
				if (product_id == -1):
					insert_problem_data(connection_hadoop_internal,current_date,location_id,location_name,user_id,user_name,"product id missing",plu_dic,"plu")
				else:
					sql = "insert into "+PLU_TABLE+" (date,user_id,user_name,location_id,location_name,product_id,product_name,plu_num,plu_size) VALUES ('"+current_date+"',"+str(user_id)+",\""+user_name+"\","+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\","+str(plu_num)+",'"+plu_size+"')"
					hadoop_cursor.execute(sql)
			except Exception as e:
				log.error(e)
				insert_problem_data(connection_hadoop_internal,current_date,location_id,location_name,user_id,user_name,str(e),plu_dic,"plu")

							
	connection_hadoop_internal.commit()
	log.debug ("Insterted plu data in to db Time: "+ datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

def update_raw_column_flag(row,connection_hadoop_internal):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		sql = "UPDATE "+LOCATION_DATE_TABLE+" SET rawflag = "+str(1)+" WHERE user_id = "+str(row['user_id'])+" and location_id = "+str(row['location_id'])+" and date = '"+row['date']+"';"
		print(sql)
		hadoop_cursor.execute(sql)
	connection_hadoop_internal.commit()
	log.info ("Update raw flag Time: "+ datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

def raw_data_download(date = None):
	if(FILE_FLAG == False):
		log.error ("FILE is Missing")
		#print(json.dumps(empty_list))
	else:

		df_location_date_info = get_location_info_for_row_table(date)
		print (df_location_date_info)
		for index,row in df_location_date_info.iterrows():
			try:
				table_missing_bol = False
				connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
				if(check_if_Table_exits(connection_hadoop_internal)!= True):
					log.debug("TABLE DOES NOT EXIST'S IN THE DATABASE")
					table_missing_bol = True

				if (table_missing_bol == False):
					log.debug ("API CAll")
					api_date = row['date']
					log.debug ("Conected to MySQLDB  "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%ms'))
					full_url = get_url(row['user_id'],row['location_id'],api_date)
					print (full_url)
					log.debug ("Starting API Call "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
					response = api_call(full_url)
					log.debug ("API call done "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
					print (response)


					data = response.json()
					#raw_data_json_obj = data['Raw Data']
					raw_poured_json_array = data['poured']
					raw_sold_json_array = data['sold']
					plu_data_json_obj = data['PLU']

					log.info ("Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')+" API_DATE ="+api_date+" User id = "+str(row['user_id'])+", User Name= "+row['user_name']+", Location id= "+str(row['location_id']) +" and Location Name= "+str(row['location_id']))
					poured_data_insert(connection_hadoop_internal, raw_poured_json_array,row['user_id'],row['location_id'],row['user_name'],row['location_name'],api_date)
					sold_data_insert(connection_hadoop_internal, raw_sold_json_array,row['user_id'],row['location_id'],row['user_name'],row['location_name'],api_date)
					plu_data_insert(connection_hadoop_internal, plu_data_json_obj,row['user_id'],row['location_id'],row['user_name'],row['location_name'],api_date)
					update_raw_column_flag(row,connection_hadoop_internal)
					log.info ("API Call result processed "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
					print ("---------------------------------------------------------------------------------------------")	
					# get_product_id('asjdb"asdasd"')
					time.sleep(DOWNLOAD_API_TIME_DELAY)
				else:
					log.error("Table does not exist")
					break
			except Exception as e:
				log.error(e)
			finally:
				if(connection_hadoop_internal != None): 
					connection_hadoop_internal.close()

if __name__ == "__main__":
	if (len(sys.argv)==2):
		try:
			datetime.strptime(str(sys.argv[1]), '%Y-%m-%d')
			raw_data_download(date = str(sys.argv[1]))
		except Exception as e:
			log.error(e)
	else:
		raw_data_download()
		
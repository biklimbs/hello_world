import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pandas as pd


def main(base_data_df):
	max = base_data_df['t_weight'].max()
	base_data_df["confidence"]=round((base_data_df["t_weight"]/(max))*100,2)
	base_data_df=base_data_df.sort_values(by='confidence', ascending=False)
	base_data_df=base_data_df.reset_index(drop=True)
	return base_data_df


def get_confidence(base_data_df):
	return main(base_data_df)
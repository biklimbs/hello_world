import sys, traceback
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
from termcolor import colored
from constants import *
from logger_config import log


FILE_FLAG = True
try:
	import linecleaning_common as lcc
	from linecleaning_common import check_if_Table_exits
	from linecleaning_common import check_connection
	from linecleaning_common import check_if_DB_exists
	from linecleaning_common import connect_to_db
	from linecleaning_common import network_call
except Exception as e:
	log.error("linecleaning_common.py file not found.")
	FILE_FLAG=False

def check_table_exits_poured_sold(connection_to_db):
	api_download_poured_sold_exists = check_if_Table_exits(connection_to_db,API_DOWNLOAD_POURED_SOLD_TABLE)
	poured_sold_exists = check_if_Table_exits(connection_to_db,POURED_SOLD_TABLE)
	return api_download_poured_sold_exists,poured_sold_exists

def check_table_exits_norm_poured_sold(connection_to_db):
	norm_poured_exists = check_if_Table_exits(connection_to_db,NORM_POURED_SOLD_TABLE)
	norm_poured_duplicate_exists = check_if_Table_exits(connection_to_db,NORM_POURED_SOLD_TABLE_DUPLICATE)
	return norm_poured_exists,norm_poured_duplicate_exists

def check_table_exits_location_date(connection_to_db):
	location_date_exists = check_if_Table_exits(connection_to_db,LOCATION_DATE_TABLE)
	location_date_duplicate_exists = check_if_Table_exits(connection_to_db,LOCATION_DATE_TABLE_DUPLICATE)
	return location_date_exists,location_date_duplicate_exists

def truncate_table(connection_to_db,table_name):
	message_truncate = ""
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="TRUNCATE TABLE "+table_name+";"	
			hadoop_cursor.execute(sql)
			message_truncate = "Success"
	except Exception as e:
		log.critical(e)
		message_truncate = e
	finally:
		return message_truncate

def insert_distinct_to_poured_sold():
	if (FILE_FLAG == True):
		try:
			connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
		except Exception as e:
			log.error(e)
			log.critical(colored("Network Error.",'red'))
			return "Network Error."
			
		if(check_if_DB_exists(connection_check)==None):
			return "Database "+MY_SQL_DB_NAME+" not found."
		try:
			connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		except Exception as e:
			log.critical(e)
			log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
			return "Database "+MY_SQL_DB_NAME+" connection not established."

		api_download_poured_sold_exists,poured_sold_exists = check_table_exits_poured_sold(connection_to_db)

		if(api_download_poured_sold_exists!=True):
			return "Table "+API_DOWNLOAD_POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."
		elif (poured_sold_exists!=True):
			return "Table "+POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

		message_insert = ""
		try:
			with connection_to_db.cursor() as hadoop_cursor:
				sql="insert into "+ POURED_SOLD_TABLE+" select distinct NULL,date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,line_id,quantity,pluNumber from "+API_DOWNLOAD_POURED_SOLD_TABLE +" ;"		
				print(sql)
				print (hadoop_cursor.execute(sql))
			connection_to_db.commit()

			message_insert = truncate_table(connection_to_db,API_DOWNLOAD_POURED_SOLD_TABLE)

		except Exception as e:
			log.error(e)
			message_insert = e
			
		finally:
			if (connection_to_db != None):
				connection_to_db.close()
			return message_insert
	else:
		return "linecleaning_common.py file not found."


def check_duplicates_in_poured_sold():
	if (FILE_FLAG == True):
		try:
			connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
		except Exception as e:
			log.error(e)
			log.critical(colored("Network Error.",'red'))
			return "Network Error."
			
		if(check_if_DB_exists(connection_check)==None):
			return "Database "+MY_SQL_DB_NAME+" not found."
		try:
			connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		except Exception as e:
			log.critical(e)
			log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
			return "Database "+MY_SQL_DB_NAME+" connection not established."

		api_download_poured_sold_exists,poured_sold_exists = check_table_exits_poured_sold(connection_to_db)

		if(api_download_poured_sold_exists!=True):
			return "Table "+API_DOWNLOAD_POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."
		elif (poured_sold_exists!=True):
			return "Table "+POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

		message_insert = ""
		try:
			with connection_to_db.cursor() as hadoop_cursor:
				sql = "SELECT date,count(date),user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,line_id,quantity,pluNumber  FROM "+POURED_SOLD_TABLE+" group by date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,line_id,quantity,pluNumber having (count(date)>1) AND (count(user_id)>1) AND (count(user_name)>1) AND (count(location_id)>1) AND (count(location_name)>1) AND (count(product_id)>1) AND (count(product_name)>1) AND (count(poured)>1) AND (count(sold)>1) AND (count(line_cleaning)>1) AND (count(line_number)>1) AND (count(line_id)>1) AND (count(quantity)>1) AND (count(pluNumber)>1)";
				data=network_call(sql,hadoop_cursor)
				if (len(data)>0):
					log.info("Duplicates detected in "+POURED_SOLD_TABLE+" Table")
					message_insert = truncate_table(connection_to_db,API_DOWNLOAD_POURED_SOLD_TABLE)
					if (message_insert == "Success"):
						sql="insert into "+ API_DOWNLOAD_POURED_SOLD_TABLE+" select distinct NULL,date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,line_id,quantity,pluNumber from "+POURED_SOLD_TABLE +" ;"		
						hadoop_cursor.execute(sql)
						log.info("INSERTED into "+API_DOWNLOAD_POURED_SOLD_TABLE+" Table")
						message_insert = truncate_table(connection_to_db,POURED_SOLD_TABLE)
						if (message_insert == "Success"):
							log.info("TRUNCATED "+POURED_SOLD_TABLE+" Table")
							sql="insert into "+ POURED_SOLD_TABLE+" select distinct NULL,date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,line_id,quantity,pluNumber from "+API_DOWNLOAD_POURED_SOLD_TABLE+" ;"		
							hadoop_cursor.execute(sql)
							log.info("INSERTED into "+POURED_SOLD_TABLE+" Table")
							message_insert = truncate_table(connection_to_db,API_DOWNLOAD_POURED_SOLD_TABLE)
							log.info("TRUNCATED "+API_DOWNLOAD_POURED_SOLD_TABLE+" Table")
							check_duplicates_in_poured_sold()
				else:
					log.info("No Duplicates detected in "+POURED_SOLD_TABLE+" Table")
					message_insert = "Success"
		except Exception as e:
			log.error(e)
			message_insert = e
			
		finally:
			if (connection_to_db != None):
				connection_to_db.close()
			return message_insert
	else:
		return "linecleaning_common.py file not found."

def check_duplicates_in_norm_poured_sold():
	if (FILE_FLAG == True):
		try:
			connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
		except Exception as e:
			log.error(e)
			log.critical(colored("Network Error.",'red'))
			return "Network Error."
			
		if(check_if_DB_exists(connection_check)==None):
			return "Database "+MY_SQL_DB_NAME+" not found."
		try:
			connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		except Exception as e:
			log.critical(e)
			log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
			return "Database "+MY_SQL_DB_NAME+" connection not established."

		norm_poured_exists,norm_poured_duplicate_exists = check_table_exits_norm_poured_sold(connection_to_db)

		if(norm_poured_exists!=True):
			log.error ("Table "+NORM_POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database.")
			return "Table "+NORM_POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."
		elif (norm_poured_duplicate_exists!=True):
			log.error("Table "+NORM_POURED_SOLD_TABLE_DUPLICATE+" is not in the "+MY_SQL_DB_NAME+" Database.")
			return "Table "+NORM_POURED_SOLD_TABLE_DUPLICATE+" is not in the "+MY_SQL_DB_NAME+" Database."

		message_insert = ""
		try:
			with connection_to_db.cursor() as hadoop_cursor:
				sql = "SELECT date,count(date),time,user_id,location_id,location_name,product_id,product_name,poured,sold FROM "+NORM_POURED_SOLD_TABLE+" group by date,time,user_id,location_id,location_name,product_id,product_name,poured,sold having (count(date)>1) AND (count(time)>1) AND (count(user_id)>1) AND (count(location_id)>1) AND (count(location_name)>1) AND (count(product_id)>1) AND (count(product_name)>1) AND (count(poured)>1) AND (count(sold)>1);"
				data=network_call(sql,hadoop_cursor)
				if (len(data)>0):
					log.info("Duplicates detected in "+NORM_POURED_SOLD_TABLE+" Table")
					message_insert = truncate_table(connection_to_db,NORM_POURED_SOLD_TABLE_DUPLICATE)
					if (message_insert == "Success"):
						log.info("TRUNCATED "+NORM_POURED_SOLD_TABLE_DUPLICATE+" Table")
						sql="insert into "+ NORM_POURED_SOLD_TABLE_DUPLICATE+" select distinct NULL,date,time,user_id,location_id,location_name,product_id,product_name,line_number,poured,sold from "+NORM_POURED_SOLD_TABLE +" ;"		
						print (sql)
						hadoop_cursor.execute(sql)
						log.info("INSERTED INTO "+NORM_POURED_SOLD_TABLE_DUPLICATE+" Table")
						message_insert = truncate_table(connection_to_db,NORM_POURED_SOLD_TABLE)
						log.info("TRUNCATED "+NORM_POURED_SOLD_TABLE+" Table")
						if (message_insert == "Success"):
							sql="insert into "+ NORM_POURED_SOLD_TABLE+" select distinct NULL,date,time,user_id,location_id,location_name,product_id,product_name,line_number,poured,sold from "+NORM_POURED_SOLD_TABLE_DUPLICATE +" ;"
							hadoop_cursor.execute(sql)
							log.info("INSERTED INTO "+NORM_POURED_SOLD_TABLE+" Table")
							message_insert = truncate_table(connection_to_db,NORM_POURED_SOLD_TABLE_DUPLICATE)
							check_duplicates_in_norm_poured_sold()
				else:
					log.info("No Duplicates detected in "+NORM_POURED_SOLD_TABLE+" Table")
					message_insert = "Success"
		except Exception as e:
			log.error(e)
			message_insert = e
			
		finally:
			if (connection_to_db != None):
				connection_to_db.close()
			return message_insert
	else:
		return "linecleaning_common.py file not found."

def check_and_remove_duplicates_in_poured_sold():
	if (insert_distinct_to_poured_sold()=="Success"):
		return check_duplicates_in_poured_sold()
	else:
		return "failure"
# def check_duplicates_in_location_date_table():
# 	if (FILE_FLAG == True):
# 		try:
# 			connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
# 		except Exception as e:
# 			log.error(e)
# 			log.critical(colored("Network Error.",'red'))
# 			return "Network Error."
			
# 		if(check_if_DB_exists(connection_check)==None):
# 			return "Database "+MY_SQL_DB_NAME+" not found."
# 		try:
# 			connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
# 		except Exception as e:
# 			log.critical(e)
# 			log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
# 			return "Database "+MY_SQL_DB_NAME+" connection not established."

# 		location_date_exists,location_date_duplicate_exists = check_table_exits_location_date(connection_to_db)

# 		if(location_date_exists!=True):
# 			return "Table "+LOCATION_DATE_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."
# 		elif (location_date_duplicate_exists!=True):
# 			return "Table "+LOCATION_DATE_TABLE_DUPLICATE+" is not in the "+MY_SQL_DB_NAME+" Database."

# 		message_insert = ""
# 		try:
# 			with connection_to_db.cursor() as hadoop_cursor:
# 				sql = "SELECT user_id,count(user_id),user_name,location_id,location_name,date FROM "+LOCATION_DATE_TABLE+" group by user_id,user_name,location_id,location_name,date having (count(user_id)>1) AND (count(user_name)>1) AND (count(location_id)>1) AND (count(location_name)>1) AND (count(date)>1);" 
# 				data=network_call(sql,hadoop_cursor)
# 				if (len(data)>0):
# 					log.info("Duplicates detected in "+LOCATION_DATE_TABLE+" Table")
# 					message_insert = truncate_table(connection_to_db,LOCATION_DATE_TABLE_DUPLICATE)
# 					if (message_insert == "Success"):
# 						sql="insert into "+ LOCATION_DATE_TABLE_DUPLICATE+" select distinct (NULL,user_id,user_name,location_id,location_name),rawflag,normflag,variance,disdate from "+LOCATION_DATE_TABLE +" ;"		
# 						print (sql)
# 						hadoop_cursor.execute(sql)
# 						log.info("INSERTED into "+LOCATION_DATE_TABLE_DUPLICATE+" Table")
# 						message_insert = truncate_table(connection_to_db,LOCATION_DATE_TABLE)
# 						if (message_insert == "Success"):
# 							log.info("TRUNCATED"+LOCATION_DATE_TABLE+" Table")
# 							sql="insert into "+ LOCATION_DATE_TABLE+" select distinct NULL,user_id,user_name,location_id,location_name,rawflag,normflag,variance,date from "+LOCATION_DATE_TABLE_DUPLICATE +" ;"		
# 							hadoop_cursor.execute(sql)
# 							log.info("INSERTED into "+LOCATION_DATE_TABLE+" Table")
# 							message_insert = truncate_table(connection_to_db,LOCATION_DATE_TABLE_DUPLICATE)
# 							log.info("TRUNCATED"+LOCATION_DATE_TABLE_DUPLICATE+" Table")
# 							check_duplicates_in_location_date_table()
# 				else:
# 					log.info("No Duplicates detected in "+LOCATION_DATE_TABLE+" Table")
# 		except Exception as e:
# 			log.error(e)
# 			message_insert = e
			
# 		finally:
# 			if (connection_to_db != None):
# 				connection_to_db.close()
# 			return message_insert
# 	else:
# 		return "linecleaning_common.py file not found."

#def main():
	#message_1 = insert_distinct_to_poured_sold()
	#message_2 = check_duplicates_in_poured_sold()
	#message_3 = check_duplicates_in_norm_poured_sold()
	#message_4 = check_duplicates_in_location_date_table()
	#print (message_4)

#main()
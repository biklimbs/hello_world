import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
from os import listdir
import csv
import pandas as pd
import datetime
from logger_config import log

accuracy_folder = "result_accuracy"
v3_gt_results_folder= "./Ground Truth/gt"
LINE_CLEANING_CONFIDENCE = 79

def find_csv_filenames( path_to_dir, suffix=".csv" ):
    filenames = listdir(path_to_dir)
    return [ filename for filename in filenames if filename.endswith( suffix ) ]

def get_accuracy():
	filenames = find_csv_filenames(v3_gt_results_folder)
	accuracy_df = pd.DataFrame(columns = ['file_name','number_of_results','gt','line_clening_predicted','correctly_predicted','false_positive','false_positive_percentage',
		'false_negative','false_negative_percentage','accuracy_percentage'])
	for name in filenames:
		v3_results_df = pd.read_csv(v3_gt_results_folder+"/"+name)
		total_length = len(v3_results_df)
		
		df_gt = v3_results_df[v3_results_df['gt'] == 1]
		line_clening_predected = v3_results_df[v3_results_df['tot_weight'] >= LINE_CLEANING_CONFIDENCE]
		false_positive_df = v3_results_df[(v3_results_df['gt'] == 0) & (v3_results_df['tot_weight'] >=LINE_CLEANING_CONFIDENCE)]
		false_negative_df = v3_results_df[(v3_results_df['gt'] == 1) & (v3_results_df['tot_weight'] <LINE_CLEANING_CONFIDENCE)]

		correctly_predicted_df = v3_results_df[(v3_results_df['gt'] == 1) & (v3_results_df['tot_weight'] >=LINE_CLEANING_CONFIDENCE)]

		number_of_gt = len(df_gt)
		line_clening_predected_len = len(line_clening_predected)
		number_of_false_posative = len(false_positive_df)
		number_of_false_negative = len(false_negative_df)
		number_of_correctly_predicted = len(correctly_predicted_df)
		log.debug ("-------------------------------------------------------")
		log.debug  (number_of_false_posative)
		log.debug  (number_of_false_negative)
		log.debug  (len(v3_results_df))
		
		false_positive_percentage = round((number_of_false_posative/len(v3_results_df))*100,2)
		false_negative_percentage = round((number_of_false_negative/len(v3_results_df))*100,2)
		if (number_of_correctly_predicted == 0 and number_of_gt == 0 and line_clening_predected_len == 0):
			percentage = 100
		elif (number_of_correctly_predicted == 0 and number_of_gt == 0 and line_clening_predected_len > 0):
			percentage = 0
		elif (number_of_correctly_predicted == 0 and number_of_gt > 0):
			percentage = 0
		elif(line_clening_predected_len>number_of_gt): 
			percentage = round(number_of_correctly_predicted/line_clening_predected_len*100,2)
		else:
			percentage = round(number_of_correctly_predicted/number_of_gt*100,2)
		log.debug  (percentage)
		log.debug  ("-------------------------------------------------------")
		name_s_list = name.split("_gt")
		accuracy_df.loc[len(accuracy_df)]=[name_s_list[0],len(v3_results_df),number_of_gt,line_clening_predected_len,number_of_correctly_predicted,number_of_false_posative,false_positive_percentage,number_of_false_negative,false_negative_percentage,percentage]
	date_current = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

	'''
	Total Accuracy
	'''
	# total_accuracy = round((accuracy_df['accuracy_percentage'].sum())/len(accuracy_df),2)
	# accuracy_df.loc[len(accuracy_df)]=["Total accuracy",total_accuracy]

	accuracy_df.to_csv(v3_gt_results_folder+"/"+accuracy_folder+"/"+date_current+".csv")
	return "Success"

def main():
	resp=get_accuracy()
	return resp

if __name__=="__main__":
	main()
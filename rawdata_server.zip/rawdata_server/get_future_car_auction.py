
import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import json
import csv
import pandas as pd
from time import sleep
import datetime
import traceback
from datetime import datetime, time
from flask import Flask, render_template, request,Response,redirect,url_for,Markup
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
import random
sys.path.append('./../misc/data_wrangling/')


MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME = 'japan_auction'


TABLE='car_future'
DOWNLOADFLAGTABLE='download_flag_future'
# COMPANY='HONDA

def api_call_get_marka():
    response  = ""
    while (response == ""):
        try:
        	# print(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC")
        	# response = requests.get(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC",timeout = 6000) # for only L1 Queue exceptions for limit of 1000
        	response = requests.get("http://75.125.226.218/xml/json?code=y19Hfrte_Dm&sql=select+distinct%28MARKA_NAME%29+from+stats",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()

#----------- Rest API where returns response in json fromat ----------
def api_call(COMPANY):
    response  = ""
    while (response == ""):
        try:
        	# print(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC")
        	# response = requests.get(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC",timeout = 6000) # for only L1 Queue exceptions for limit of 1000
        	response = requests.get("http://75.125.226.218/xml/json?code=y19Hfrte_Dm&sql=select+distinct%28MODEL_NAME%29+from+stats+where+MARKA_NAME%3D%27"+COMPANY+"%27",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()

def api_call_model(COMPANY,model):
    response  = ""
    while (response == ""):
        try:
        	# print(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC")
        	# response = requests.get(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC",timeout = 6000) # for only L1 Queue exceptions for limit of 1000
        	response = requests.get("http://75.125.226.218/xml/json?code=y19Hfrte_Dm&sql=select+*+from+stats+where+MARKA_NAME%3D%27"+COMPANY+"%27+and+MODEL_NAME%3D%27"+model+"%27",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()

#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)

	return connection_hadoop_check

def chcek_dupicates():
	QUERY="SELECT distinct date,company,model FROM japan_auction.download_flag;"

# #-----------Establishing Connection to MySQL Server ----------         
# connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)

# print(str(api_call('2018-06-10')['ViewModels'][0]['CreatedAt'])[:10])

def insert_to_table(connection_hadoop_internal,ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,MIL_ST,EQUIP,RATE,START,FINISH,STATUS,TIME,IMAGES):
	try:
		sql_=""
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			today_=str(str(datetime.today())[:16])
			# if(PW == ""):
			# 	# print(type(PW))
			# 	sql = "insert into "+TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,MIL_ST,EQUIP,RATE,START,FINISH,STATUS,TIME,IMAGES,LOCAL_TIME) VALUES('"+ID+"',"+LOT+",'"+AUCTION_DATE+"','"+AUCTION+"',"+MARKA_ID+","+MODEL_ID+",'"+MARKA_NAME+"','"+MODEL_NAME+"',"+YEAR+",'"+ENG_V+"',' ','"+KUZOV+"','"+GRADE+"','"+COLOR+"','"+KPP+"',"+KPP_TYPE+",'"+PRIV+"','"+MILEAGE+"',"+MIL_ST+",'"+EQUIP+"','"+RATE+"',"+START+",'"+FINISH+"','"+STATUS+"','"+TIME+"',\""+IMAGES+"\",'"+today_+"')"
			# 	sql_= "insert into "+TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,MIL_ST,EQUIP,RATE,START,FINISH,STATUS,TIME,IMAGES,LOCAL_TIME) VALUES('"+ID+"',"+LOT+",'"+AUCTION_DATE+"','"+AUCTION+"',"+MARKA_ID+","+MODEL_ID+",'"+MARKA_NAME+"','"+MODEL_NAME+"',"+YEAR+",'"+ENG_V+"',' ','"+KUZOV+"','"+GRADE+"','"+COLOR+"','"+KPP+"',"+KPP_TYPE+",'"+PRIV+"','"+MILEAGE+"',"+MIL_ST+",'"+EQUIP+"','"+RATE+"',"+START+",'"+FINISH+"','"+STATUS+"','"+TIME+"',\""+IMAGES+"\",'"+today_+"')"
			# 	# print(sql_)
			# 	hadoop_cursor.execute(sql)

			# else:
			sql = "insert into "+TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,MIL_ST,EQUIP,RATE,START,FINISH,STATUS,TIME,IMAGES,LOCAL_TIME) VALUES('"+ID+"',"+LOT+",'"+AUCTION_DATE+"','"+AUCTION+"',"+MARKA_ID+","+MODEL_ID+",'"+MARKA_NAME+"','"+MODEL_NAME+"',"+YEAR+",'"+ENG_V+"','"+str(PW)+"','"+KUZOV+"','"+GRADE+"','"+COLOR+"','"+KPP+"',"+KPP_TYPE+",'"+PRIV+"','"+MILEAGE+"',"+MIL_ST+",'"+EQUIP+"','"+RATE+"',"+START+",'"+FINISH+"','"+STATUS+"','"+TIME+"',\""+IMAGES+"\",'"+today_+"')"
			sql_= "insert into "+TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,MIL_ST,EQUIP,RATE,START,FINISH,STATUS,TIME,IMAGES,LOCAL_TIME) VALUES('"+ID+"',"+LOT+",'"+AUCTION_DATE+"','"+AUCTION+"',"+MARKA_ID+","+MODEL_ID+",'"+MARKA_NAME+"','"+MODEL_NAME+"',"+YEAR+",'"+ENG_V+"','"+str(PW)+"','"+KUZOV+"','"+GRADE+"','"+COLOR+"','"+KPP+"',"+KPP_TYPE+",'"+PRIV+"','"+MILEAGE+"',"+MIL_ST+",'"+EQUIP+"','"+RATE+"',"+START+",'"+FINISH+"','"+STATUS+"','"+TIME+"',\""+IMAGES+"\",'"+today_+"')"
				# print(sql_)
					# print(sql_)
			hadoop_cursor.execute(sql)

			connection_hadoop_internal.commit()

	except Exception as e:
		print(e)
		print(sql_)

def insert_to_download_flag(connection_hadoop_internal,date,localdate,company,companyflag,model,modelflag):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql="insert into "+DOWNLOADFLAGTABLE+" (date,localdate,company,companyflag,model,modelflag) VALUES('"+date+"','"+localdate+"','"+company+"',"+companyflag+",'"+model+"',"+modelflag+")"
			hadoop_cursor.execute(sql)
		connection_hadoop_internal.commit()
	except Exception as e :
		print(e)


def update_companyflagandmodelflag(connection_hadoop_internal,company,model):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql1="SET SQL_SAFE_UPDATES=0;"
			sql="update "+DOWNLOADFLAGTABLE+" set companyflag= 1 , modelflag= 1 where company= '"+company+"' and model= '"+model+"';"
			print(sql)
			hadoop_cursor.execute(sql1)
			hadoop_cursor.execute(sql)
		connection_hadoop_internal.commit()
	except Exception as e :
		print(e)

def main():
	# res_={'country':{'car'"['sds','sds']"},{'car'"['sds','sds']"}}
	# country={}
	# model={}
	connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	# model=[]
	try:
		for company in api_call_get_marka():
		# print(api_call())
			for  model in api_call(str(company['TAG0'])):
				# if(str(x['TAG0']) in model):
				# 	pass
				# 	# company[str(x['TAG0'])]=api_call_model(str(x['TAG0']))
				# else:
				car_models=list(api_call_model(str(company['TAG0']),str(model['TAG0'])))
				# print(car_models)
				today_=str(str(datetime.today())[:16])
				start_time=t.time()
				if(int(len(car_models))>0):
					insert_to_download_flag(connection_hadoop_internal,car_models[0]['TIME'],today_,car_models[0]['MARKA_NAME'],"0",car_models[0]['MODEL_NAME'],"0")
					# log.info(car_models)
					for car_model in range(int(len(car_models))):
						# start_time=t.time()
						today_=str(str(datetime.today())[:16])
						car_model_details=car_models[car_model]
						insert_to_table(connection_hadoop_internal,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],car_model_details['COLOR'],car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['MIL_ST'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],car_model_details['IMAGES'])
					end_time=t.time()-start_time
					log.info("time taken to download "+str(model['TAG0'])+"  "+str(end_time))
					update_companyflagandmodelflag(connection_hadoop_internal,str(car_models[0]['MARKA_NAME']),str(car_models[0]['MODEL_NAME']))
						# sys.exit()
						# sleep(random.randint(1,10))
						# sys.exit()
					log.info(str(model['TAG0']))
					# log.info(str(x['TAG0']))
					sleep(random.randint(45,60))
				else:
					log.info("NO data fouund for "+ str(company['TAG0']) )
			log.info("Data download Completed for "+ str(company['TAG0']) )
			
		
		
	except Exception as e:
		print(e)



main()

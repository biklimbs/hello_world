import paramiko

source = r'/home/vmuser/bb_automate/rawdata/rawView/2018-08-01_L1.csv'
dest = r'/home/pavan//Documents/'
hostname = 'hadoop.vmokshagroup.com'
port = 2345 # default port for SSH
username = 'vmuser'
password = 'Iot@1234'

try:
    t = paramiko.Transport((hostname, port))
    t.connect(username=username, password=password)
    sftp = paramiko.SFTPClient.from_transport(t)
    sftp.put(source, dest)
except Exception as e:
	print(e)
finally:
    t.close()

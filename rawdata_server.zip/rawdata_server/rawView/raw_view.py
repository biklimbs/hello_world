import os
import csv
import pandas as pd
import pymysql
from flask import Flask, render_template, request,Response,redirect,url_for,Markup
import requests
import tablib
from datetime import datetime
from operator import itemgetter
import os
import glob


app = Flask(__name__)
Basic_URL="http://betaapi.beerboard.com/nodejsserver/getLineCleaningData?date="
secondary_URL="&locationid="

#----------- Rest API where returns response in json fromat ----------
def api_call(sele_date,loc):
    response  = ""
    while (response == ""):
        try:
        	# print(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC")
        	# response = requests.get(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC",timeout = 6000) # for only L1 Queue exceptions for limit of 1000
        	print(Basic_URL+sele_date+secondary_URL+loc)
        	response = requests.get(Basic_URL+sele_date+secondary_URL+loc,timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()


def int_validate(val):
	try:
		int(val)
		return "True"
	except ValueError:
		return "False"
	except Exception as e:
		return str(e)

#-----------Validating date format  ----------         
def validate(date_text):
    try:
        datetime.strptime(date_text, '%Y-%m-%d')
        return True
    except Exception as e:
        return False

def get_foramte_csv(json):
	try:
		res_array=[]
		# print(len(json))
		for i in range(len(json)):
			
			x=json[i]
			# print(x['Poured'])
			ind_array=[]	
			
			ind_array.append(str(x['product']))
			if('Poured' not in x):
			
				ind_array.append(0)
			else:
				ind_array.append(str(str(x['Poured']).split(" oz")[0]))

			if('sold' not in x):
				ind_array.append(0)
			else:
				ind_array.append(str(x['sold']))

			ind_array.append(str(str(x['timekey']).split(" ")[1]))
			res_array.append(ind_array)
		# print(table_row)
	except Exception as e:
		print(e)
	return res_array
	# print(res_array)
			# {'Poured': '18.80 oz', 'lineCleaning': 0, 'product': 'Stella Artois', 'timekey': '2018-06-03 13:01:42', 'lineNo': '11'}


def write_csv(file_name, list_of_rows, header):   
    
    with open(file_name, 'w',encoding="utf-8",newline='') as f:
        csv_writer=csv.DictWriter(f, header)
        csv_writer.writeheader()      
        for row in list_of_rows:      
            row_unicode={}      
            for k, v in zip(header, row):
                v=str(v)       
                row_unicode[k]=v      
            csv_writer.writerow(row_unicode)   

def convert_to_html(sor_):
	res_row=""
	boolena=True
	for x in sor_:
		if boolena:
			res_row=res_row+"<tr bgcolor='#99ddff' ><td>"+str(x[0])+"</td><td>"+str(x[1])+"<td>"+str(x[2])+"</td><td>"+str(x[3])+"<td></tr>"
			boolena=False
		else:
			res_row=res_row+"<tr><td>"+str(x[0])+"</td><td>"+str(x[1])+"<td>"+str(x[2])+"</td><td>"+str(x[3])+"<td></tr>"
			boolena=True
	return res_row
            

@app.route("/")
def index():
	for x in glob.glob('*.csv'):
		os.remove(x)
	return render_template("daterange.html")


# @app.route("/Fil")
# def index():
# 	return render_template("Fil.html",)

@app.route("/getdata",methods = [ 'POST'])
def getdata():
	for x in glob.glob('*.csv'):
		os.remove(x)
	print(request.form)
	try:
		if(str(int_validate(request.form['locationid']))=='True' and validate(str(request.form['date']))):
			response=api_call(str(request.form['date']),str(request.form['locationid']))
			poured=get_foramte_csv(response.get("poured"))
			sold=get_foramte_csv(response.get("sold"))
			res_array_p_s1=list(poured + sold)

			res_array_p_s=[list(t) for t in set(tuple(element) for element in res_array_p_s1)]

			# print(list(tuple(element) for element in res_array_p_s))

			time_sor_=sorted(res_array_p_s, key=itemgetter(3))
			sor_=sorted(time_sor_, key=itemgetter(0))
			name= convert_to_html(sor_)
			# write_csv(str(request.form['date'])+"_"+str(request.form['locationid'])+".csv",sor_, [' product ',' Poured ',' sold ',' time '])
			# dataset = tablib.Dataset(delimiter=',')
			# with open(os.path.join(os.path.dirname(__file__),str(request.form['date'])+"_"+str(request.form['locationid'])+".csv")) as f:
			# 	dataset.csv = f.read()

		else:
			print("Something went Wrong")

		# request.form['search_loc']
		# [('date', '2018-05-30'), ('date', '123')]
		# print(int(request.form['locationid']))
		
		# return render_template("daterange.html")
		return render_template("Fil.html",name=Markup(name))
	except Exception as e:
		print(e)
		return str(e)
	except ValueError:
		print("That's not an int!")



if __name__ == "__main__":
    app.run(host='0.0.0.0' ,port=85)

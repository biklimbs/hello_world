import os
import paramiko
# paramiko.util.log_to_file('/tmp/paramiko.log')
# paramiko.util.load_host_keys(os.path.expanduser('~/.ssh/known_hosts'))

host = 'hadoop.vmokshagroup.com'
port = 2345
username = 'vmuser'

files = ['file1', 'file2', 'file3', 'file4']
remote_images_path = '/remote_path/images/'
local_path = '/tmp/'

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(
            paramiko.AutoAddPolicy())
ssh.connect(hostname=host, port=port, username=username)
sftp = ssh.open_sftp()


file_remote ='/home/vmuser/bb_automate/rawdata/rawView/2018-08-01_L1.csv'
file_local = '/tmp/' + '2018-08-01_L1.csv'

print (file_remote + '>>>' + file_local)

sftp.get(file_remote, file_local)

sftp.close()
ssh.close()


import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import json
import csv
import pandas as pd
from time import sleep
import datetime
# import traceback
from datetime import datetime, time
from flask import Flask, render_template, request,Response,redirect,url_for,Markup
from termcolor import colored
import os, inspect
from datetime import date, timedelta
import random


MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME = 'cawm_stats'


TABLE='count_stats'
BASE_URL="http://75.125.226.218/xml/json?&ip='10.10.0.0'&code=y19Hfrte_Dm&sql="


#----------- Rest API where returns response in json fromat ----------
def get_count(start_time,end_limt):
    response  = ""
    while (response == ""):
        try:
        	start_time=start_time
        	start_time_split=start_time.split(" ")
        	end_limt=end_limt
        	end_limt_split=end_limt.split(" ")
        	response = requests.get(BASE_URL+"select+count%28*%29+from+main+where+TIME+between++%27"+str(start_time_split[0]).replace(' ','+')+"%25%27+and+%27"+str(end_limt_split[0]).replace(' ','+')+"+23%25%27",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        	# print("http://75.125.226.218/xml/json?code=y19Hfrte_Dm&sql=select+count%28*%29+from+stats+where+TIME+between++%27"+str(start_time_split[0]).replace(' ','+')+"%3A"+str(start_time_split[1])+"%25%27+and+%27"+str(end_limt_split[0]).replace(' ','+')+"%3A"+str(end_limt_split[1])+"%25%27")
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()

#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		print(e)
		# traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			print(e)
			t.sleep(30)

	return connection_hadoop_check




def insert_to_table(json_obj):
	try:
		connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)	
		sql_=""
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			# print(PW == "")
			today_=str(str(datetime.today())[:19])
			count=str(json_obj[0]['TAG0'])
			sql = "insert into "+TABLE+" (LOCAL_TIME,COUNT) VALUES('"+today_+"',"+count+")"
			print(sql)
			# # # print(sql_)
			hadoop_cursor.execute(sql)
			
			connection_hadoop_internal.commit()
	except Exception as e:
		print(e)
		print(sql_)

count=0
while True:
	import time
	e_time=str(datetime.now().strftime("%Y-%m-%d %H:%M"))
	s_time=str(str(datetime.now() - timedelta(days=2))[:16])
	insert_to_table(get_count(s_time,e_time))
	time.sleep(3600)


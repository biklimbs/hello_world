import pandas as pd
import numpy as np
import pymysql.cursors
from random import shuffle,sample,randrange
import traceback
import sys

# SEARCH_MAKE=sys.argv[1]
# SEARCH_MODEL=sys.argv[2]
# SEARCH_YEAR=''
# SEARCH_KUZOV=sys.argv[3]
# SEARCH_COLOR=''
# SEARCH_MILEAGE=''

MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME = 'japan_car_algo'
TABLE = 'web_one_week_history'


def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
    
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)

	return connection_hadoop_check


def get_avg_price(company,model,year, mileage,kuzov,rate,color):
	try:
		price = 0
		success = False
		message = ""
		connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		sql_empty = "select FINISH FROM "+TABLE
		sql_where = "select AUCTION_DATE,FINISH,YEAR,MILEAGE FROM "+TABLE+" Where AUCTION not like 'USS%' and FINISH != 0 and STATUS='SOLD' and "
		sql = sql_empty
		if (company == "" and model == "" and year == "" and mileage == "" and kuzov == ""):
			#sql = sql_empty
			price = 0
			success = False
			message = "No Configuration Selected."
			return price, success, message
		else:
			sql = sql_where
			if (company != ""):
				sql = sql+"MARKA_NAME = \""+company+"\""+" and "

			if (model != ""):
				sql = sql+"MODEL_NAME = \""+model+"\""+" and "

			if (year != ""):
				sql = sql+"YEAR = "+year+" and "

			if (mileage != ""):
				sql = sql+"MILEAGE >= "+mileage+" and "

			if (kuzov != ""):
				sql = sql+"KUZOV = \""+kuzov+"\""+" and "

			if (rate != ""):
				sql = sql+"RATE = \""+rate+"\""+" and "

			if (color != ""):
				sql = sql+"COLOR = \""+color+"\""+" and "

			sql = sql[0:-4]
			# print (sql) 

			try:
				with connection_hadoop_internal.cursor() as hadoop_cursor:
					hadoop_cursor.execute(sql)
					distinct_locatons = hadoop_cursor.fetchall()
					if (len(distinct_locatons)>0):
						res_df=pd.DataFrame(distinct_locatons)
						res_df= res_df.sort_values(by="AUCTION_DATE")
						# res_df=res_df.drop(res_df.index[len(res_df)-1])

						# print(res_df)
						if(len(res_df)>5):
							res_array = np.asarray(res_df["FINISH"])
							# print(res_array)
							res_df["FINISH"]=res_df["FINISH"].astype(int)
							print("BEFORE REMOVING OUTLIER MEAN:",round(res_df["FINISH"].mean(),2))
							print("BEFORE REMOVING OUTLIER MEDIAN:",res_df["FINISH"].median())
							max_value_outlier=res_df["FINISH"].mean() + 3 * res_df["FINISH"].std()
							min_value_outlier= res_df["FINISH"].mean() - 3 * res_df["FINISH"].std()
						 	# print(res_df)
							df_= res_df[(res_df["FINISH"] > int(min_value_outlier)) & (res_df["FINISH"] < int(max_value_outlier))]
							# print(df_)
							print("AFTER REMOVING OUTLIER MEAN:",round(df_["FINISH"].mean(),2))
							print("AFTER REMOVING OUTLIER MEDIAN:",df_["FINISH"].median())

							# price = round(df_["FINISH"].mean(),2)
							price = int(df_["FINISH"].median())
							success = True
							message = "success"
							return price, success, message
						else:
							res_df["FINISH"]=res_df["FINISH"].astype(int)
							# price = round(res_df["FINISH"].mean(),2)
							price =int(res_df["FINISH"].median())
							success = True
							message = "success"
							return price, success, message
					else:
						price = 0
						success = False
						message = "No cars found based on the above configuration."
						return price, success, message
			
			except Exception as e:
				traceback.print_exc()
				print(e)
				price = 0
				success = False
				message = str(e)
				return price, success, message
	except Exception as e:
		print(e)

def search_car(company,model,year, mileage,kuzov,rate,color):
	try:
		# print(company,model,year, mileage,kuzov,rate,color)
		return get_avg_price(company,model,year,mileage,kuzov,rate,color)
	except Exception as e:
		print(e)

if __name__=="__main__":
	search_make=str(sys.argv[1])
	search_model=str(sys.argv[2])
	search_kuzov=str(sys.argv[3])
	search_year=str(sys.argv[4])
	search_mileage=str(sys.argv[5])
	search_rate=str(sys.argv[6])
	search_color=str(sys.argv[7])
	print(get_avg_price(search_make,search_model,search_year,search_mileage,search_kuzov,search_rate,search_color))	 	
	

import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
sys.path.append('./../misc/data_wrangling/')


MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Power@1234'
MY_SQL_DB_NAME = 'exception_analysis'


TABLE='exception_frequency'

#----------- Url link to get exception details based on date ----------
Basic_URL="http://34.236.166.193:1342"
secondary_URL="/SBarException/?limit=1000&skip=0&where={\"ReportedDate\":\""



#----------- Rest API where returns response in json fromat ----------
def api_call(sele_date):
    response  = ""
    while (response == ""):
        try:
        	# print(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC")
        	# response = requests.get(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC",timeout = 6000) # for only L1 Queue exceptions for limit of 1000
        	response = requests.get(Basic_URL+secondary_URL+sele_date+"\"}&sort=Id ASC",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()


#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)

	return connection_hadoop_check




# #-----------Establishing Connection to MySQL Server ----------         
# connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)

# print(str(api_call('2018-06-10')['ViewModels'][0]['CreatedAt'])[:10])

def insert_to_table(connection_hadoop_internal,local_date,local_time,reported_date,reported_time,total):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql = "insert into "+TABLE+" (local_date,local_time,reported_date,reported_time,total) VALUES ('"+local_date+"','"+local_time+"','"+reported_date+"','"+reported_time+"','"+total+"')"
			hadoop_cursor.execute(sql)
		connection_hadoop_internal.commit()
	except Exception as e:
		print(e)


def main():
	try:
		connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		today_=str(datetime.today())
		date_to=str(datetime.today() - timedelta(days=2))
		date_to_api=str(str(date_to)[:10])
		if(len(api_call(date_to_api)['ViewModels'])>0):
			res=api_call(date_to_api)
			res_=res['ViewModels'][0]['CreatedAt']
			log.info(str(today_[:10])+" "+str(today_[11:16])+" "+str(res_[:10])+" "+str(res_[11:16])+" "+str(res['info']['total']))
			insert_to_table(connection_hadoop_internal,str(today_[:10]),str(today_[11:16]),str(res_[:10]),str(res_[11:16]),str(res['info']['total']))			
		else:
			log.info("DATA NOT YET UPDATED")
	except Exception as e:
		print(e)



while True:
	log.info("Started "+str(datetime.today()))
	main()
	t.sleep(1800)

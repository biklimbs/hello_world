
import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import json
import csv
import pandas as pd
from time import sleep
import datetime
import traceback
from datetime import datetime, time
from flask import Flask, render_template, request,Response,redirect,url_for,Markup
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
import random


MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME = 'stats'

INTERVAL=1800

BASE_URL="http://75.125.226.218/xml/json?&ip='10.10.0.0'&code=y19Hfrte_Dm&sql="
MAIN_URL=BASE_URL+"select+count%28*%29+from+stats+where+TIME+between++%27"
TAG_FOR_colon="%3A"
MIDDLE_URL="%25%27+and+%27"
END_URL="%25%27"

TABLE='stats_update_freq'



#----------- Rest API where returns response in json fromat ----------
def get_count(start_time,end_limt):
    response  = ""
    while (response == ""):
        try:
        	# print(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC")
        	# response = requests.get(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC",timeout = 6000) # for only L1 Queue exceptions for limit of 1000
        	start_time=start_time
        	start_time_split=start_time.split(":")
        	end_limt=end_limt
        	end_limt_split=end_limt.split(":")
        	response = requests.get(MAIN_URL+str(start_time_split[0]).replace(' ','+')+TAG_FOR_colon+str(start_time_split[1])+MIDDLE_URL+str(end_limt_split[0]).replace(' ','+')+TAG_FOR_colon+str(end_limt_split[1])+END_URL,timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        	# print("http://75.125.226.218/xml/json?code=y19Hfrte_Dm&sql=select+count%28*%29+from+stats+where+TIME+between++%27"+str(start_time_split[0]).replace(' ','+')+"%3A"+str(start_time_split[1])+"%25%27+and+%27"+str(end_limt_split[0]).replace(' ','+')+"%3A"+str(end_limt_split[1])+"%25%27")
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()

#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)

	return connection_hadoop_check


connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)

def insert_to_table(connection_hadoop_internal,json_obj,start_time,end_time):
	try:
		sql_=""
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			# print(PW == "")
			today_=str(str(datetime.today())[:19])
			count=str(json_obj[0]['TAG0'])
			# print(count,start_time,end_time)
			fmt = '%Y-%m-%d %H:%M'
			tstamp1 = datetime.strptime(str(start_time), fmt)
			tstamp2 = datetime.strptime(str(end_time), fmt)
			print(count,str(tstamp2 - tstamp1))
			# print(today_)
			# sys.exit()
			# print("insert into "+TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,EQUIP,RATE,START,FINISH,STATUS,TIME,AVG_PRICE,AVG_STRING,IMAGES,LOCAL_TIME) VALUES('"+ID+"',"+LOT+",'"+AUCTION_DATE+"','"+AUCTION+"',"+MARKA_ID+","+MODEL_ID+",'"+MARKA_NAME+"','"+MODEL_NAME+"',"+YEAR+",'"+ENG_V+"',"+str(c_pw)+",'"+KUZOV+"','"+GRADE+"','"+COLOR+"','"+KPP+"',"+KPP_TYPE+",'"+PRIV+"','"+MILEAGE+"','"+EQUIP+"','"+RATE+"',"+START+",'"+FINISH+"','"+STATUS+"','"+TIME+"',"+AVG_PRICE+",'"+AVG_STRING+"',\""+IMAGES+"\"'"+today_+"')")
			sql = "insert into "+TABLE+" (locarl_time,start_time,end_time,duration,count) VALUES('"+today_+"',\""+start_time+"\",\""+end_time+"\",\""+str(tstamp2 - tstamp1)+"\","+count+")"
			print(sql)
			# # # print(sql_)
			hadoop_cursor.execute(sql)
			
			connection_hadoop_internal.commit()
	except Exception as e:
		print(e)
		print(sql_)

c_time=str(datetime.now().strftime("%Y-%m-%d %H:%M"))
count=0
while True:
	import time
	c_time=str(datetime.now().strftime("%Y-%m-%d %H:%M"))

	count=count+1
	milliseconds = int(round(time.time() * 1000))
	print(milliseconds)
	insert_to_table(connection_hadoop_internal,get_count(c_time,str(datetime.fromtimestamp(int(int(milliseconds)+int(count*1800000))/1000.0))[0:16]),c_time,str(datetime.fromtimestamp(int(int(milliseconds)+1800000)/1000.0))[0:16])
	time.sleep(INTERVAL)

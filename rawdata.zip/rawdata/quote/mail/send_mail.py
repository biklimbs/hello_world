# Python code to illustrate Sending mail with attachments 
# from your Gmail account 
import sys
# libraries to be imported 
import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 
from constants import  *
from logger_config import *
import logger_config


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		Formatting Email with attachment,subject and body
def send_mail(fromaddr,from_password,toaddr,subject,body,file_name,to,country):
    try:
        # instance of MIMEMultipart 
        msg = MIMEMultipart() 

        # storing the senders email address 
        msg['From'] = fromaddr 

        # storing the receivers email address 
        msg['To'] = toaddr 

        # storing the subject 
        msg['Subject'] = subject

        # string to store the body of the mail 
        # body = "Body_of_the_mail"

        # attach the body with the msg instance 
        msg.attach(MIMEText(body, 'plain')) 

        try:
            # open the file to be sent 
            filename = PDF_FILE_NAME_EMAIL+str(str(file_name).split("/")[-1])
            attachment = open(filename, "rb") 
        except Exception as e:
            print(e)
            return False,"File doesn't exist"

        # instance of MIMEBase and named as p 
        p = MIMEBase('application', 'octet-stream') 

        # To change the payload into encoded form 
        p.set_payload((attachment).read()) 

        # encode into base64 
        encoders.encode_base64(p) 

        p.add_header('Content-Disposition', "attachment; filename= %s" % to+" "+country+".pdf") 

        # attach the instance 'p' to instance 'msg' 
        msg.attach(p) 

        # creates SMTP session 
        s = smtplib.SMTP('smtp.gmail.com', 587) 

        # start TLS for security 
        s.starttls() 

        try:
            # Authentication 
            s.login(fromaddr, from_password) 
        except Exception as e:
            print(e)
            print("Login Failure")
            return False,"Login Failure"

        # Converts the Multipart msg into a string 
        text = msg.as_string() 

        try:
            # sending the mail 
            s.sendmail(fromaddr, toaddr, text) 
        except Exception as e:
            print(e)
            return False,"Something went wrong"

        # terminating the session 
        s.quit()

        return True,"Sucess"
    except Exception as e :
        log.error(str(e) )
        return False,str(e)

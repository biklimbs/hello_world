# Description: history_html deals with reading records from csv and formating to readable HTML format.
# Author:  Pavan Kumar.C
# Created On: 30/11/2018
# Modified For:
# Modified On:
# Modified By:


from sql_helper import *
# constants.py not imported since it is imported in sql_helper
from logger_config import *
import logger_config

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		Updaing freight charges in to server table 
def update_freight_details(detailed_dic):
	try:
		safe_mode,query=get_update_query(detailed_dic)
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			cursor.execute(safe_mode)
			cursor.execute(query)
		connection_to_db.commit()
		return True
	except Exception as e:
		log.error(str(e))
		return False

#		Formatting update query  
def get_update_query(detailed_dic):
	portcode=detailed_dic['port_code']
	vesselCode=detailed_dic['vessel_code']
	cost=detailed_dic['cost']
	unit=detailed_dic['unit']
	shipmentTime=detailed_dic['ShipmentTime']
	vesselSchedule=detailed_dic['VesselSchedule']
	safe_mode="SET SQL_SAFE_UPDATES = 0;"
	if(detailed_dic['update_new']=='true'):
		query="UPDATE "+FREIGHT_TABLE+" SET cost = \""+cost +"\",unit =\""+unit+"\",shipmentTime =\""+shipmentTime+"\",vesselSchedule = \""+vesselSchedule+"\",dateModified =\""+str(t.strftime('%Y-%m-%d %H:%M:%S'))+"\"  WHERE portCode = "+portcode+" and vesselCode ="+vesselCode+";"
	else:
		present_id=str(get_max_id_freight()+1)
		query="INSERT INTO "+FREIGHT_TABLE+" VALUES("+present_id+",\""+present_id+"\",\""+portcode+"\",\""+vesselCode+"\",\""+cost+"\",\""+unit+"\",\""+shipmentTime+"\",\""+vesselSchedule+"\",\" \","+str('1')+",\"user\",\""+str(t.strftime('%Y-%m-%d %H:%M:%S'))+"\",\" \",\""+str(t.strftime('%Y-%m-%d %H:%M:%S'))+"\",\"1\")"
	return safe_mode,query

#		To get Maximum  id in table  
def get_max_id_freight():
	try:
		connection_to_db = connect_to_db(HOST_NAME,USER_NAME,PASSWORD,DB_NAME)
		with connection_to_db.cursor() as cursor:
			cursor.execute("SELECT max(id) as id FROM "+FREIGHT_TABLE+";")
			response=cursor.fetchall()
			return response[0]['id']
	except Exception as e:
		log.error(str(e))
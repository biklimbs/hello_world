# Description: history_helper deals with saving the record of request made in standard and customization.
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:

from logger_config import *
import logger_config
import time as t
import ast
import traceback
import json
import datetime
#from datetime import datetime, timezone

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#		To get recommendation cars in to html format
def get_recommendations_html(future_car_records_list):
	'''
	This function takes data in json form converts it into list of dictionary and calls 'grid_html_formatter' for preprocessing.
	'''
	try:
		#---Select first element from given list 'future_car_records_list'(i.e query result) and assign to variable---
		future_car_records=json.loads(future_car_records_list[0])
		start_time=t.time()
		records_html_format=""
		for record in future_car_records:
			records_html_format=records_html_format+grid_html_formatter(record)
		log.info("Time taken for recommendations HTML format :"+str(round(t.time()-start_time,2)))	
		return records_html_format
	except Exception as e:
		log.error(str(e))
		return False

#		To format recommendation of cars in to html form
def grid_html_formatter(record):
	'''
	This function takes dictionary as input and format it by including HTML tag to it for displaying in web browser.
	''' 
	start_tag="<div class=\"grid-item\" style=\"color: #99ddff;\">"
	end_tag="</div>"
	try:
		image = ast.literal_eval(record['s3_front_images'])
	except Exception as e:
		image=['Image not available']
		print(str(e))
	try:
		#---Converting epoch timestamp to custom format
		record['AUCTION_DATE']=int((record['AUCTION_DATE'])/1000)
		record['AUCTION_DATE']=datetime.datetime.fromtimestamp(record['AUCTION_DATE']).strftime('%Y-%m-%d %H:%M:%S')
	except Exception as e:
		print(str(e))
		
	try:
		content="<img src=\""+str(image[0])+"\" width=\"200\" height=\"185\"><br><div class=\"row\" ><div class=\"column\" style=\"width: 50%;float: left;\"><b><font color=\"black\">Make    		: "+record['MARKA_NAME']+"</font></b></div><div class=\"column\"><b><font color=\"black\">Model    		:  "+record['MODEL_NAME']+"</font></b></div></div><div class=\"row\" ><div class=\"column\" style=\"width: 50%;float: left;\"><b><font color=\"black\">Grade   		: "+record['GRADE']+	 "</font></b></div><div class=\"column\"><b><font color=\"black\">Rate   		: "+record['RATE']+"</font></b></div></div><div class=\"row\" ><div class=\"column\" style=\"width: 50%;float: left;\"><b><font color=\"black\">Chasis ID   	: "+record['KUZOV']+	 "</font></b></div><div class=\"column\"><b><font color=\"black\">Year   		: "+str(record['YEAR'])+"</font></b></div></div><div class=\"row\" ><div class=\"column\" style=\"width: 50%;float: left;\"><b><font color=\"black\">Color    		: "+record['COLOR']+     "</font></b></div><div class=\"column\"><b><font color=\"black\">Mileage   	: "+str(record['MILEAGE'])+"</font></b></div></div><div class=\"row\" ><div class=\"column\" style=\"width: 50%;float: left;\"><b><font color=\"black\">Auction Date	: "+str(record['AUCTION_DATE'])+ "</font></b></div><div class=\"column\"><b><font color=\"black\">Auction   	: "+record['AUCTION']+"</font></b></div> <div class=\"column\"><b><font color=\"black\">Price   	: "+str(record['AVG_PRICE'])+"</font></b></div></div>"
	except Exception as e:
		print(str(e))
		traceback.print_exc()
	return start_tag+content+end_tag
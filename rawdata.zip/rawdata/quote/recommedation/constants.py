MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME = 'recommendation_model'

TABLE = 'future_recommendation_preprocess'


RATE_LIST = ["***", "R", "RA", "1", "2", "3", "3.5", "4", "4.5", "5", "6", "S"]

LIMIT_COUNT=10
LIMIT_MIL=20000
LIMIT_YR=1
LIMIT_AVG_PRICE=25000

LIMIT_YR_MAKE = 5

MAKE_LIST = ["TOYOTA", "NISSAN", "SUZUKI", "MAZDA", "HONDA", "SUBARU", "VOLKSWAGEN", "LEXUS",
             "MITSUBISHI", "ISUZU", "DAIHATSU", "MERCEDES BENZ", "AUDI", "BMW"]

MAKE_DICT = {1: {"TOYOTA", "NISSAN", "SUZUKI", "MAZDA"}, 2: {"HONDA", "SUBARU", "VOLKSWAGEN", "LEXUS"}, 3: {"MITSUBISHI", "ISUZU", "DAIHATSU"},
             4: {"MERCEDES BENZ", "AUDI", "BMW"}}

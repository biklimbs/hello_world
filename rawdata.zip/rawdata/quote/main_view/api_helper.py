
# Description: api_helper deals with API call to get quote price and to get live exchange rate .
# Author:  Pavan Kumar.C
# Created On: 21/11/2018
# Modified For:
# Modified On:
# Modified By:


import sys, os
sys.path.append(os.path.abspath(os.path.join('..')))
try:
	from constants import *
except Exception as e:
		print("Failed to import constants.py. to "+str(os.path.dirname(os.path.realpath(sys.argv[0])))+"/"+os.path.splitext(os.path.basename(__file__))[0]+".py.")

import http.client
from logger_config import *
import logger_config
import json

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


#		To get exchange rate by doing rest_api call       
def get_exchange_rate(mode):
	try:
		mode=str(mode)
		conn = http.client.HTTPConnection(EXCHANGE_RATE_BASE_URL)
		headers = {'cache-control': "no-cache",'postman-token': EXCHANGE_RATE_TOKEN}
		conn.request(EXCHANGE_METHOD, EXCHANGE_RATE_EXTENSION_URL+mode, headers=headers)
		res = conn.getresponse()
		data = res.read().decode("utf-8")
		rate_to_filter=""
		exchange_rate=float(json.loads(data)['quotes']["USDJPY"])
		# if(mode=="USD"):
		# 	rate_to_filter=exchange_rate
		# else:
		# 	rate_to_filter=1/exchange_rate
		return float(exchange_rate)
	except Exception as e:
		return " "
		log.error(str(e))


#		REST API call to get bid prices based on selection        
def call_bid_lambda(country,port,vessel,company,model,s_year,e_year,mileage,kuzov,grade,engine_cc,rate,color):
	try:
		conn = http.client.HTTPSConnection(QUOTE_LAMBDA_URL)
		payload = "{\"company\": \""+company+"\",\"model\": \""+model+"\",\"s_year\": \""+s_year+"\",\"e_year\": \""+e_year+"\",\"mileage\": \""+mileage+"\",\"color\": "+str(color)+" ,\"kuzov\": \""+kuzov+"\",\"rate\": "+str(rate)+",\"countryCode\":\""+country+"\",\"portCode\":\""+port+"\",\"vessleCode\":\""+vessel+"\",\"grade\":"+str(grade)+",\"eng_v\":"+str(engine_cc)+"}"
		log.info(str(payload))
		headers = {'content-type': "application/json",'cache-control': "no-cache",'postman-token': QUOTE_LAMBDA_POSTMAN_TOKEN}
		conn.request(QUOTE_LAMBDA_METHOD , QUOTE_LAMBDA_EXTENSION_URL, payload, headers)
		res = conn.getresponse()
		data = res.read()
		return payload,json.loads(data.decode("utf-8"))
		# print(data.decode("utf-8"))
	except Exception as e:
		log.error(str(e))
		return {}


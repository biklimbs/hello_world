from bid.main_view.helper import *


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#-----------To set a formate for HTML formate used in detailed view  ----------      
def table_formated(rows):
	try:
		rows=sorted(rows, key = lambda i: int(i['FINISH']),reverse=True)
		res=""
		for row in rows:
			res=res+Markup("<tr bgcolor='#99ddff' ><td>"+str(row['AUCTION'])+"</td><td>"+str(row['MARKA_NAME'])+"</td><td>"+str(row['MODEL_NAME'])+"</td><td>"+str(row['KUZOV'])+"</td><td>"+str(row['YEAR'])+"</td><td>"+str(row['MILEAGE'])+"</td><td>"+str(row['COLOR'])+"</td><td>"+str(row['RATE'])+"</td><td>"+str(row['EQUIP'])+"</td><td>"+str(row['KPP'])+"</td><td>"+str(row['ENG_V'])+"</td><td>"+str(row['PRIV'])+"</td><td>"+str(row['AVG_PRICE'])+"</td><td>"+str(row['FINISH'])+"</td></tr>")
		return res
	except Exception as e:
		log.error(str(e))

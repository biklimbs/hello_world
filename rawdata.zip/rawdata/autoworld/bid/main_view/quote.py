import sys
from .sql_helper import * 
from .html_helper import * 
from .api_helper import * 
from .helper import * 
from .calculations import * 
from .get_chassis_id import get_chassis

from bid.history_view.history_html import *
from bid.history_view.history_helper import *
from bid.detailed_view.deailed_query import *


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#------------------------- To get Custom Quote ---------------------
def custom_quote(search_dic):
	try:	
		resultant_dic={}
		payload=get_payload(search_dic)

		country, port, vessel, company, model, s_year, e_year, mileage, kuzov, rate, color, country_name,port_name,vessel_name = validate_parameter_standard(search_dic)

		c_params=str(search_dic['c_params']).split(',')
		#-----------To assign current chages   ----------    
		avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country_name,port_name,vessel_name,data_count=assign_chages_custom(c_params)

		inspection_fee=get_inspection_fee_for_country(int(inspection_fee),country_name)

		#-----------To fob,cnf,cif chages for country   ----------    
		fob,cf,cif=get_fob_cf_cif_custom(avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country_name)

		rate=str(array_parram(search_dic,'rate')) if('rate' in str(search_dic)) else "-"
		color=str(array_parram(search_dic,'color')) if('color' in str(search_dic)) else "-"
		mil_resp=mileage_converter(str(search_dic['mileage']),"-")
		mileage="-" if(mil_resp=="0-0") else mil_resp

		#-----------HTML for quote data   ----------    
		quote_html=form_quote_html(country_name,port_name,vessel_name,company,model,s_year,e_year,kuzov,mileage,rate,color)
		
		#-----------HTML for data points   ----------    
		data_points_html=form_data_points(data_count)

		#-----------HTML for fee and charges   ----------    
		fee_and_charges_html=form_fee_and_charges_custom(avg_price,slab_rate,inspection_fee,lc_charges,freight_charge,misc_charge,country_name)

		#-----------HTML for FOB C&F CIF   ----------    	
		result_html=form_result_html(fob,cf,cif,country_name)

		#-----------   Display_html   ----------    
		display_html=get_display_quote(quote_html+data_points_html+fee_and_charges_html,result_html)

		#-----------   Save record to .csv file    ----------    
		save_to_history_csv(payload,str(result_html),fee_and_charges_html)


		resultant_dic['display_html']=display_html
		resultant_dic['history']=set_history()

		return resultant_dic
	except Exception as e:
		log.error(str(e))


#-----------To get bid_price and other details by calling rest_api used in checkbox of customize   ----------      		
def display_custom_options(search_dic):
	try:
		res_dic={}
		c_params=str(search_dic['c_params']).split(",")
		country_name=validate_parameter(c_params[6],"country")
		
		avg_price=str(c_params[0])
		inspection_fee=str(c_params[2])
		freight_charge=str(c_params[5])
		
		res_dic['avg_price']=(avg_price)
		res_dic['slab_rate']=int(get_slab_rate(int(avg_price),country_name))
		res_dic['inspection_fee']=get_inspection_fee_for_country(int(inspection_fee),country_name)
		res_dic['lc_charge']=0
		res_dic['misl_fee']=0
		res_dic['freight_charge']=int(freight_charge)
		
		return res_dic
	except Exception as e:
		log.error(e)


#------------------------- To get Standard Quote ---------------------
def standard_quote(search_dic):
	try:
		start_time=t.time()

		valid_start_time=t.time()

		country, port, vessel, company, model, s_year, e_year, mileage, kuzov, rate, color, country_name,port_name,vessel_name = validate_parameter_standard(search_dic)
		
		log.info("Time taken to Validate Prams call :"+str(round(t.time()-valid_start_time,2)))	
		
		db_start_time=t.time()
		
		payload,result=call_quote_api(country,port,vessel,company,model,s_year,e_year,mileage, kuzov,rate,color)
		
		log.info("Time taken to API call :"+str(round(t.time()-db_start_time,2)))	

		log.debug("Quote API input"+str(payload))
		log.debug("Quote API response"+str(result))
		
		if(result['Success']):
			
			asign_varibles_start_time=t.time()
			
			#-----------Assign_varibles   ----------    
			avg_price,auction_fee,trasport_charge,forward_fee,inspection_fee,lc_charges,misc_charge,freight_charge,margin=asign_varibles_standard(result,country_name)
			
			log.info("Time taken to asign_varibles block :"+str(round(t.time()-asign_varibles_start_time,2)))	
			
			#-----------Get FOB C&F CIF   ----------    
			fob,cf,cif = get_fob_cf_cif_standard(avg_price,auction_fee,inspection_fee,forward_fee,trasport_charge,lc_charges,freight_charge,margin,misc_charge)					
			
			
		elif(result['success']==False):
			company=""
			length=""
			query=""
			quote_tag=" Search with above criteria not found "
			selection=" "
		
		renter_start_time=t.time()

		Company='-' if company =='' else company
		Model='-' if(model=='') else model
		Mileage='-' if(mileage=='') else mileage
		Kuzov='-' if(kuzov=='') else kuzov
		Rate='-' if(rate==[]) else str(str(rate).partition('[')[-1].rpartition(']')[0])
		Color='-' if(color==[]) else str(str(color).partition('[')[-1].rpartition(']')[0])

		detailed_start_time=t.time()

		#-----------HTML for Detailed view   ----------    
		detailed_view_formatter,length=get_Detailed_view(search_dic)
		
		log.info("Time taken to DB call :"+str(round(t.time()-detailed_start_time,2)))	

		#-----------HTML for quote data   ----------    
		quote_html=form_quote_html(country_name,port_name,vessel_name,Company,Model,s_year,e_year,Kuzov,Mileage,Rate,Color)

		#-----------HTML for data points   ----------    
		data_points_html=form_data_points(length)

		#-----------HTML for fee and charges   ----------    
		fee_and_charges_html=form_fee_and_charges_standard(result,country_name)
		
		#-----------HTML for FOB C&F CIF   ----------    
		result_html=form_result_html(fob,cf,cif,country_name)

		#-----------   Display_html   ----------    
		display_html=get_display_quote(quote_html+data_points_html+fee_and_charges_html,result_html)
		

		#-----------   Save record to .csv file    ----------    
		save_to_history_csv(str(get_payload(search_dic)),str(result_html)," ")
			
		log.info("Time taken to renter and validate HTML page function :"+str(round(t.time()-renter_start_time,2)))		

		log.info("Time taken to search_results function :"+str(round(t.time()-start_time,2)))		
		
		return get_formated_dic_standard(country_name,avg_price,inspection_fee,freight_charge,length,display_html,detailed_view_formatter)
	except Exception as e:
		log.error(e)

#------------------------- Validating parameters for Standard Quote ---------------------
def validate_parameter_standard(search_dic):
	try:
		c_params=str(search_dic['c_params']).split(",")
		company=validate_parameter(search_dic['company'],'company')
		model=validate_parameter(search_dic['model'],'model')
		start_year=validate_parameter(search_dic['s_year'],'year')
		end_year=validate_parameter(search_dic['e_year'],'year')
		mil_resp=mileage_converter(search_dic['mileage'],"-")
		mileage="" if(mil_resp=="0-0") else mil_resp
		chassis=validate_parameter(search_dic['kuzov'],'kuzov')
		rate=convert_to_array(array_parram(search_dic,'rate'))
		color=convert_to_array(array_parram(search_dic,'color'))
		country=validate_parameter(search_dic['country'],"country")
		port=validate_parameter(search_dic['port'],"port")
		vessel=validate_parameter(search_dic['vessel'],"vessel")
		country_name=c_params[6]
		port_name=c_params[7]
		vessel_name=c_params[8]
		return country, port, vessel, company, model, start_year, end_year, mileage, chassis, rate, color, country_name,port_name,vessel_name
	except Exception as e:
		log.error(str(e))
		traceback.print_exc()

	
#------------------------- Assigning variables for Standard Quote ---------------------
def asign_varibles_standard(result,country_name):
	try:
		avg_price=int(result['Records']['bidPrice'])
		auction_fee=int(result['Records']['auctionFee'])
		trasport_charge=int(result['Records']['transportFee'])
		forward_fee=int(result['Records']['forwordingVanning'])
		inspection_fee=int(result['Records']['inspectionfee'])
		lc_charges=int(result['Records']['LCCharge'])
		misc_charge=get_standard_misl_charge() # Fixed
		freight_charge=int(result['Records']['oceanFreight'])
		margin=get_margin_search_results(avg_price) # % of margin from avg_price
		return avg_price,auction_fee,trasport_charge,forward_fee,inspection_fee,lc_charges,misc_charge,freight_charge,margin
	except Exception as e:
		log.error(str(e))
	
#------------------------- Formatting dictionary for Standard Quote ---------------------
def get_formated_dic_standard(country_name,avg_price,inspection_fee,freight_charge,length,display_html,detailed_view_formatter):
	try:
		html_dic={}
		html_dic['display_html']=display_html
		html_dic['history']=set_history()
		html_dic['detailed']=detailed_view_formatter

		html_dic['avg_price']=avg_price
		html_dic['slab_rate']=str(int(get_slab_rate(int(avg_price),country_name)))
		html_dic['inspection_fee']=inspection_fee
		html_dic['lc_charge']=0
		html_dic['misl_fee']=0
		html_dic['freight_charge']=freight_charge
		html_dic['data_count']=length
		return html_dic
	except Exception as e:
		log.error(str(e))
	
#-----------To assign current chages (used in custom mode)  ----------    
def assign_chages_custom(c_params):
	try:
		avg_price=str(c_params[0])
		slab_rate=str(c_params[1])
		inspection_fee=str(c_params[2])
		lc_charges=str(c_params[3])
		misc_charge=str(c_params[4])
		freight_charge=str(c_params[5])
		country_name=str(c_params[6])
		port_name=str(c_params[7])
		vessel_name=str(c_params[8])
		data_count=str(c_params[9])
		return avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country_name,port_name,vessel_name,data_count
	except Exception as e:
		log.error(str(e))

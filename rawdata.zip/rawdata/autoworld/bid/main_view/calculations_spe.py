from .constants import *

#-----------To get slab rate based on avg_price and for exceptions countries  ----------
def get_slab_rate(avg_price, country):
	slab_rate = 0
	from_range = 0
	to_range = PRICE_DIFF+1
	if(country == "New Zealand"):
		slab_rate = get_slab_rate_new_zealand()
	elif(country == "Cyprus"):
		slab_rate = get_slab_rate_cyprus()
	elif(country == "Malta"):
		slab_rate = get_slab_rate_malta()
	else:
		i = 0
		while(i < 100):
			if(from_range < avg_price < to_range):
				slab_rate = (i*20000)+100000
				break
			i += 1
			from_range = to_range
			to_range = from_range+PRICE_DIFF

	return slab_rate

#-----------To get slab rate for new_zealand----------
def get_slab_rate_new_zealand():
	return NEW_ZEALAND_SLAB_RATE

#-----------To get slab rate for malta----------
def get_slab_rate_malta():
	return MALTA_SLAB_RATE

#-----------To get slab rate for cyprus----------
def get_slab_rate_cyprus():
	return CYPRUS_SLAB_RATE
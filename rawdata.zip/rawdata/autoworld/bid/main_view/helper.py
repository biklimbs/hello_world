from .constants import *
from datetime import datetime, time
import csv
from flask import Flask, render_template, request,Response,redirect,url_for,Markup,jsonify
import http.client
import json
from .logger_config import *
from .calculations import *
import bid.main_view.logger_config as logger_config
import os, inspect
import traceback
import pymysql.cursors
import time as t
import pandas as pd
from django.http import HttpResponse,JsonResponse

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")


#-----------To make a list of parameters which are having more than one value in dic helps for color and rate(multiple select)  ----------      
def array_parram(dic,param):
	choices=""
	try:
		for key in dic.keys():
			for value in dic.getlist(key):
				if(key==param):
					choices=choices+",'"+value+"'" if(str(value).strip()!='' and str(value).strip()!=str(param).upper()) else choices
		return str(choices[1:])
	except Exception as e:
		log.error(str(e))

#-----------To convert string to array by spliting string with " , "  ----------      	
def convert_to_array(string):
	try:
		res=[]
		if len(string)>0:
			for each in string.split(","):
				res.append(str(each)[1:-1])
		else:
			pass
		return res
	except Exception as e:
		log.error(str(e))

#-----------To validate parameters they are same or not helps in passing paylod  ----------      
def validate_parameter(param,term):
	try:
		if(param!='' and param!=term.upper()):
			return param
		else:
			if(param=='S_YEAR' or param=='E_YEAR'):
				return '0'
			else:
				return ""
	except Exception as e:
		log.error(str(e))

#-----------To change mileage format from 'k' to '000'(numerical)  ----------      
def mileage_converter(mil_str,div):
	try:
		res=""
		mil_str=mil_str.split("-")
		res=res+str(str(mil_str[0]).split('k')[0])+"000" if(int(str(mil_str[0]).split('k')[0])>0) else  res+"0"
		res=res+div+str(str(mil_str[1]).split('k')[0])+"000" if(int(str(mil_str[1]).split('k')[0])>0) else  res+div+"0"
		return res
	except Exception as e:
		log.error(str(e))
	
#-----------To change a formate of dic parameters in to payload formate readable for api call   ----------    
def get_payload(search_dic):
	try:
		c_params=str(search_dic['c_params']).split(',')
		country=str(c_params[6])
		port=str(c_params[7])
		vessel=str(c_params[8])
		company=validate_parameter(search_dic['company'],'company')
		model=validate_parameter(search_dic['model'],'model')
		s_year=validate_parameter(search_dic['s_year'],'year')
		e_year=validate_parameter(search_dic['e_year'],'year')
		mil_resp=mileage_converter(search_dic['mileage'],"-")
		mileage="" if(mil_resp=="0-0") else mil_resp
		kuzov=validate_parameter(search_dic['kuzov'],'kuzov')
		rate=convert_to_array(array_parram(search_dic,'rate'))
		color=convert_to_array(array_parram(search_dic,'color'))
		payload = "{\r\n\"company\": \""+company+"\",\r\n\"model\": \""+model+"\",\r\n\"s_year\": \""+s_year+"\",\r\n\"e_year\": \""+e_year+"\",\r\n\"mileage\": \""+mileage+"\",\r\n\"color\": "+str(color).replace("'","\"")+" ,\r\n\"kuzov\": \""+kuzov+"\",\r\n\"rate\": "+str(rate).replace("'","\"")+",\r\n\"countryCode\":\""+country+"\",\r\n\"portCode\":\""+port+"\",\r\n\"vessleCode\":\""+vessel+"\"\r\n}"
		return payload
	except Exception as e:
		log.error(str(e))
		# traceback.print_stack()
		return str(e)

#-----------To get fob,cf,cif for standard quote  ----------      		
def get_fob_cf_cif_standard(avg_price,auction_fee,inspection_fee,forward_fee,trasport_charge,lc_charges,freight_charge,margin,misc_charge):
	try:
		if(avg_price > 0):
			fob=get_fob_standard(avg_price, auction_fee, trasport_charge,forward_fee, inspection_fee, lc_charges, misc_charge, margin)
			cf=get_cnf_standard(fob, freight_charge)
			cif=get_cif_standard(fob, freight_charge)
		else:
			fob=0
			cf=0
			cif=0
		return fob,cf,cif
	except Exception as e:
		log.error(str(e))	

#-----------To get fob,cf,cif for custom quote  ----------      		
def get_fob_cf_cif_custom(avg_price,slab_rate,inspection_fee,lc_charges,misc_charge,freight_charge,country):
	try:
		fob=""
		cf=""
		cif=""
		if(int(avg_price) > 0):
			fob=get_fob_custom(avg_price,slab_rate,lc_charges,inspection_fee,misc_charge)
			cf=get_cnf_custom(fob, freight_charge)
			cif=get_cif_custom(fob, freight_charge)
		else:
			fob=0
			cf=0
			cif=0
		return fob,cf,cif
	except Exception as e:
		log.error(str(e))

#-----------To get inspection fee for country  ----------      
def get_inspection_fee_for_country(inspection,country):
	try:
		if(country=="New Zealand"):
			return 0
		elif(country=="Malta"):
			return 0
		elif(country=="Cyprus"):
			return 0
		else:
			return inspection
	except Exception as e:
		log.error(str(e))


#-----------To Create a folder if not present in path  ----------   
def check_folder_and_create(folder_path):
	if not os.path.isdir(folder_path):
		os.system('mkdir '+folder_path+'')


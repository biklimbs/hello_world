from bid.main_view.helper import *    


#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#-----------To get data from history .csv and formatted in HTML formate   ----------    
def set_history():
	try:
		res=''
		check_folder_and_create(CSV_FOLDER)
		if os.path.isfile(CSV_FOLDER+HISTORY_CSV_FILE):
			with open(CSV_FOLDER+HISTORY_CSV_FILE) as csv_file:
				for x in csv.reader(csv_file, delimiter=','):
					row=json.loads(x[1])
					res="<tr bgcolor='#99ddff' ><td width='6%'>"+str(x[0])+"</td><td width='6%'>"+str(row['countryCode'])+"</td><td width='6%'>"+str(row['portCode'])+"</td><td width='6%'>"+str(row['vessleCode'])+"</td><td width='6%'>"+str(row['company'])+"</td><td width='6%'>"+str(row['model'])+"</td><td width='6%'>"+str(row['s_year'])+"-"+str(row['e_year'])+"<td width='6%'>"+str(row['kuzov'])+"</td><td width='6%'>"+str(row['mileage'])+"</td><td width='6%'>"+str(str(row['rate'])[1:-1])+"</td><td width='6%'>"+str(str(row['color'])[1:-1])+"</td><td width='6%'>"+str(x[3])+"</td><td width='6%'>"+str(x[2])+"</td></tr>"+res
			return Markup(res)
		else:
			return " "
	except Exception as e:
		log.error(str(e))
from django.apps import AppConfig


class BidConfig(AppConfig):
    name = 'bid'

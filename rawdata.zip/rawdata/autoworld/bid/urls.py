from django.urls import path
from django.conf.urls import  url

from . import views


urlpatterns = [
    path('', views.index, name='index'),
    
    url(r'^PORT$', views.port, name='getport'),
    url(r'^MARK$', views.mark, name='getmark'),
    url(r'^VESSEL$', views.vessel, name='getvessel'),
    url(r'^MODEL$', views.model, name='getmodel'),
    url(r'^YEAR$', views.year, name='getyear'),
    url(r'^KUZOV$', views.chasisid, name='getchasis'),
    url(r'^RATE$', views.rate, name='getrate'),
    url(r'^COLOR$', views.color, name='getcolor'),
    url(r'^STANDARD_QUOTE$', views.standard_quote_, name='getstandardquote'),
    url(r'^CUSTOMIZE$', views.customize, name='customize'),
    url(r'^CUSTOM_QUOTE$', views.custom_quote_, name='getcustomquote'),
]



import requests
import sys
import pymysql.cursors
import time as t
from time import sleep
import datetime
from datetime import datetime, time
from flask import Flask, render_template, request,Response,redirect,url_for,Markup,jsonify
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
from operator import itemgetter
import pandas as pd
import json
import csv
import os

# http://34.236.166.193:1342/SBarException/?limit=10000&skip=0&where={%22ReportedDate%22:%222018-08-01%22,%22Type%22:%22L1%20Queue%22}&sort=Id%20ASC
# http://34.236.166.193:1342/SBarException/?limit=10000&skip=0&where={"ReportedDate":"2018-08-01","Type":"L1%20Queue"}&sort=Id%20ASC
BASIC_URL="http://34.236.166.193:1342/SBarException/?limit=10000&skip=0&where={\"ReportedDate\":\""
AFTER_DATE="\",\"Type\":\""
QUEUE="%20Queue\"}&sort=Id%20ASC"


#----------- Rest API where returns response in json fromat ----------
def api_call(date,queue):
    response  = ""
    while (response == ""):
        try:
        	# print(BASIC_URL+str(date)+AFTER_DATE+str(queue)+QUEUE)
        	response = requests.get(BASIC_URL+str(date)+AFTER_DATE+str(queue)+QUEUE,timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return format_results(response.json(),date,queue)


def write_csv(file_name, list_of_rows, header):   
    
    with open(file_name, 'w') as f:
        csv_writer=csv.DictWriter(f, header)
        csv_writer.writeheader()      
        for row in list_of_rows:      
            row_unicode={}      
            for k, v in zip(header, row):
                v=str(v)       
                row_unicode[k]=v      
            csv_writer.writerow(row_unicode)   


def format_results(response,date,queue):
	try:
		json=response['ViewModels']
		if(len(json)>0):
			res_array=[]
			for x in json:
				ind_array=[]
				ind_array.append(str(x['Location']))
				ind_array.append(str(x['Poured']))
				ind_array.append(str(x['Sold']))
				ind_array.append(str(x['Variance']))
				res_array.append(ind_array)

			print(str(os.path.abspath('.')))
		#	directory=os.path.join('/home/pavan/Documents/csv/'+date+"_"+queue+'.csv')
			# os.chmod(directory, 0)
#			os.path.abspath('.')
			headers=[' Location ',' Poured ',' Sold ',' Variance ']
			write_csv(date+"_"+queue+'.csv',res_array,headers)
		else:
			print(e)
			return []
	except Exception as e:
		print(str(e))




app = Flask(__name__)


# #-----------Flask Starts Here ----------         

@app.route("/")
def index():
	try:		
		return render_template("index.html")		
	except Exception as e:
		return 'something went wrong'+str(e)


@app.route('/DOWNLOAD', methods=["GET", "POST"])
def DOWNLOAD():
	try:
		print(str(request.form))
		api_call(str(request.form['date']),str(request.form['download']))
		return ""
	except Exception as e:
		print(e)
		return str(e)	

if __name__ == "__main__":
	app.run(host='0.0.0.0' ,port=89)

# print(list(d['Database'] for d in get_tables(connection_hadoop_internal)))


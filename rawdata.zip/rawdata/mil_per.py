
import requests
import sys
import pymysql.cursors
import time as t
from time import sleep
import datetime
from datetime import datetime, time
from flask import Flask, render_template, request,Response,redirect,url_for,Markup,jsonify
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
from operator import itemgetter
import pandas as pd



MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME = 'japan_car_algo_daily'


script="<div id="
script1=" style='min-width: 100px; height: 300px; margin: 0 auto'></div><script type='text/javascript'>"
Highchart_="Highcharts.chart(\""
container_="\",{chart: {zoomType:'x',type: 'spline'},title:{style:{fontSize:'12px'},text:'"
title_="'},subtitle:{text:''},xAxis: {categories:"
categories_=" },yAxis: {title: {text: 'Percentage'},labels: {formatter: function () {return this.value ;}}},tooltip: {crosshairs: true,shared: true},plotOptions: {spline: {marker: {radius: 4,lineColor: '#666666',lineWidth: 1}}},series: [{name: '"
parameter="',data:"
Sold_="}]});</script>"


app = Flask(__name__)


def Markup_formater(mil_array,per_array,category,param,date_):
#     print(product_name)
    # product=str(" \" "+product_name+"( "+str(date_array[st])+" to "+str(date_array[en-1])+" )"+"("+str(st)+" -- "+str(en)+")"+" \" ")
    return Markup(script)+Markup(category)+Markup(script1)+Markup(Highchart_)+Markup(category)+Markup(container_)+Markup(date_)+Markup(title_)+Markup(mil_array)+Markup(categories_)+Markup(param)+Markup(parameter)+Markup(per_array)+Markup(Sold_)


#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)
	return connection_hadoop_check



def convert_markup_tables(json_):
	res_tags="<option value='search_loc' selected='selected' >Company</option>"
	tables=[]
	for table in json_:
		res_tags=res_tags+"<option value='"+str(table['TABLE_NAME'])+"' >"+str(table['TABLE_NAME'])+"</option>"
		# print(table['TABLE_NAME'])
	return Markup(res_tags)



def get_tables(connection_hadoop_internal):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql="SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE  TABLE_SCHEMA='"+MY_SQL_DB_NAME+"' and TABLE_NAME like '%2018'"
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall()
			return response_code
	except Exception as e :
		print(e)
		return "[]"



def get_filter_params_mark(connection_hadoop_internal,table,company):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			res_=[]
			if(company== ' '):
				sql="select distinct MARKA_NAME  as x FROM "+table+" ;"
			else:
				sql="select distinct MODEL_NAME  as x FROM "+table+" where MARKA_NAME='"+company+"' ;"
			# print(sql)
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall() 
			# print(response_code)
			params=sorted(list(pd.DataFrame(response_code)['x']))
			for param in params:
				res_.append(param)
			# print(res_)
			return res_
	except Exception as e :
		print(e)
		return "[]"


def search_results_mil_per(connection_hadoop_internal,search_dic):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			table=str(search_dic['table'])
			company=str(search_dic['mark'])
			model=str(search_dic['model'])
			# sql="select MILEAGE,PERCENTAGE FROM "+table+" order by MILEAGE ASC ;"
			sql="select YEAR,KPP,RATE,KUZOV,MILEAGE,PERCENTAGE FROM "+table+" where MARKA_NAME='"+company+"' and MODEL_NAME ='"+model+"' and KPP != ' ' and RATE != ' ' AND YEAR != 0 and KUZOV != ' ' order by MILEAGE ASC ;"
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall() 
			# print(response_code)
			return response_code
	except Exception as e:
		return []	


def resultarray(json_,date_):
	res_markup=''
	params_array=['YEAR','KPP','RATE','KUZOV','MILEAGE']
	sorted_=sorted(json_, key=itemgetter('MILEAGE')) 
	for param in params_array:
		per_array=[]
		param_array=[]
		for row in sorted_:
			param_array.append(str(row[param]))
			if(str(row['PERCENTAGE'])=='None'):
				per_array.append(0.0)
			else:
				per_array.append(float(row['PERCENTAGE']))
		res_markup =res_markup+Markup_formater(param_array,per_array,'category'+param,param,date_)

	return res_markup



# #-----------Establishing Connection to MySQL Server ----------         
connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)


@app.route("/")
def index():
	try:
		return render_template("mil_per.html",tables=convert_markup_tables(get_tables(connection_hadoop_internal)))		
	except Exception as e:
		print("--------------------------")
		print(e)
		return 'something went wrong'



@app.route("/Execute", methods = ['POST'])
def Execute():
	try:
		res_=''
		search_dic=request.form
		# if(str(search_dic['table'])!='TABLE' and str(search_dic['mark'])!='MARKA' and str(search_dic['model'])!='MODEL'):
		if(str(search_dic['table'])!='TABLE'):
			connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
			table_split=str(search_dic['table']).split('_')
			date_=str(table_split[2])+" "+str(table_split[3])+" "+str(table_split[4])
			return render_template("Fil.html",bot1=resultarray(search_results_mil_per(connection_hadoop_internal,search_dic),date_),title=date_)
			# return render_template("graph.html",res_=resultarray(search_results_mil_per(connection_hadoop_internal,search_dic)),title=date_+" "+str(search_dic['mark'])+" "+str(search_dic['model']))
		else:
			return str("Choose Fields")
	except Exception as e:
		return  str(e)


@app.route('/MARKA_NAME', methods=["GET", "POST"])
def MARKA_NAME():
	try:
		connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		return jsonify(get_filter_params_mark(connection_hadoop_internal,str(request.form['table']),' '))	
	except Exception as e:
		return str(e)



@app.route('/MODEL_NAME', methods=["GET", "POST"])
def MODEL_NAME():
	try:
		connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		return jsonify(get_filter_params_mark(connection_hadoop_internal,str(request.form['table']),str(request.form['mark'])))	
	except Exception as e:
		return str(e)


if __name__ == "__main__":
	app.run(host='0.0.0.0' ,port=86)




import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import json
import csv
import pandas as pd
from time import sleep
import datetime
import traceback
from datetime import datetime, time
from flask import Flask, render_template, request,Response,redirect,url_for,Markup
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
import random


MY_SQL_HOST_NAME = 'spark.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Vmmobility@1234'
MY_SQL_DB_NAME = 'japan_car_algo_daily'

COUNT_=100000


TABLE='future_predicted_24_jul_2018'
BASE_URL="http://75.125.226.218/xml/json?&ip='10.10.0.0'&code=y19Hfrte_Dm&sql="


#----------- Rest API where returns response in json fromat ----------
def get_count(s_date,e_date):
    response  = ""
    while (response == ""):
        try:
        	response = requests.get(BASE_URL+"select+count%28*%29+from+main+where+TIME+between++%27"+s_date+"%25%27+and+%27"+e_date+"+23%3A%25%27+and+AUCTION+not+like+%27USS%25%27",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            log.info("API CALL TIME OUT",e)
    return response.json()

#----------- Rest API where returns response in json fromat ----------
def api_call(s_date,e_date,st_limt,end_limt):
    response  = ""
    while (response == ""):
        try:
        	log.info("running for range : "+" "+str(st_limt)+" "+str(end_limt))
        	response = requests.get(BASE_URL+"select+*+from+main+where+TIME+between++%27"+s_date+"%3A%25%27+and+%27"+e_date+"+23%3A%25%27+and+AUCTION+not+like+%27USS%25%27+LIMIT+"+str(st_limt)+"%2C+"+str(end_limt),timeout = 6000) 
        	print(BASE_URL+"select+*+from+main+where+TIME+between++%27"+s_date+"%3A%25%27+and+%27"+e_date+"+23%3A%25%27+and+AUCTION+not+like+%27USS%25%27+LIMIT+"+str(st_limt)+"%2C+"+str(end_limt))
        except Exception as e:
            log.info("API CALL TIME OUT",e)
    return response.json()


#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()
			return db_check_result

	except:
		#traceback.log.info_stack()
		return None
 

#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)

	return connection_hadoop_check

#----------- Rest API where returns response in json fromat ----------
def get_all_images(ID):
    response  = ""
    while (response == ""):
        try:
        	response = requests.get(BASE_URL+"select+IMAGES+from+main+where+id%3D%27"+ID+"%27+",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()


def update_image(db_connection_obj,ID):
	try:
		image=str(get_all_images(ID)[0]['IMAGES'])
		with db_connection_obj.cursor() as hadoop_cursor:
			security_set="SET SQL_SAFE_UPDATES=0;"
			update_Image="update "+TABLE+" set IMAGES= \""+image+"\" where ID= \""+ID+"\";"
#			print(update_Image)
			hadoop_cursor.execute(security_set)
			hadoop_cursor.execute(update_Image)
			db_connection_obj.commit()
	except Exception as e:
		log.info(str(e))

def check_ID(db_connection_obj,id):
	with db_connection_obj.cursor() as hadoop_cursor:
		sql="SELECT * FROM "+TABLE+" where ID = \""+ id+"\" ;"
		hadoop_cursor.execute(sql)
		res_=hadoop_cursor.fetchone()
		if(str(res_)=='None'):
			return True
		else:
			return False



#----------- Inserting data to car_future_all table for each car done here  ----------
def insert_to_table(db_connection_obj,ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,EQUIP,RATE,START,FINISH,STATUS,TIME,AVG_PRICE,AVG_STRING,IMAGES):
	try:
		sql_=""
		with db_connection_obj.cursor() as hadoop_cursor:
			today_=str(str(datetime.today())[:16])
			if(check_ID(db_connection_obj,ID)):
#				print(ID)
				sql = "insert into "+TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,EQUIP,RATE,START,FINISH,STATUS,TIME,AVG_PRICE,AVG_STRING,IMAGES,LOCAL_TIME) VALUES(\""+ID+"\","+LOT+",\""+AUCTION_DATE+"\",\""+AUCTION+"\","+MARKA_ID+","+MODEL_ID+",\""+MARKA_NAME+"\",\""+MODEL_NAME+"\","+YEAR+",\""+ENG_V+"\",\""+str(PW)+"\",\""+KUZOV+"\",\""+GRADE+"\",\""+COLOR+"\",\""+KPP+"\","+KPP_TYPE+",\""+PRIV+"\","+MILEAGE+",\""+EQUIP+"\",\""+RATE+"\","+START+",\""+FINISH+"\",\""+STATUS+"\",\""+TIME+"\","+AVG_PRICE+",\""+AVG_STRING+"\",\""+IMAGES+"\",\""+today_+"\")"
				hadoop_cursor.execute(sql)
				db_connection_obj.commit()
				update_image(db_connection_obj,ID)

	except Exception as e:
		log.info(e)
		log.info(sql_)
		# sys.exit()

#----------- Get cars based on MARKA and MODEL and Inserted to table done here ----------
def download_car_info(db_connection_obj,json_):
	try:
		start_time=t.time()
		for car_model in range(int(len(json_))):
			today_=str(str(datetime.today())[:16])
			car_model_details=json_[car_model]
			if('AVG_PRICE' in car_model_details and 'AVG_STRING' in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],car_model_details['COLOR'],car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],car_model_details['AVG_PRICE'],car_model_details['AVG_STRING'],car_model_details['IMAGES'])
			if('AVG_PRICE' not in car_model_details and 'AVG_STRING' not in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],car_model_details['COLOR'],car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],'0','NULL',car_model_details['IMAGES'])
			elif('AVG_STRING' not in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],car_model_details['COLOR'],car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],car_model_details['AVG_PRICE'],'NULL',car_model_details['IMAGES'])
			elif('AVG_PRICE' not in car_model_details):
				insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],car_model_details['COLOR'],car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],'0',car_model_details['AVG_STRING'],car_model_details['IMAGES'])


		end_time=t.time()-start_time
		log.info("time taken to download is "+str(end_time))
		# log.info(model)
		
	except Exception as e:
		# return False
		log.info(e)



connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)

def main():
	try:
		e_date=datetime.now().strftime("%Y-%m-%d")
		s_date=str(str(datetime.today() - timedelta(days=1))[:10])
		# model_count=get_count(s_date,e_date)
		model_count=COUNT_
		count=model_count
		log.info("Total distinct models : "+str(count)+" "+s_date+" "+e_date)
		count = count/250
		if(int(count)<count):
			loop_int=int(count)+1
		else:
			loop_int=int(count)
		st_limt=0
		end_limt=0
		for let in range(loop_int):
			log.info(str(let)+" / "+str(loop_int))
			st_limt=st_limt
			end_limt=st_limt+250
			# if let>202
			print(st_limt,end_limt)
			json_=api_call(s_date,e_date,st_limt,end_limt)
			while int(len(json_))!=250:
				# print("hai1")
				print(str(int(len(json_))))
				t.sleep(1800)
				json_=api_call(s_date,e_date,st_limt,end_limt)
			else:
				# print("hai")
				download_car_info(connection_hadoop_internal,json_)
					
			st_limt=end_limt
	except Exception as e:
		# print("Hai")
		log.info(e)



if __name__=="__main__":
	main()

import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pandas as pd



def get_time_range_linecleaning_1(base_data_df):
	prod_result_df=pd.DataFrame()
	prod_uniq=loc_df["product_id"].unique()
	for prod in prod_uniq:
		df_linecleaning=base_data_df[base_data_df["product_id"]==prod]
		df_linecleaning1= df_linecleaning.sort_values(by="date")
		df_linecleaning1=df_linecleaning1.reset_index(drop=True)
		k=0
		for item in range(0,len(df_linecleaning1)):
			
			start_time_lc=df_linecleaning1.loc[item,"time"]
			prod_result_df.loc[k,"date"]=df_linecleaning1.loc[item,"date"]
			prod_result_df.loc[k,"start_time"]=start_time_lc
			date_temp=pd.to_datetime(start_time_lc)
			end_time_lc = (date_temp + timedelta(minutes=VAR_MIN))
			date_temp1,date_temp2=str(end_time_lc).split(" ")
			prod_result_df.loc[k,"end_time"]=date_temp2
			prod_result_df.loc[k,"poured"]=df_linecleaning1.loc[item,"poured"]
			prod_result_df.loc[k,"loc_id"]=df_linecleaning1.loc[item,"loc_id"]
			prod_result_df.loc[k,"loc_name"]=df_linecleaning1.loc[item,"loc_name"]
			prod_result_df.loc[k,"prod_id"]=df_linecleaning1.loc[item,"prod_id"]
			prod_result_df.loc[k,"prod_name"]=df_linecleaning1.loc[item,"prod_name"]
			prod_result_df.loc[k,"confidence"]=df_linecleaning1.loc[item,"confidence"]
			k+=1
			
	return prod_result_df

def get_time_range_linecleaning_1(base_data_df):
	return main(base_data_df)
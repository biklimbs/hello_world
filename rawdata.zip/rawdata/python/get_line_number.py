from linecleaning_common import get_line_number_data
import pandas as pd
import datetime
from datetime import datetime, timedelta
import sys
import numpy as np
try:
	from logger_config import log
except:
	log.error("logger_config.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()

# def increment_date(date):
# 	date = datetime.strptime(date, "%Y-%m-%d")
# 	modified_date = date + timedelta(days=1)
# 	date = datetime.strftime(modified_date, "%Y-%m-%d")
# 	return date

def compare_for_line_number(base_data_df,df_line_number):
	print("In compare with line number")
	log.debug("In compare with line number")
	#log.info("Getting the line number for linecleaning instances")
	for index, rows in base_data_df.iterrows():
		for line_index, line_rows in df_line_number.iterrows():
			if str(base_data_df.loc[index,"date"])==str(df_line_number.loc[line_index,"date"]) and int(base_data_df.loc[index,"product_id"])==int(df_line_number.loc[line_index,"product_id"]):
				base_data_df.loc[index,"line_number"]=df_line_number.loc[line_index,"line_number"]
				base_data_df.loc[index,"line_count"]=df_line_number.loc[line_index,"line_count"]
				base_data_df.loc[index,"line_flag"]=df_line_number.loc[line_index,"line_flag"]
				#print (concat_df.loc[index,"line_number"])
				break
	return base_data_df

def main(base_data_df,data_df):
	# to_date= increment_date(to_date)
	# data_df = get_line_number_data(location_id, from_date, to_date)

	
	unique_date= data_df["date"].unique()
	line_number_df= pd.DataFrame()
	index=0
	for date in unique_date:
		data_df_based_on_date=data_df[data_df["date"]==date]
		uniq_prod= data_df_based_on_date["product_id"].unique()
		for prod_id in uniq_prod:

			data_df_based_on_prod= data_df_based_on_date[data_df_based_on_date["product_id"]==prod_id]
			#print(data_df_based_on_prod)
			uniq_line_number= data_df_based_on_prod["line_number"].unique()
			#print(uniq_line_number)
			uniq_line_number= list(uniq_line_number)
			if len(uniq_line_number) != 1 and 0 in uniq_line_number:
				 uniq_line_number.remove(0)

			if len(uniq_line_number)>1:
				line_number_df.loc[index,"line_flag"]= 1
			else:
				line_number_df.loc[index,"line_flag"]= 0
				#pass
			#print(uniq_line_number)
			unique_location_id= data_df_based_on_prod["location_id"].unique()
			unique_location_name= data_df_based_on_prod["location_name"].unique()
			unique_product_id= data_df_based_on_prod["product_id"].unique()
			unique_product_name= data_df_based_on_prod["product_name"].unique()
			line_number_df.loc[index,"date"]= date
			line_number_df.loc[index,"location_id"]= unique_location_id[0]
			line_number_df.loc[index,"location_name"]=unique_location_name[0]
			line_number_df.loc[index,"product_id"]= unique_product_id[0]
			line_number_df.loc[index,"product_name"]= unique_product_name[0]
			line_number_df.loc[index,"line_number"]= ",".join([str(i) for i in uniq_line_number])
			line_number_df.loc[index,"line_count"]= len(uniq_line_number)
			index+=1


	#print(line_number_df)
	base_data_df= compare_for_line_number(base_data_df,line_number_df)
	return base_data_df

if __name__ == "__main__":
	main(base_data_df,line_num_df)

def get_line_number(base_data_df,line_num_df):
	return main(base_data_df,line_num_df)
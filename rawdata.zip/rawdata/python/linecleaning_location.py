"""
Title: Location feature

Description: Computes linecleaning at the location level. 
Algorithm: 1.Standard deviation for the given duration is calculated for each datapoint and
		   2. Each datapoint is checked for sold data and poured data
 		   3. And also checked for the time time stamp.
 		   4. Algorithm will  
 		   			a)  award weight for each datapoint proportional to 
 		   					i) Standard deviation
 		   					ii) Sold data
 		   					iii) Time range (6.00 pm to 9.30 pm)
 		   					iv) Neighbourhood 
 		   			b) penalize for each data point proportional to 
 		   					i) Multiday issue
 		   	5 Compare with base dataframe and assign the weight according to the linecleaning at location level by comparing the date and time.
"""



import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from logger_config import log
from constants import display_modified_df
try:
	from constants import *
except:
	log.error("constants.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()

# # comparision between linecleaning location dataframe and the linecleaning dataframe
# # if in the same time both dataframes are having spike or datapoint then 
# # increase the weight of that particular datapoint in the line cleaning dataframe
# def compare_with_loc(base_data_df,df_location_feature):
# 	if(len(df_location_feature)>0):
# 		base_data_df=base_data_df.reset_index(drop=True)
# 		for row in range(0,len(base_data_df)):
# 			for line in range(0,len(df_location_feature)):
# 				if base_data_df.loc[row,"date"]==df_location_feature.loc[line,"date"] and base_data_df.loc[row,"time"]==df_location_feature.loc[line,"time"]:
# 					base_data_df.loc[row,'loc_f']=round(df_location_feature.loc[line,'loc_f'],2)
# 					base_data_df.loc[row,"loc_w"]=round(df_location_feature.loc[line,'loc_w'],2)
# 					break
# 		base_data_df["loc_f"].fillna(0, inplace=True)
# 		base_data_df["loc_w"].fillna(0, inplace=True)
# 	else:
# 		base_data_df["loc_f"] = 0.00
# 		base_data_df["loc_w"] = 0.00
# 	return base_data_df

START_HR_MRN=6
START_MIN_MRN=0
END_HR_MRN=18
END_MIN_MRN=0
START_HR_NT=21
START_MIN_NT=30
END_HR_NT=6
END_MIN_NT=0


W_SOLD_FULL=1
W_SOLD_HALF=0.5
W_SOLD_QUATER=0.25

W_TIME_START_OF_THE_DAY=1
W_TIME_MIDDLE_OF_THE_DAY=0.5
W_TIME_END_OF_THE_DAY=1

W_DEVIATION_FROM_SD_FIRST_QUATER=0.25
W_DEVIATION_FROM_SD_SECOND_QUATER=0.50
W_DEVIATION_FROM_SD_THIRD_QUATER=0.75
W_DEVIATION_FROM_SD_FOURTH_QUATER=1

W_NEIGHBOURHOOD= 2.95
W_LOC_MULTIDAY=2
LIMIT_CHECK=10

MAX=3
DISPLAY_CONFIDENCE_CUT_OFF=95


# find standard deviation for all the data-points
def find_std_dev_diff(df_location_local,mean,stdev):
	for i,j in enumerate(df_location_local["poured"]):
		df_location_local.loc[i,"stdev_diff"]=(j-(mean))
	return(df_location_local)

# checking the neighbourhood feature, for the datapoint in linecleaning dataframe with sold data zero
# if any near by datapoint is having maximum weight then that datapoint will be assignd maximum weight
# this is location wise
def check_neighbourhood(df_location_local,data_point):
	#latest_i=int(i)
	if df_location_local.loc[data_point,"sold"]==0 and df_location_local.loc[data_point,"weight"]!=MAX:
		
		prev_flag=True
		nxt_flag=True
		for j in range(data_point):
			prev=int(data_point-j)
			nxt=int(data_point+j)
			#print("...it is j",str(int(latest_i-j)))
			
			if prev_flag==True:
				#print("prev=",prev)
				if prev!=0 and df_location_local.loc[prev-1,"weight"]==MAX:
					#print("prev======",prev)
					df_location_local.loc[data_point,"weight"]=W_NEIGHBOURHOOD
					#print("date and time==",df_location_local.loc[data_point,"date"],df_location_local.loc[data_point,"time"])
					#print("weight changed in prev")
					prev_flag=False

				elif prev==0 or df_location_local.loc[prev-1,"sold"]!=0:
					#print("prev flag is False")
					prev_flag=False
					#break
			if nxt_flag==True:
				#print("nxt==",nxt)
				#print("length=",(len(df_location_local)-1))
				if nxt!=(len(df_location_local)-1) and df_location_local.loc[nxt+1,"weight"]==MAX:
					df_location_local.loc[data_point,"weight"]=W_NEIGHBOURHOOD
					#print("date and time==",df_location_local.loc[data_point,"date"],df_location_local.loc[data_point,"time"])
					#print("weight changed in next")
					nxt_flag=False
				elif nxt==(len(df_location_local)-1) or df_location_local.loc[nxt+1,"sold"]!=0:
					#print("next flag is False")
					nxt_flag=False

			if prev_flag==False and nxt_flag==False:
				#print("Both False")
				break

		return df_location_local
	else:
		return df_location_local


def check_loc_multiday(df_multiday_local2,data_point):
	#print(data_point)
	if df_multiday_local2.loc[data_point,"sold"]==0:
		
		prev_flag=True
		nxt_flag=True
		count_prev=0
		count_nxt=0
		for j in range(0,len(df_multiday_local2)):
			prev=int(data_point-j)
			nxt=int(data_point+j)
			#print("...it is j",str(int(latest_i-j)))
			
			if prev_flag==True:
				#print("prev=",prev)
				if prev!=0 and df_multiday_local2.loc[prev-1,"sold"]==0:
					#print("prev======",prev)
					count_prev+=1
					if count_prev > LIMIT_CHECK:
						df_multiday_local2.loc[data_point,"weight"]-=W_LOC_MULTIDAY
						#print("date and time==",df_multiday_local2.loc[data_point,"date"],df_multiday_local2.loc[data_point,"time"])
						# print(".............")
						# print("weight changed in prev")
						# print("..............")
						prev_flag=False

				elif prev==0 or df_multiday_local2.loc[prev-1,"sold"]!=0:
					#print("prev flag is False")
					prev_flag=False
					#print("prev flag becomes False")
					#break
			else:
				pass

			if nxt_flag==True:
				#print("nxt==",nxt)
				#print("length=",(len(df_multiday_local2)-1))
				if nxt!=(len(df_multiday_local2)-1) and df_multiday_local2.loc[nxt+1,"sold"]==0:
					count_nxt+=1
					#print("count===",count_nxt)
					if count_nxt > LIMIT_CHECK:
						df_multiday_local2.loc[data_point,"weight"]-=W_LOC_MULTIDAY
						#print("date and time==",df_multiday_local2.loc[data_point,"date"],df_multiday_local2.loc[data_point,"time"])
						# print(".............")
						# print("weight changed in next")
						# print(".............")
						nxt_flag=False
				elif nxt==(len(df_multiday_local2)-1) or df_multiday_local2.loc[nxt+1,"sold"]!=0:
					#print("next flag is False")
					nxt_flag=False
					#print("next flag becomes False")

			else:
				pass

			if (count_nxt+count_prev)>LIMIT_CHECK:
				df_multiday_local2.loc[data_point,"weight"]-=W_LOC_MULTIDAY
				# print(".............")
				# print("weight changed",df_multiday_local2.loc[data_point,"date"])
				# print(".............")
			elif prev_flag==False and nxt_flag==False:
				#print("Both False")
				break
			else:
				#print("in new else")
				#print("prev flag",prev_flag)
				#print("nxt flag", nxt_flag)
				pass

		return df_multiday_local2
	else:
		return df_multiday_local2




# Checking sold data amount for the particular spike of poured data.(Here it is null or not)
# And assigning the weight acoordingl
def check_sold_is_null(df_location_local2,i):
	if df_location_local2.loc[i,"sold"]==0 or df_location_local2.loc[i,"sold"]<(df_location_local2.loc[i,"poured"]/100)*2:
		df_location_local2.loc[i,"weight"]=df_location_local2.loc[i,"weight"]+W_SOLD_FULL
		return df_location_local2
	else:
		df_location_local2.loc[i,"weight"]=df_location_local2.loc[i,"weight"]+0
		return df_location_local2


# checking that the spike datapoint is in which time range(Start of the day, End of the day, middle of the day)
# and assign weight accordingly
def check_time_range(df_location_local1,i):
	#print("time",datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time())
	#if ((df_location_local1.loc[i,"time"]>"06:00:00" and df_location_local1.loc[i,"time"]<="12:00:00") or (df_location_local1.loc[i,"time"]>"22:00:00" and df_location_local1.loc[i,"time"]<"06:00:00")):
	if (datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() >= time(START_HR_MRN,START_MIN_MRN) and datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() <= time(END_HR_MRN,END_MIN_MRN)):
		df_location_local1.loc[i,"weight"]=df_location_local1.loc[i,"weight"]+W_TIME_START_OF_THE_DAY
		#print(df_location_local1.loc[i,"weight"])
		df_location_local1= check_sold_is_null(df_location_local1,i)
		return df_location_local1

	elif (datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() >= time(START_HR_NT,START_MIN_NT) or datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() <= time(END_HR_NT,END_MIN_NT)):
		df_location_local1.loc[i,"weight"]=df_location_local1.loc[i,"weight"]+W_TIME_END_OF_THE_DAY
		#print(df_location_local1.loc[i,"weight"])
		df_location_local1= check_sold_is_null(df_location_local1,i)
		return df_location_local1

		
	else:
		df_location_local1.loc[i,"weight"]=df_location_local1.loc[i,"weight"]+W_TIME_MIDDLE_OF_THE_DAY
		#print(df_location_local1.loc[i,"weight"])
		df_location_local1= check_sold_is_null(df_location_local1,i)
		return df_location_local1


# Checking standard deviation difference for all the pured data and
# assign the weight accordingly.
def check_std_dev_diff(df_location_local,i,avg):
	
	#print(avg)
	#print("std_diff",df_location_local.loc[i,"stdev_diff"])
	if df_location_local.loc[i,"stdev_diff"]>=0 and df_location_local.loc[i,"stdev_diff"]<((avg)/2):
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_FIRST_QUATER
		#print(df_location_local.loc[i,"weight"])

		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	elif df_location_local.loc[i,"stdev_diff"]>=((avg)/2) and df_location_local.loc[i,"stdev_diff"]<avg:
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_SECOND_QUATER
		#print(df_location_local.loc[i,"weight"])

		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	elif df_location_local.loc[i,"stdev_diff"] >= avg and df_location_local.loc[i,"stdev_diff"]<(avg*3/2):
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_THIRD_QUATER
		#print(df_location_local.loc[i,"weight"])
		#print(df_location_local.loc[i,"poured"])

		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	elif df_location_local.loc[i,"stdev_diff"]>=(avg*3/2):
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_FOURTH_QUATER
		#print(df_location_local.loc[i,"weight"])
		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	else:
		df_location_local.loc[i,"weight"]=0
		return df_location_local
	

# displaying results in end with a cut-off confidence
def display_result(df_location_local):
	df_location_local1=df_location_local[df_location_local["confidence"]>=DISPLAY_CONFIDENCE_CUT_OFF]
	# print(colored("product id= "+str(prod)+"",'red'))
	# #df_internet_issue_local1=df_internet_issue_local1.rename(columns={'location_id':'loc_id','location_name':'loc_name','product_id':'prod_id','product_name':'prod_name'})
	#print(df_location_local1)
	return df_location_local1
	

# comparision between linecleaning location dataframe and the linecleaning dataframe
# if in the same time both dataframes are having spike or datapoint then 
# increase the weight of that particular datapoint in the line cleaning dataframe
# def compare_with_loc(base_data_df,df_location_feature):
# 	if(len(df_location_feature)>0):
# 		base_data_df=base_data_df.reset_index(drop=True)
# 		for row in range(0,len(base_data_df)):
# 			for line in range(0,len(df_location_feature)):
# 				if base_data_df.loc[row,"date"]==df_location_feature.loc[line,"date"] and base_data_df.loc[row,"time"]==df_location_feature.loc[line,"time"]:
# 					base_data_df.loc[row,'location_std']=round(df_location_feature.loc[line,'stdev_diff'],2)
# 					base_data_df.loc[row,"location_weight"]=round(df_location_feature.loc[line,'weight'],2)
# 					break
# 		base_data_df["location_std"].fillna(0, inplace=True)
# 		base_data_df["location_weight"].fillna(0, inplace=True)
# 	else:
# 		base_data_df["location_std"] = 0.00
# 		base_data_df["location_weight"] = 0.00
# 	return base_data_df


def compare_with_loc(base_data_df,df_location_feature):
	if(len(df_location_feature)>0):
		base_data_df=base_data_df.reset_index(drop=True)
		for line in range(0,len(df_location_feature)):
			# print(base_data_df.loc[(base_data_df['date'] == df_location_feature.loc[line,"date"]) & (base_data_df['time'] == df_location_feature.loc[line,"time"]),"loc_f"])
			base_data_df.loc[(base_data_df['date'] == df_location_feature.loc[line,"date"]) & (base_data_df['time'] == df_location_feature.loc[line,"time"]),"loc_f"]=W_LOCATION
			base_data_df.loc[(base_data_df['date'] == df_location_feature.loc[line,"date"]) & (base_data_df['time'] == df_location_feature.loc[line,"time"]),"weight"]+=W_LOCATION

	return base_data_df

def linecleaning_location_main(base_data_df):
	try:
		#print ("Analysing location for "+sys.argv[1]+"")
		#log.info("Analysing location for "+sys.argv[1]+"")
		# bool_location_file_avilable = False
		pd.set_option('expand_frame_repr', False)
		pd.options.display.max_rows=2000
		df_location=base_data_df
		df_location=df_location.groupby(["date","time","loc_id","loc_name"])["poured","sold"].sum()
		df_location=df_location.reset_index(drop=False)
		#df_location=df_location.rename(columns={'location_id':'loc_id','location_name':'loc_name'})
		#print(df_location)

		mean=df_location["poured"].mean()
		#print("Mean=",mean)
		stdev=df_location["poured"].std()
		#print("Standard Deviation",stdev)
		start_date_df=df_location.sort_values(by='date', ascending=False)
		start_date_df=start_date_df.reset_index()
		#print("End date =",start_date_df.loc[0,"date"])
		end_date_df=df_location.sort_values(by='date', ascending=True)
		end_date_df=end_date_df.reset_index()
		#print("Start date =",end_date_df.loc[0,"date"])

		#print("No. Of data points",len(df_location["poured"]))
		#print(df_location)
		df_location=find_std_dev_diff(df_location,mean,stdev)

		#print(df_location["stdev_tot"])
		df_location=df_location.sort_values(by="stdev_diff", ascending=False)
		df_location=df_location.reset_index(drop=True)

		avg=stdev
		#print("average standard deviation difference=",avg)
		#print("average",avg)
		for i in range(0,len(df_location)):
			df_location=check_std_dev_diff(df_location,i,avg)

			# if i>0:
			# 	break

		df_location=df_location.sort_values(by=["date","time"])
		df_location=df_location.reset_index(drop=True)
		#print(df_location)
		for data_point in range(0,len(df_location)):
			df_location=check_neighbourhood(df_location,data_point)
			df_location= check_loc_multiday(df_location,data_point)     ### new module multiday added to location feature
		#print(MAX)
		df_location=df_location.sort_values(by='weight', ascending=False)
		df_location=df_location.reset_index(drop=True)

		df_location["confidence"]=(df_location["weight"]/MAX)*100
		df_location=df_location.rename(columns={'location_id':'loc_id','location_name':'loc_name'})

		#df_location=df_location.drop(["id"],axis=1)
		#df_location=df_location.reset_index(drop=True,col_level=1, col_fill='confidence')
		#print(df_location)

		result_df=display_result(df_location)
		
		result_df=result_df.loc[result_df["stdev_diff"]>0]
		result_df=result_df.reset_index(drop=True)

		base_data_df["loc_f"]=0								### By default zero location feature

		base_data_df= compare_with_loc(base_data_df,result_df)

		return base_data_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)


def get_linecleaning_location(base_data_df):
	line_cleaning_location_df, resp = linecleaning_location_main(base_data_df);
	return line_cleaning_location_df, resp


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pandas as pd


def main(base_data_df):
	for index,row in base_data_df.iterrows():
		base_data_df.loc[index,'t_weight'] = row['loc_w']-row['inet_w']-row['mday_w']-row['iloss_w']-row['m_plu_w']+row['std_w']+row['sold_w']

	return base_data_df


def get_total_weight(base_data_df):
	return main(base_data_df)
"""
Title: One Hour sold feature

Description: Computes one hour sold at the product level. 
Algorithm: Checked for each datapoint that the datapoint belongs to one hour sold or not.
			Ckecked with the 10 datapoints forward and backward that the points are having the sold data or not.
			If sold data is there in between 1 hr then it is penalized. 
"""


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time,timedelta
from termcolor import colored
import os, inspect
from logger_config import log
try:
	from constants import *
except:
	log.error("constants.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()

def compute_one_hour_sold_feature(df_linecleaning_local,row):
	#print("In elimination feature")
	log.debug("In check one hour sold feature")
	#log.info("Checking the sold data in one hour range")
	#print(df_linecleaning_local)
	temp_date_list=[]
	temp_time_list=[]
	date_temp=str(df_linecleaning_local.loc[row,"date"])+" "+str(df_linecleaning_local.loc[row,"time"])
	date_temp1=pd.to_datetime(date_temp)
	date_temp2=date_temp1
	#print("id",row)
	for i in range(RANGE):
		_20_backward = (date_temp1 - timedelta(minutes=VAR_MIN))
		date1,time1=str(_20_backward).split(" ")
		temp_date_list.append(date1)
		temp_time_list.append(time1)
		date_temp1= _20_backward
		_20_forward=(date_temp2 + timedelta(minutes=VAR_MIN))
		date2,time2=str(_20_forward).split(" ")
		temp_date_list.append(date2)
		temp_time_list.append(time2)
		date_temp2 =_20_forward

	sold_data=df_linecleaning_local.loc[row,"sold"]
	for j in range(RANGE):
		#print("j......=",j)
		#print(df_linecleaning_local.loc[row,"poured"])
		#print(temp_date_list[j],temp_time_list[j])
		#print ((df_linecleaning_local.dtypes))
		# value=df_linecleaning_local[df_linecleaning_local["date"]=="2017-12-08"]
		# print(value)
		#print(df_linecleaning_local)
		temp_df= df_linecleaning_local.loc[df_linecleaning_local["date"]==temp_date_list[j]]
		
		temp_df= temp_df.loc[temp_df["time"]==temp_time_list[j]]
		temp_df= temp_df.reset_index(drop=True)
		#print(temp_df)
		#print(temp_df)
		if temp_df.empty:
			#df_linecleaning_local.loc[row, "one_hr_feat"]= LINECLEANING_ONE_HOUR_DEFAULT_MAIN
			#print(df_linecleaning_local.loc[df_linecleaning_local["date"]==temp_date_list[j]].empty)
			pass
		else:
			
			sold_data+=temp_df.loc[0,"sold"]
			if sold_data>= (df_linecleaning_local.loc[row, "poured"])/2:
				#print("change")
				df_linecleaning_local.loc[row, "one_hour_sold_f"]=LINECLEANING_ONE_HOUR_MAIN
				df_linecleaning_local.loc[row, "weight"]=df_linecleaning_local.loc[row, "weight"]-LINECLEANING_ONE_HOUR_MAIN
			else:
				df_linecleaning_local.loc[row,"one_hour_sold_f"]= 0
				
	# else:
	# 	df_linecleaning_local.loc[row, "one_hr_feat"]= 0
	# 	pass
	#print(df_linecleaning_local.loc[row,"one_hour_sold_f"])
	return df_linecleaning_local

# def compute_one_hour_sold_weight(df_linecleaning_local,row):
# 	df_linecleaning_local.loc[row, "one_hour_sold_w"] = df_linecleaning_local.loc[row, "one_hour_sold_f"]
# 	return df_linecleaning_local

def check_one_hour_sold_main(base_data_df):
	try:
		#print ("Analysing multiday issue for "+sys.argv[1]+"")
		#log.info("Analysing one hour sold feature for "+sys.argv[1]+"")
		pd.set_option('expand_frame_repr', False)

		result_df=pd.DataFrame()
		prod_uniq=base_data_df["prod_id"].unique()
		for prod in prod_uniq:
			df_one_hour_sold=base_data_df[base_data_df["prod_id"]==prod]
			df_one_hour_sold=df_one_hour_sold.sort_values(by=['date','time'],ascending=True)
			df_one_hour_sold=df_one_hour_sold.reset_index()
			
			df_one_hour_sold["one_hour_sold_f"]= 0
			#print(df_one_hour_sold)
			for index in range(0,len(df_one_hour_sold)):
				df_one_hour_sold=compute_one_hour_sold_feature(df_one_hour_sold,index)
				#df_one_hour_sold= compute_one_hour_sold_weight(df_one_hour_sold,index)
			
			#print(df_one_hour_sold)
			
			#print(df_one_hour_sold)
			result_df=result_df.append(df_one_hour_sold)
			# print("prod: ",prod)
			# if prod==25:
			# 	sys.exit()
		result_df=result_df.sort_values(by=['date','time'])
		result_df=result_df.reset_index(drop=True)
		#result_df.to_csv('./'+str(sys.argv[1])+'_onehr_dump.csv',index = False)
		return result_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)
	
	
def check_one_hour_sold(base_data_df):
	return check_one_hour_sold_main(base_data_df)
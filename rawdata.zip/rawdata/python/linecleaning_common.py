#----------- Database Credentials ----------
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from constants import *
try:
	from logger_config import log
except:
	log.error("logger_config.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()

# MY_SQL_HOST_NAME = 'hadoop.vmoksha.com'
# MY_SQL_USER_NAME = 'root'
# MY_SQL_PASSWORD = 'Power@1234'
# MY_SQL_DB_NAME = 'beerboardLocalDb'

# NORMALIZATION_TABLE = '68_normalizedPouredSold'
# RAW_TABLE="68_nagitive_variance"


# To Check that the network is connected or not
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(connection_hadoop_check)
			#traceback.print_exc()
			t.sleep(30)

	return connection_hadoop_check


# To check that the Database is there or not
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None


# To connect the Database in mysql
def connect_to_db(host,user,password,db):
	connection_hadoop_internal=0
	while (connection_hadoop_internal==0):
		try:
			connection_hadoop_internal = pymysql.connect(host=host,
	                             	user=user,
	                             	password=password,
	                             	db=db,
	                             	charset='utf8mb4',
	                             	cursorclass=pymysql.cursors.DictCursor)
		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(connection_hadoop_check)
			#traceback.print_exc()
			t.sleep(30)

	return connection_hadoop_internal


# To check that there Table exixts or not in Database
def check_if_Table_exits(connection_to_db,TABLE):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+TABLE+";"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except:
		#traceback.print_stack()
		return False

# To retry again and again till network comes while executing the sql query
def network_call(sql,hadoop_cursor):
	#response  = ""
	response_code = 0
	while (response_code==0):
		try:
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall()
		except:
			log.critical(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			#print(colored("NETWORK CALL TIME OUT. RETRYING ... ",'red'))
			traceback.print_exc()
			t.sleep(10)
			#traceback.print_stack()
	return response_code


# To get the normalized data from the normalized table for a particular location
def get_normalized_data(location_id,from_date,to_date):
	empty_df=pd.DataFrame()
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	if(check_if_DB_exists(connection_check)==None):
		return empty_df,"Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,NORM_POURED_SOLD_TABLE)!=True):
		
		return empty_df,"Table "+NORM_POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			#sql="select *, DATE_FORMAT(time, '%T') as time_str from "+NORMALIZATION_TABLE +" where date between '"+from_date+"' and '"+to_date+"' and location_id = "+str(location_id)+";"
			sql="select *, DATE_FORMAT(time, '%T') as time_str, DATE_FORMAT(date, '%Y-%m-%d') as date_str from "+NORM_POURED_SOLD_TABLE +" where date between '"+from_date+"' and '"+to_date+"' and location_id =  "+str(location_id)+";"
			#print (sql)
			
			data=network_call(sql,hadoop_cursor)
			
			data = pd.DataFrame(data)
			#print(data)
			data = data.drop('time', 1)
			data = data.drop('date', 1)
			data = data.rename(columns = {'time_str':'time','date_str':'date'})

	except:
		log.error("Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		#print("Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		# data = []
		# data = pd.DataFrame(data)
		#return None
		return empty_df,"Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3])
		#traceback.print_exc()
	connection_to_db.close()
	return data,"Success"

def get_line_number_data(location_id,from_date,to_date):
	empty_df=pd.DataFrame()
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	if(check_if_DB_exists(connection_check)==None):
		return empty_df,empty_df,"Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,POURED_SOLD_TABLE)!=True):
		return empty_df,empty_df,"Table "+POURED_SOLD_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="select * from "+POURED_SOLD_TABLE +" where date between '"+from_date+"' and '"+to_date+"' and location_id = "+str(location_id)+";"
			#print (sql)
			raw_data=network_call(sql,hadoop_cursor)
			
			data = pd.DataFrame(raw_data)
			#print(data)
			data_raw= pd.DataFrame(raw_data)
			data['date'], data['time'] = data['date'].str.split(' ', 1).str
			
			# data = data.drop('time', 1)
			# data = data.rename(columns = {'time_str':'time'})

	except:
		log.error("Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		#print("Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		# data = []
		# data = pd.DataFrame(data)
		#return None
		#traceback.print_exc()
		return empty_df,empty_df,"Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3])
		#traceback.print_exc()
	connection_to_db.close()
	#print(data_raw)
	return data,data_raw,"Success"

# To check that the date format is correct or not
def validate(date_text):
    try:
        datetime.strptime(date_text, '%Y-%m-%d')
        #print(date_text)
        return True
    except Exception as e:
    	log.error(e)
    	#print(e)
    	log.error(date_text)
    	#print(date_text)
    	return False
    	
def get_all_locations(date):
	empty_df=pd.DataFrame()
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		
	if(check_if_DB_exists(connection_check)==None):
		
		return empty_df,"Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,LOCATION_DATE_TABLE)!=True):
		
		return empty_df,"Table "+LOCATION_DATE_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="select date,user_id,user_name,location_id,location_name from "+LOCATION_DATE_TABLE +" where date = \""+date+"\" and exceflag = 1;"		
			data=network_call(sql,hadoop_cursor)
			data = pd.DataFrame(data)
			

	except Exception as e:
		log.error("Location's data is not available for the date " + date)
		data = pd.DataFrame()
		return empty_df,"Location's data is not available for the date " + date
	finally:
		connection_to_db.close()
	return data,"Success"

def get_plu_table_data(location_id,from_date,to_date):
	empty_df=pd.DataFrame()
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	if(check_if_DB_exists(connection_check)==None):
		return empty_df,"Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,PLU_TABLE)!=True):
		return empty_df,"Table "+PLU_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="select * from "+PLU_TABLE +" where date between '"+from_date+"' and '"+to_date+"' and location_id = "+str(location_id)+";"
			#print (sql)
			data=network_call(sql,hadoop_cursor)
			
			data = pd.DataFrame(data)
			#data['date'], data['time'] = data['date'].str.split(' ', 1).str
			
			# data = data.drop('time', 1)
			# data = data.rename(columns = {'time_str':'time'})

	except:
		log.error("PLU data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		#print("Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		# data = []
		# data = pd.DataFrame()
		connection_to_db.close()
		return empty_df, "PLU data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3])
		#traceback.print_exc()
		
		#traceback.print_exc()
	connection_to_db.close()
	return data, "Success"

def get_all_locations_based_on_date_range(start_date, end_date):
	empty_df=pd.DataFrame()
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		
	if(check_if_DB_exists(connection_check)==None):
		
		return empty_df,"Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,NORM_POURED_SOLD_TABLE)!=True):
		
		return empty_df,"Table "+LOCATION_DATE_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="select date,user_id,user_name,location_id,location_name from "+LOCATION_DATE_TABLE +" where date between \""+start_date+"\" and \""+end_date+"\" and exceflag = 1;"		
			
			#sql="select distinct(location_id),location_name,date from "+LOCATION_DATE_TABLE +" where date between \""+start_date+"\" and \""+end_date+"\";"		
			data=network_call(sql,hadoop_cursor)
			print (sql)
			data = pd.DataFrame(data)
			

	except:
		log.error("Location's data is not available for the date between " + start_date +" and "+end_date)
		data = pd.DataFrame()
		return empty_df,"Location's data is not available for the date between " + start_date +" and "+end_date
	finally:
		connection_to_db.close()
	return data,"Success"

def check_if_details_exsts(date,ProductId,start_time,end_time,loc_id,line_number):
	empty_flag = pd.DataFrame()
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		
	if(check_if_DB_exists(connection_check)==None):
		
		return empty_flag,"Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,LINE_CLEANING_RESULTS)!=True):
		
		return empty_flag,"Table "+LINE_CLEANING_RESULTS+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="select * from "+LINE_CLEANING_RESULTS +" where LineCleaningDate = \""+date+"\" and ProductId = "+str(ProductId)+" and StartTime =\""+start_time+"\" and EndTime = \""+end_time+"\" and LocationId = "+str(loc_id)+" and LineNumber = "+str(line_number)+";"	
			print (sql)
			data=network_call(sql,hadoop_cursor)
			print (data)
	except:
		log.error("Line_cleaning data is not available" + date)
		data = []
		return empty_flag,"Line_cleaning data is not available"+date
	finally:
		connection_to_db.close()
	return data,"Success"

def save_line_cleaning_details_to_db(ProductId,LocationId,LineCleaningDate,StartTime,EndTime,ProductName,LocationName,LineNumber,Confidence,ProductLoss,ProductLocationLoss,CreatedAt,ModifiedAt,UpdateCount,user_name_,user_id_,LineId):
	
	print (ProductId,LocationId,LineCleaningDate,StartTime,EndTime,ProductName,LocationName,LineNumber,Confidence,ProductLoss,ProductLocationLoss,CreatedAt,ModifiedAt,UpdateCount,user_name_,user_id_,LineId)
	try:
		ProductId=int(ProductId)
		LocationId=int(LocationId)
		user_id_=int(user_id_)
		print(ProductId,LocationId,user_id_)
	except:
		print(ProductId,LocationId,user_id_)
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		
	if(check_if_DB_exists(connection_check)==None):
		
		return "Database "+MY_SQL_DB_NAME+" not found."

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		

	#print(check_if_Table_exits(connection_to_db))

	if(check_if_Table_exits(connection_to_db,LINE_CLEANING_RESULTS)!=True):
		
		return "Table "+LINE_CLEANING_RESULTS+" is not in the "+MY_SQL_DB_NAME+" Database."

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="INSERT INTO "+LINE_CLEANING_RESULTS+" (CustomerId,CustomerName,ProductId,LocationId,LineCleaningDate,StartTime,EndTime,ProductName,LocationName,LineNumber,LineId,Confidence,ProductLoss,ProductLocationLoss,CreatedAt,ModifiedAt,UpdateCount)VALUES('"+str(user_id_)+"',\""+str(user_name_)+"\",'"+str(ProductId)+"','"+str(LocationId)+"',\""+LineCleaningDate+"\",\""+StartTime+"\",\""+EndTime+"\",\""+ProductName+"\",\""+LocationName+"\",\""+str(LineNumber)+"\",\""+str(LineId)+"\",\""+str(Confidence)+"\",\""+str(ProductLoss)+"\",\""+str(ProductLocationLoss)+"\",\""+CreatedAt+"\",\""+ModifiedAt+"\","+str(UpdateCount)+")"		
			#print (sql)
			hadoop_cursor.execute(sql)
			connection_to_db.commit()
			print ("Saved")
	except Exception as e:
		print (e)
		return "Line cleaning data not saved"
	finally:
		connection_to_db.close()
	return "Success"




def get_location_info_for_row_table(date):
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	if(check_if_DB_exists(connection_check)==None):
		sys.exit("\nDatabase "+MY_SQL_DB_NAME+" not found.")

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,LOCATION_DATE_TABLE)!=True):
		sys.exit("\nTable "+LOCATION_DATE_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database.")

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			if (date == None):
				sql="select distinct(location_id),date,location_name,normflag,rawflag,user_id,user_name from "+LOCATION_DATE_TABLE +" where rawflag = "+ str(0)+";"
			else:
				sql="select distinct(location_id),date,location_name,normflag,rawflag,user_id,user_name from "+LOCATION_DATE_TABLE +" where rawflag = "+ str(0)+" and date = '"+date+"';"
			print (sql)
			data=network_call(sql,hadoop_cursor)
			if (len(data)>0):
				data = pd.DataFrame(data)
			else:
				data = pd.DataFrame()

	except:
		data = pd.DataFrame()
		log.error("Date does not exit")
	connection_to_db.close()
	return data


def get_product_id_from_table(product_name):
	try:
		connection_check=check_connection(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD)
	except:
		log.critical(colored("Network Error.",'red'))
		#print("Network Error.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	if(check_if_DB_exists(connection_check)==None):
		sys.exit("\nDatabase "+MY_SQL_DB_NAME+" not found.")

	try:
		connection_to_db = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	except Exception as e:
		log.critical(e)
		#print (e)
		#print(connection_to_db)
		log.critical("Database "+MY_SQL_DB_NAME+" connection not established.")
		#print("\nDatabase "+MY_SQL_DB_NAME+" connection not established.")
		#return None
		traceback.print_exc(limit=0,file=sys.stdout)
		#sys.exit()

	#print(check_if_Table_exits(connection_to_db))
	

	if(check_if_Table_exits(connection_to_db,PRODUCT_TABLE)!=True):
		sys.exit("\nTable "+PRODUCT_TABLE+" is not in the "+MY_SQL_DB_NAME+" Database.")

	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="select distinct(id) from "+PRODUCT_TABLE +" where name = \""+product_name+"\";"
			#print (sql)
			data=network_call(sql,hadoop_cursor)
			#print (data)

	except:
		data = pd.DataFrame()
		log.error("Date does not exit")
	connection_to_db.close()
	return data
"""
Title: Internet feature

Description: Computes Internet issue at the location level. 
Algorithm: 1.Standard deviation for the given duration is calculated for each datapoint and
		   2. Each datapoint is checked for sold data and poured data
 		   3. For the poured of each datapoint checked the sum of sold for back datapoints without pored.
 		   4. Algorithm will  
 		   			a)  award weight for each datapoint proportional to 
 		   					i) Standard deviation
 		   					ii) Sold data
 		   					iii) Sold data sum for prevoius datapoints
 		   					
 		   			
 		   5 Compare with base dataframe and assign the weight according to the linecleaning at location level by comparing the date and time.
"""


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from logger_config import log
from constants import *




# def compare_internet_df(base_data_df,df_location):
# 	#print(df_location)
# 	log.debug(base_data_df)
# 	for item in range(0,len(base_data_df)):
# 		inet_temp=df_location.loc[(df_location['date'] == base_data_df.loc[item,"date"]) & (df_location['time'] == base_data_df.loc[item,"time"]), ['inet_f']]
# 		#print(base_data_df.loc[item,"date"],base_data_df.loc[item,"time"])
# 		base_data_df.loc[item,"inet_f"]= inet_temp["inet_f"].values[0]
# 		base_data_df.loc[item,"inet_w"]= inet_temp["inet_f"].values[0]
# 		#print(inet_temp["inet_f"].values[0])
# 		#sys.exit()
# 	return base_data_df


# compare the inetrnet datafreme with the base dataframe
def compare_internet_df(base_data_df,df_internet_issue_local):
	# print(df_internet_issue_local)
	if(len(df_internet_issue_local)>0):
		base_data_df=base_data_df.reset_index(drop=True)
		for line in range(0,len(df_internet_issue_local)):
			# print(base_data_df.loc[(base_data_df['date'] == df_internet_issue_local.loc[line,"date"]) & (base_data_df['time'] == df_internet_issue_local.loc[line,"time"]),"loc_f"])
			base_data_df.loc[(base_data_df['date'] == df_internet_issue_local.loc[line,"date"]) & (base_data_df['time'] == df_internet_issue_local.loc[line,"time"]),"inet_f"]=W_INET
			base_data_df.loc[(base_data_df['date'] == df_internet_issue_local.loc[line,"date"]) & (base_data_df['time'] == df_internet_issue_local.loc[line,"time"]),"weight"]-=W_INET

	return base_data_df

# find standard deviation for all the data-points
def find_std_dev_diff(df_internet_issue_local,mean,stdev):
	for i,j in enumerate(df_internet_issue_local["poured"]):
		df_internet_issue_local.loc[i,"stdev_diff"]=(j-(mean))
	return(df_internet_issue_local)

# Checking that, for a poured spike detected, there is a same amount of sold data or not,
# just before the time it is detected. If not than assign the weight accordingly.
def check_poured_sold_sum(df_internet_issue_local2,i):
	#print("........in check_poured_sold_sum")
	#print(".....i= ",i)
	sold_sum=0
	latest_i=int(i)
	for j in range(latest_i):
		latest_j=int(latest_i-j)
		#print("...it is j",str(int(latest_i-j)))
		if latest_j!=0 and df_internet_issue_local2.loc[latest_j-1,"poured"]==0:
			#print("j======",latest_j-1)
			#print("pouredddddddddddd",df_internet_issue_local2.loc[latest_j-1,"poured"])
			#print("soldddddddddddddd",df_internet_issue_local2.loc[latest_j-1,"sold"])
			#print("dateeeee",df_internet_issue_local2.loc[latest_j-1,"date"])
			#print("timeeeee",df_internet_issue_local2.loc[latest_j-1,"time"])
			sold_sum=sold_sum+df_internet_issue_local2.loc[latest_j-1,"sold"]
			#print("sold_sum =",sold_sum)
		else:
			#print("Break")
			break
	#print("sold_sum complete=====",sold_sum)
	if sold_sum >= (df_internet_issue_local2.loc[i,"poured"]*3/4):
		df_internet_issue_local2.loc[i,"weight"]=df_internet_issue_local2.loc[i,"weight"]+INET_W_SOLD_SUM_FOURTH_QUATER
		df_internet_issue_local2.loc[i,"sold_sum"]=sold_sum
		#print(df_internet_issue_local2.loc[i,"weight"])

	elif sold_sum >= (df_internet_issue_local2.loc[i,"poured"]*1/2) and sold_sum < (df_internet_issue_local2.loc[i,"poured"]*3/4):
		df_internet_issue_local2.loc[i,"weight"]=df_internet_issue_local2.loc[i,"weight"]+INET_W_SOLD_SUM_THIRD_QUATER
		df_internet_issue_local2.loc[i,"sold_sum"]=sold_sum
		#print(df_internet_issue_local2.loc[i,"weight"])

	elif sold_sum >= (df_internet_issue_local2.loc[i,"poured"]*1/4) and sold_sum < (df_internet_issue_local2.loc[i,"poured"]*1/2):
		df_internet_issue_local2.loc[i,"weight"]=df_internet_issue_local2.loc[i,"weight"]+INET_W_SOLD_SUM_SECOND_QUATER
		df_internet_issue_local2.loc[i,"sold_sum"]=sold_sum
		#print(df_internet_issue_local2.loc[i,"weight"])

	else:
		df_internet_issue_local2.loc[i,"weight"]=df_internet_issue_local2.loc[i,"weight"]+INET_W_SOLD_SUM_FIRST_QUATER
		df_internet_issue_local2.loc[i,"sold_sum"]=sold_sum
		#print(df_internet_issue_local2.loc[i,"weight"])

	#print("...sold sum",sold_sum)

	return df_internet_issue_local2


# Checking sold data amount for the particular spike of poured data.
# And assigning the weight acoordingly 
def check_poured_and_sold(df_internet_issue_local1,i):
	#print("..... in check_poured_sold")
	#print("solddddddd....",df_internet_issue_local1.loc[i,"sold"])
	#print("poureddddd....",df_internet_issue_local1.loc[i,"poured"])
	
	if df_internet_issue_local1.loc[i,"sold"]>=0 and df_internet_issue_local1.loc[i,"sold"]<(df_internet_issue_local1.loc[i,"poured"]/4):
		df_internet_issue_local1.loc[i,"weight"]=df_internet_issue_local1.loc[i,"weight"]+INET_W_SOLD_FIRST_QUATER
		#print("1....",df_internet_issue_local1.loc[i,"weight"])
		df_internet_issue_local1=check_poured_sold_sum(df_internet_issue_local1,i)
		return df_internet_issue_local1

	elif df_internet_issue_local1.loc[i,"sold"]>=(df_internet_issue_local1.loc[i,"poured"]/4) and df_internet_issue_local1.loc[i,"sold"]<(df_internet_issue_local1.loc[i,"poured"]/2):
		df_internet_issue_local1.loc[i,"weight"]=df_internet_issue_local1.loc[i,"weight"]+INET_W_SOLD_SECOND_QUATER
		#print("2....",df_internet_issue_local1.loc[i,"weight"])
		df_internet_issue_local1=check_poured_sold_sum(df_internet_issue_local1,i)
		return df_internet_issue_local1

	elif df_internet_issue_local1.loc[i,"sold"]>=(df_internet_issue_local1.loc[i,"poured"]/2) and df_internet_issue_local1.loc[i,"sold"]<((df_internet_issue_local1.loc[i,"poured"]*3)/4):
		df_internet_issue_local1.loc[i,"weight"]=df_internet_issue_local1.loc[i,"weight"]+INET_W_SOLD_THIRD_QUATER
		#print("3....",df_internet_issue_local1.loc[i,"weight"])
		df_internet_issue_local1=check_poured_sold_sum(df_internet_issue_local1,i)
		return df_internet_issue_local1
	else:
		df_internet_issue_local1.loc[i,"weight"]=df_internet_issue_local1.loc[i,"weight"]+INET_W_SOLD_FOURTH_QUATER
		#print("4....",df_internet_issue_local1.loc[i,"weight"])
		df_internet_issue_local1=check_poured_sold_sum(df_internet_issue_local1,i)
		return df_internet_issue_local1

# Checking standard deviation difference for all the pured data and
# assign the weight accordingly.
def check_std_dev_diff(df_internet_issue_local,i,avg):
	#print("...... in check std_dev difference")
	#print(avg)
	#print("std_diff",df_internet_issue_local.loc[i,"stdev_diff"])
	if df_internet_issue_local.loc[i,"stdev_diff"]>=0 and df_internet_issue_local.loc[i,"stdev_diff"]<((avg)/2):
		df_internet_issue_local.loc[i,"weight"]=INET_W_FROM_SD_FIRST_QUATER
		#print("....std diff 1",df_internet_issue_local.loc[i,"stdev_diff"])
		#print(df_internet_issue_local.loc[i,"weight"])

		df_internet_issue_local=check_poured_and_sold(df_internet_issue_local,i)
		return df_internet_issue_local

	elif df_internet_issue_local.loc[i,"stdev_diff"]>=((avg)/2) and df_internet_issue_local.loc[i,"stdev_diff"]<avg:
		df_internet_issue_local.loc[i,"weight"]=INET_W_FROM_SD_SECOND_QUATER
		#print("....std diff 2",df_internet_issue_local.loc[i,"stdev_diff"])
		#print(df_internet_issue_local.loc[i,"weight"])

		df_internet_issue_local=check_poured_and_sold(df_internet_issue_local,i)
		return df_internet_issue_local

	elif df_internet_issue_local.loc[i,"stdev_diff"] >= avg and df_internet_issue_local.loc[i,"stdev_diff"]<(avg*3/2):
		df_internet_issue_local.loc[i,"weight"]=INET_W_FROM_SD_THIRD_QUATER
		#print("....std diff 3",df_internet_issue_local.loc[i,"stdev_diff"])
		#print(df_internet_issue_local.loc[i,"weight"])

		df_internet_issue_local=check_poured_and_sold(df_internet_issue_local,i)
		return df_internet_issue_local

	elif df_internet_issue_local.loc[i,"stdev_diff"]>=(avg*3/2):
		df_internet_issue_local.loc[i,"weight"]=INET_W_FROM_SD_FOURTH_QUATER
		#print("....std diff 4",df_internet_issue_local.loc[i,"stdev_diff"])
		#print(df_internet_issue_local.loc[i,"weight"])
		df_internet_issue_local=check_poured_and_sold(df_internet_issue_local,i)
		return df_internet_issue_local

	else:
		df_internet_issue_local.loc[i,"weight"]=0         			### std deviation diffrence is zero here
		df_internet_issue_local.loc[i,"sold_sum"]=0
		#print("....std diff 0",df_internet_issue_local.loc[i,"stdev_diff"])
		return df_internet_issue_local

# displaying results in end with a cut-off confidence
def display_result(df_internet_issue_local):
	df_internet_issue_local1=df_internet_issue_local[df_internet_issue_local["confidence"]>=INET_DISPLAY_CONFIDENCE_CUT_OFF]
	# print(colored("product id= "+str(prod)+"",'red'))
	# #df_internet_issue_local1=df_internet_issue_local1.rename(columns={'location_id':'loc_id','location_name':'loc_name','product_id':'prod_id','product_name':'prod_name'})
	# print(df_internet_issue_local1)
	return df_internet_issue_local1



def internet_issue_main(base_data_df):
	try:
		loc_df = base_data_df
		result_df=pd.DataFrame()

		df_internet_issue=loc_df.groupby(["date","time","loc_id","loc_name"])["poured","sold"].sum()
		df_internet_issue=df_internet_issue.reset_index(drop=False)
		#print(df_internet_issue)
		#df_internet_issue=df_internet_issue.reset_index()
		mean=df_internet_issue["poured"].mean()
		#print("Mean=",mean)
		stdev=df_internet_issue["poured"].std()
		#print("Standard Deviation =",stdev)
		
		start_date_df=df_internet_issue.sort_values(by='date', ascending=False)
		start_date_df=start_date_df.reset_index(drop=True)
		#print("End date =",start_date_df.loc[0,"date"])
		end_date_df=df_internet_issue.sort_values(by='date', ascending=True)
		end_date_df=end_date_df.reset_index(drop=True)
		#print("Start date =",end_date_df.loc[0,"date"])

		#print("No. Of data points =",len(df_internet_issue["poured"]))

		df_internet_issue=find_std_dev_diff(df_internet_issue,mean,stdev)
		#df_internet_issue=df_internet_issue
		#print(df_internet_issue)
		df_internet_issue=df_internet_issue.sort_values(by=["date","time"],ascending=True)
		df_internet_issue=df_internet_issue.reset_index(drop=True)
		# print(df_internet_issue)
		avg=stdev
		#avg=((df_internet_issue["stdev_diff"].max())/2)
		if avg==0:
			df_internet_issue["weight"]=0
		else:
			for i in range(0,len(df_internet_issue)):
				df_internet_issue=check_std_dev_diff(df_internet_issue,i,avg)

		base_data_df["inet_f"]=0								### By default zero location feature
		df_internet_issue["confidence"]=(df_internet_issue["weight"]/INET_MAX)*100
		df_internet_issue=display_result(df_internet_issue)
		df_internet_issue=df_internet_issue.reset_index(drop=True)

		base_data_df = compare_internet_df(base_data_df,df_internet_issue)
		# base_data_df=base_data_df.rename(columns={'inet_std':'inet_f','inet_weight':'inet_w'})
		return base_data_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)

def get_internet_issue(base_data_df):
	return internet_issue_main(base_data_df)
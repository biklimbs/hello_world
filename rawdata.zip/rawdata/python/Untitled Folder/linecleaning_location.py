import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from logger_config import log
from constants import display_modified_df
import constants as cs


START_HR_MRN=cs.LINECLEANING_LOCATION_START_HR_MRN
START_MIN_MRN=cs.LINECLEANING_LOCATION_START_MIN_MRN
END_HR_MRN=cs.LINECLEANING_LOCATION_END_HR_MRN
END_MIN_MRN=cs.LINECLEANING_LOCATION_END_MIN_MRN
START_HR_NT=cs.LINECLEANING_LOCATION_START_HR_NT
START_MIN_NT=cs.LINECLEANING_LOCATION_START_MIN_NT
END_HR_NT=cs.LINECLEANING_LOCATION_END_HR_NT
END_MIN_NT=cs.LINECLEANING_LOCATION_END_MIN_NT

W_SOLD_FULL=cs.LINECLEANING_LOCATION_W_SOLD_FULL
W_SOLD_20= cs.LINECLEANING_LOCATION_W_SOLD_20
W_SOLD_HALF=cs.LINECLEANING_LOCATION_W_SOLD_HALF
W_SOLD_QUATER=cs.LINECLEANING_LOCATION_W_SOLD_QUATER

W_TIME_START_OF_THE_DAY=cs.LINECLEANING_LOCATION_W_TIME_START_OF_THE_DAY
W_TIME_MIDDLE_OF_THE_DAY=cs.LINECLEANING_LOCATION_W_TIME_MIDDLE_OF_THE_DAY
W_TIME_END_OF_THE_DAY=cs.LINECLEANING_LOCATION_W_TIME_END_OF_THE_DAY



W_DEVIATION_FROM_SD_FIRST_QUATER=cs.LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_FIRST_QUATER
W_DEVIATION_FROM_SD_SECOND_QUATER=cs.LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_SECOND_QUATER
W_DEVIATION_FROM_SD_THIRD_QUATER=cs.LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_THIRD_QUATER
W_DEVIATION_FROM_SD_FOURTH_QUATER=cs.LINECLEANING_LOCATION_W_DEVIATION_FROM_SD_FOURTH_QUATER

W_NEIGHBOURHOOD= cs.LINECLEANING_LOCATION_W_NEIGHBOURHOOD

MAX=cs.LINECLEANING_LOCATION_MAX
DISPLAY_CONFIDENCE_CUT_OFF=cs.LINECLEANING_LOCATION_DISPLAY_CONFIDENCE_CUT_OFF

W_LOCATION=cs.LINECLEANING_LOCATION_W_LOCATION=1


# find standard deviation for all the data-points
def find_std_dev_diff(df_location_local,mean,stdev):
	for i,j in enumerate(df_location_local["poured"]):
		df_location_local.loc[i,"stdev_diff"]=(j-(mean))
	return(df_location_local)

# checking the neighbourhood feature, for the datapoint in linecleaning dataframe with sold data zero
# if any near by datapoint is having maximum weight then that datapoint will be assignd maximum weight
# this is location wise
def check_neighbourhood(df_location_local,data_point):
	#latest_i=int(i)
	if df_location_local.loc[data_point,"sold"]==0 and df_location_local.loc[data_point,"weight"]!=MAX:
		
		prev_flag=True
		nxt_flag=True
		for j in range(data_point):
			prev=int(data_point-j)
			nxt=int(data_point+j)
			#print("...it is j",str(int(latest_i-j)))
			
			if prev_flag==True:
				#print("prev=",prev)
				if prev!=0 and df_location_local.loc[prev-1,"weight"]==MAX:
					#print("prev======",prev)
					df_location_local.loc[data_point,"weight"]=W_NEIGHBOURHOOD
					#print("date and time==",df_location_local.loc[data_point,"date"],df_location_local.loc[data_point,"time"])
					#print("weight changed in prev")
					prev_flag=False

				elif prev==0 or df_location_local.loc[prev-1,"sold"]!=0:
					#print("prev flag is False")
					prev_flag=False
					#break
			if nxt_flag==True:
				#print("nxt==",nxt)
				#print("length=",(len(df_location_local)-1))
				if nxt!=(len(df_location_local)-1) and df_location_local.loc[nxt+1,"weight"]==MAX:
					df_location_local.loc[data_point,"weight"]=W_NEIGHBOURHOOD
					#print("date and time==",df_location_local.loc[data_point,"date"],df_location_local.loc[data_point,"time"])
					#print("weight changed in next")
					nxt_flag=False
				elif nxt==(len(df_location_local)-1) or df_location_local.loc[nxt+1,"sold"]!=0:
					#print("next flag is False")
					nxt_flag=False

			if prev_flag==False and nxt_flag==False:
				#print("Both False")
				break

		return df_location_local
	else:
		return df_location_local


# Checking sold data amount for the particular spike of poured data.(Here it is null or not)
# And assigning the weight acoordingl
def check_sold_is_null(df_location_local2,i):
	if df_location_local2.loc[i,"sold"]==0 or df_location_local2.loc[i,"sold"]<(df_location_local2.loc[i,"poured"]/100):
		df_location_local2.loc[i,"weight"]=df_location_local2.loc[i,"weight"]+W_SOLD_FULL
		
	elif df_location_local2.loc[i,"sold"]>=(df_location_local2.loc[i,"poured"]/100) and df_location_local2.loc[i,"sold"]<((df_location_local2.loc[i,"poured"]/100)*20):
		df_location_local2.loc[i,"weight"]=df_location_local2.loc[i,"weight"]+W_SOLD_20
	else:
		df_location_local2.loc[i,"weight"]=df_location_local2.loc[i,"weight"]+0
		
	return df_location_local2

# checking that the spike datapoint is in which time range(Start of the day, End of the day, middle of the day)
# and assign weight accordingly
def check_time_range(df_location_local1,i):
	#print("time",datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time())
	#if ((df_location_local1.loc[i,"time"]>"06:00:00" and df_location_local1.loc[i,"time"]<="12:00:00") or (df_location_local1.loc[i,"time"]>"22:00:00" and df_location_local1.loc[i,"time"]<"06:00:00")):
	if (datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() >= time(START_HR_MRN,START_MIN_MRN) and datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() <= time(END_HR_MRN,END_MIN_MRN)):
		df_location_local1.loc[i,"weight"]=df_location_local1.loc[i,"weight"]+W_TIME_START_OF_THE_DAY
		#print(df_location_local1.loc[i,"weight"])
		df_location_local1= check_sold_is_null(df_location_local1,i)
		return df_location_local1

	elif (datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() >= time(START_HR_NT,START_MIN_NT) or datetime.strptime(df_location_local1.loc[i,"time"], '%H:%M:%S').time() <= time(END_HR_NT,END_MIN_NT)):
		df_location_local1.loc[i,"weight"]=df_location_local1.loc[i,"weight"]+W_TIME_END_OF_THE_DAY
		#print(df_location_local1.loc[i,"weight"])
		df_location_local1= check_sold_is_null(df_location_local1,i)
		return df_location_local1

		
	else:
		df_location_local1.loc[i,"weight"]=df_location_local1.loc[i,"weight"]+W_TIME_MIDDLE_OF_THE_DAY
		#print(df_location_local1.loc[i,"weight"])
		df_location_local1= check_sold_is_null(df_location_local1,i)
		return df_location_local1


# Checking standard deviation difference for all the pured data and
# assign the weight accordingly.
def check_std_dev_diff(df_location_local,i,avg):
	
	#print(avg)
	#print("std_diff",df_location_local.loc[i,"stdev_diff"])
	if df_location_local.loc[i,"stdev_diff"]>=0 and df_location_local.loc[i,"stdev_diff"]<((avg)/2):
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_FIRST_QUATER
		#print(df_location_local.loc[i,"weight"])

		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	elif df_location_local.loc[i,"stdev_diff"]>=((avg)/2) and df_location_local.loc[i,"stdev_diff"]<avg:
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_SECOND_QUATER
		#print(df_location_local.loc[i,"weight"])

		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	elif df_location_local.loc[i,"stdev_diff"] >= avg and df_location_local.loc[i,"stdev_diff"]<(avg*3/2):
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_THIRD_QUATER
		#print(df_location_local.loc[i,"weight"])

		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	elif df_location_local.loc[i,"stdev_diff"]>=(avg*3/2):
		df_location_local.loc[i,"weight"]=W_DEVIATION_FROM_SD_FOURTH_QUATER
		#print(df_location_local.loc[i,"weight"])
		df_location_local=check_time_range(df_location_local,i)
		return df_location_local

	else:
		df_location_local.loc[i,"weight"]=0
		return df_location_local


# displaying results in end with a cut-off confidence
def display_result(df_location_local):
	df_location_local1=df_location_local[df_location_local["confidence"]>=DISPLAY_CONFIDENCE_CUT_OFF]
	# print(colored("product id= "+str(prod)+"",'red'))
	# #df_internet_issue_local1=df_internet_issue_local1.rename(columns={'location_id':'loc_id','location_name':'loc_name','product_id':'prod_id','product_name':'prod_name'})
	#print(df_location_local1)
	return df_location_local1
	
# comparision between linecleaning location dataframe and the linecleaning dataframe
# if in the same time both dataframes are having spike or datapoint then 
# increase the weight of that particular datapoint in the line cleaning dataframe
def compare_with_loc(base_data_df,df_location_feature):
	if(len(df_location_feature)>0):
		base_data_df=base_data_df.reset_index(drop=True)
		for row in range(0,len(base_data_df)):
			for line in range(0,len(df_location_feature)):
				if base_data_df.loc[row,"date"]==df_location_feature.loc[line,"date"] and base_data_df.loc[row,"time"]==df_location_feature.loc[line,"time"]:
					base_data_df.loc[row,'location_std']=round(df_location_feature.loc[line,'stdev_diff'],2)
					base_data_df.loc[row,"location_weight"]=round(df_location_feature.loc[line,'weight'],2)
					break
		base_data_df["location_std"].fillna(0, inplace=True)
		base_data_df["location_weight"].fillna(0, inplace=True)
	else:
		base_data_df["location_std"] = 0.00
		base_data_df["location_weight"] = 0.00
	return base_data_df

def main(base_data_df):
	log.debug(len(base_data_df))
	try:
		df_location = base_data_df
		if (len(df_location) > 0):
			bool_location_file_avilable = True
		else:
			bool_location_file_avilable = False
	except:
		#traceback.print_exc()
		log.info("Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		#print ("Data not available for the location %s in the time range %s %s" %(sys.argv[1],sys.argv[2],sys.argv[3]))
		sys.exit()
	
	if (bool_location_file_avilable == True):

		df_location=df_location.groupby(["date","time","location_id","location_name"])["poured","sold"].sum()
		df_location=df_location.reset_index(drop=False)

		mean=df_location["poured"].mean()
		#print("Mean=",mean)
		stdev=df_location["poured"].std()
		#print("Standard Deviation",stdev)
		
		start_date_df=df_location.sort_values(by='date', ascending=False)
		start_date_df=start_date_df.reset_index()
		#print("End date =",start_date_df.loc[0,"date"])
		end_date_df=df_location.sort_values(by='date', ascending=True)
		end_date_df=end_date_df.reset_index()
		#print("Start date =",end_date_df.loc[0,"date"])

		#print("No. Of data points",len(df_location["poured"]))

		df_location=find_std_dev_diff(df_location,mean,stdev)

		#print(df_location["stdev_tot"])
		df_location=df_location.sort_values(by="stdev_diff", ascending=False)
		df_location=df_location.reset_index(drop=True)

		avg=stdev
		#print("average standard deviation difference=",avg)
		#print("average",avg)
		for i in range(0,len(df_location)):
			df_location=check_std_dev_diff(df_location,i,avg)

			# if i>0:
			# 	break

		df_location=df_location.sort_values(by=["date","time"])
		df_location=df_location.reset_index(drop=True)
		#print(df_location)
		for data_point in range(0,len(df_location)):
			df_location=check_neighbourhood(df_location,data_point)

		#print(MAX)
		#df_location=df_location.sort_values(by='weight', ascending=False)
		#df_location=df_location.reset_index(drop=True)

		#df_location["confidence"]=(df_location["weight"]/MAX)*100
		#df_location=df_location.rename(columns={'location_id':'loc_id','location_name':'loc_name'})

		#df_location=df_location.drop(["id"],axis=1)
		#df_location=df_location.reset_index(drop=True,col_level=1, col_fill='confidence')
		#print(df_location)
		#linecleaning_locaiton_df=display_result(df_location)
		#log.debug(df_location)
		return compare_with_loc(base_data_df,df_location)
		


def get_linecleaning_location(base_data_df):
	line_cleaning_location_df = main(base_data_df);
	line_cleaning_location_df=line_cleaning_location_df.rename(columns={'location_std':'loc_f','location_weight':'loc_w'})
	return line_cleaning_location_df



#----------- Importing Required Libraries ----------
import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
from new_api_data_insert_to_mysql import raw_data_download 
from call_all_locations import call_all_location as call_all
sys.path.append('./../misc/data_wrangling/')
#----------- Database Credentials and required Tables to deal with ----------
from normalized_poured_sold_optimized_updated import main as normalized_poured_sold_main
# from save_linecleaning_result import save_line_cleaning_result_main
from api_to_locationDB import write_data_to_loation_table as write_data_main
from constants import *
from check_and_remove_duplicates import check_and_remove_duplicates_in_poured_sold,check_duplicates_in_norm_poured_sold

#-----------Checking Database available or not  ----------         
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
		
#-----------Checking table available or not  ----------         
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------         
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal

#-----------Checking connection established or not  ----------             
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)


#-----------Validating date format  ----------         
def validate(date_text):
    try:
        datetime.strptime(date_text, '%Y-%m-%d')
        return True
    except Exception as e:
        return False

#-----------Validating date range----------         
def validate_drange(sdate,edate):
    try:
    	if((int(t.mktime(datetime.strptime(str(sdate), "%Y-%m-%d").timetuple())) * 1000<int(t.mktime(datetime.strptime(str(edate), "%Y-%m-%d").timetuple()))* 1000)):
    		return True
    	else:
    		return False
        # datetime.strptime(date_text, '%Y-%m-%d')
        # return True
    except Exception as e:
        return False

#-----------Validating input is integer or not----------         
def int_validate(dt):
	try:
		int(dt)
		return True
	except Exception as e:
		return False

#-----------Getting location data based on location_id (i.e, user_name,User_id,location_name)----------         
def get_location_details(location):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		hadoop_cursor.execute("SELECT * FROM beerboardLocalDb.user_loc_name_id where location_id="+str(location)+";")
		locatons_details = hadoop_cursor.fetchall()
# 		print(locatons_details)
		return locatons_details


#-----------Inserting data to table ----------         
def insert_data_toDB(connection_hadoop_internal,date,json_res,exceflag):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date,exceflag) VALUES ('"+str(json_res['user_id'])+"','"+str(json_res['user_name'])+"','"+str(json_res['location_id'])+"','"+str(json_res['location_name'])+"',0,0,'"+str('0')+"','"+ date +"',"+exceflag+")"
		hadoop_cursor.execute(sql)
	connection_hadoop_internal.commit()



#-----------Establishing Connection to MySQL Server ----------         
connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)

#-----------Gettting distinct location_id and date from location table----------         
loations_date_table=""
with connection_hadoop_internal.cursor() as hadoop_cursor_:
	hadoop_cursor_.execute("select location_id,date from "+LOCATION_DATE_TABLE+" ;")
	distinct_locatons = hadoop_cursor_.fetchall()
	if(len(distinct_locatons) > 0):
		loations_date_table=pd.DataFrame(distinct_locatons)


#-----------Update / new records insertion to location table basev4_LineCleaningResultsd on request date----------         		
def get_data_for_location_table():
	if(len(sys.argv)==4):
		try:
			# print(validate(sys.argv[1]) and validate(sys.argv[2]) and validate_drange(sys.argv[1],sys.argv[2]) and int_validate(str(sys.argv[2])))
			if(validate(sys.argv[1]) and validate(sys.argv[2]) and validate_drange(sys.argv[1],sys.argv[2]) and int_validate(str(sys.argv[3]))):
				# print(list(loations_date_table.loc[loations_date_table['location_id']==int(json_res['location_id'])]['date']))
				diffdate=int(str(datetime.strptime(sys.argv[2], '%Y-%m-%d')-datetime.strptime(sys.argv[1], '%Y-%m-%d')).split(" ")[0])
				# print(diffdate)
				ReportedDate=datetime.strptime(str(sys.argv[1]), '%Y-%m-%d')
				json_res=json.loads(json.dumps(get_location_details(str(sys.argv[3]))))[0]
				for x in range(NUMBER_OF_DAYS_TO_RUN_THE_ALGO) :
					ReportedDate_formate=str(str(ReportedDate).split(" ")[0])
					print(ReportedDate_formate)
					print(json_res)
					if(ReportedDate_formate not in list(loations_date_table.loc[loations_date_table['location_id']==int(json_res['location_id'])]['date'])):
						print(str(str(ReportedDate).split(" ")[0]),str(json_res['location_id']))
						if(str(sys.argv[1])==str(ReportedDate_formate)):
							insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res,1)
						else:
							insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res,0)
						# insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res)
						# insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),int(sys.argv[3]))
					ReportedDate=ReportedDate-timedelta(days=1)
				# diffdate=datetime.strptime(sys.argv[2], '%Y-%m-%d')-datetime.strptime(sys.argv[1], '%Y-%m-%d')
				ReportedDate=datetime.strptime(str(sys.argv[1]), '%Y-%m-%d')
				# print(diffdate)
				for x in range(diffdate) :
					ReportedDate_formate=str(str(ReportedDate).split(" ")[0])
					print(ReportedDate_formate)
					if(ReportedDate_formate not in list(loations_date_table.loc[loations_date_table['location_id']==int(json_res['location_id'])]['date'])):
						print(str(str(ReportedDate).split(" ")[0]),str(json_res['location_id']))
						if(str(sys.argv[1])==str(ReportedDate_formate)):
							insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res,1)
						else:
							insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res,0)
						# insert_data_toDB(connection_hadoop_internal,str(ReportedDate_formate),json_res)
						# insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),int(sys.argv[3]))
					ReportedDate=ReportedDate-timedelta(days=-1)
				return True
			else:
				print("Location should be integer")
			if(validate_drange(sys.argv[1],sys.argv[2])):
				return True
				pass
			else:
				print("Start date should be befor end date")
				return False

					
		except Exception as e:
			print(e)
			return False
	elif(len(sys.argv)==3):
		try:
			if(validate(sys.argv[1]) and validate(sys.argv[2]) and validate_drange(sys.argv[1],sys.argv[2])):
				diffdate=int(str(datetime.strptime(sys.argv[2], '%Y-%m-%d')-datetime.strptime(sys.argv[1], '%Y-%m-%d')).split(" ")[0])
				ReportedDate=datetime.strptime(str(sys.argv[2]), '%Y-%m-%d')
				for x in range(diffdate):
					ReportedDate_formate=str(str(ReportedDate).split(" ")[0])
					write_data_main(connection_hadoop_internal,str(ReportedDate_formate))
					ReportedDate=ReportedDate-timedelta(days=-1)
					# write_data_main(connection_hadoop_internal,str(str(datetime.strptime(str(sys.argv[1]), '%Y-%m-%d')).split(" ")[0]))
				return True

			elif(validate(sys.argv[1]) and int_validate(str(sys.argv[2]))):
				ReportedDate=datetime.strptime(str(sys.argv[1]), '%Y-%m-%d')
				json_res=json.loads(json.dumps(get_location_details(str(sys.argv[2]))))[0]
				print(list(loations_date_table.loc[loations_date_table['location_id']==int(json_res['location_id'])]['date']))
				if(len(json_res)>0):
					for x in range(NUMBER_OF_DAYS_TO_RUN_THE_ALGO) :
						ReportedDate_formate=str(str(ReportedDate).split(" ")[0])
						if(ReportedDate_formate not in list(loations_date_table.loc[loations_date_table['location_id']==int(json_res['location_id'])]['date'])):
							if(str(sys.argv[1])==str(ReportedDate_formate)):
								insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res,1)
							else:
								insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res,0)
							# insert_data_toDB(connection_hadoop_internal,str(str(ReportedDate).split(" ")[0]),json_res)
						ReportedDate=ReportedDate-timedelta(days=1)
				return True
			else:
				print("Date format is wromg / End date should be greater than Start date")			
				return False
		except Exception as e:
			print("loation is not in integer format",e)
			return False
	elif(len(sys.argv)==2):
		# print(list(loations_date_table.loc[loations_date_table['location_id']==int(json_res['location_id'])]['date']))
		if(validate(sys.argv[1])):
			write_data_main(connection_hadoop_internal,str(sys.argv[1]))
			return True
		else:
			print("Incorrect date format, USE : YYYY-MM-DD" )
			return False
	else:
		print("Options : ")
		print("YYYY-MM-DD YYYY-MM-DD LOCATION_ID	:  Run linecleaning algorithm for given duration and for given location ")
		print("YYYY-MM-DD YYYY-MM-DD			:  Run linecleaning algorithm for given duration ")
		print("YYYY-MM-DD LOCATION_ID			:  Run linecleaning algorithm for given date and for given location ")
		print("YYYY-MM-DD				:  Run linecleaning algorithm for given date based on exception table ")
		return False


try:
	if(get_data_for_location_table()):
		raw_data_download()
		message = check_and_remove_duplicates_in_poured_sold()
		if (message == "Success"):
			normalized_poured_sold_main()
			message_norm_pord_sold = check_duplicates_in_norm_poured_sold()
			if (message_norm_pord_sold == "Success"):	
				s_date=""
				e_date=""
				if(len(sys.argv)==4):
					pass
					# print (str(sys.argv[1]),str(sys.argv[2]),int(sys.argv[3]))
					# save_line_cleaning_result_main()
				elif(len(sys.argv)==3):
					pass
					# if(validate(sys.argv[1]) and validate(sys.argv[2]) and validate_drange(sys.argv[1],sys.argv[2])):
					# 	save_line_cleaning_result_main()
					# elif(validate(sys.argv[1]) and int_validate(str(sys.argv[2]))):
					# 	save_line_cleaning_result_main()
				elif(len(sys.argv)==2):
					call_all(sys.argv[1])													
					# print(sys.argv)
					# save_line_cleaning_result_main(sys.argv[1])




except Exception as e:
	log.error(e)

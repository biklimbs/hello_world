"""
Title: Ideal loss feature

Description: Computes Ideal loss at the product level. 
Algorithm: 1. Compute the smartbar loss by getting the diffrence between poured and sold and adding the ideal loss(i.e 10 % of sold on that day) 
 		   			
 		   2. Compare with base dataframe and assign the weight according to the linecleaning at product level by comparing the date and product.
"""


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time, timedelta
from termcolor import colored
import os, inspect
from logger_config import log
from constants import *

#NORMALIZATION_TABLE = '68_normalizedPouredSold'
#RAW_TABLE=LINE_CLEANING_TABLE# '68_nagitive_variance'

START_TIME=" 06:00:00"
END_TIME=" 06:00:00"
SOLD_MAGIC_NUM=10
POSITIVE_LOSS_MAGIC_NUM= 1000
#POURED_THRESHOLD= 5




# def compare_ideal_loss(df_linecleaning_local,df_ideal_loss_local):
# 	#log.debug("In ideal loss module")
# 	#log.info("Checking the ideal loss and total loss of whole day")
# 	#print("ideal loss df")
# 	#print(df_ideal_loss_local)
# 	#print(df_linecleaning_local)
# 	for row in range(0,len(df_linecleaning_local)):
# 		for line in range(0,len(df_ideal_loss_local)):
# 			#print(df_ideal_loss_local.loc[line,"prod_id"])
# 			#print(df_linecleaning_local.loc[row,"date"], df_ideal_loss_local.loc[line,"date"], df_linecleaning_local.loc[row,"prod_id"], df_ideal_loss_local.loc[line,"prod_id"])
# 			if (str(df_linecleaning_local.loc[row,"date"])==str(df_ideal_loss_local.loc[line,"date"])) and (df_linecleaning_local.loc[row,"prod_id"]==df_ideal_loss_local.loc[line,"prod_id"]):# and df_linecleaning_local.loc[row,"loc_feat"]==0:
# 				#print(df_linecleaning_local.loc[row,"date"], df_ideal_loss_local.loc[line,"date"], df_linecleaning_local.loc[row,"prod_id"], df_ideal_loss_local.loc[line,"prod_id"])
# 				#print(round(abs(df_ideal_loss_local.loc[line,"sb_loss"]),2),df_ideal_loss_local.loc[line,"ideal_loss"])
# 				if df_ideal_loss_local.loc[line,"sb_loss"]>0:
# 					#df_linecleaning_local.loc[row,"weight"]-= W_IDEAL_LOSS_COMPARE
# 					df_linecleaning_local.loc[row,"ideal_f"]=0
# 					break
# 				elif (abs(df_ideal_loss_local.loc[line,"sb_loss"])-df_ideal_loss_local.loc[line,"ideal_loss"])<=IDEAL_CONFIDENCE_LOSS:
# 					df_linecleaning_local.loc[row,"ideal_f"]=(abs(df_ideal_loss_local.loc[line,"sb_loss"])/IDEAL_CONFIDENCE_LOSS)*IDEAL_CONFIDENCE_LOSS
# 					break

# 				else:
# 					df_linecleaning_local.loc[row,"ideal_f"]=100
# 					# df_linecleaning_local.loc[row,"sb_loss"] = df_ideal_loss_local.loc[line,"sb_loss"]
# 					# df_linecleaning_local.loc[row,"loc_loss"] = df_ideal_loss_local.loc[line,"loc_loss"]
# 					break
# 			else:
# 				df_linecleaning_local.loc[row,"ideal_f"]=100
# 	#print(df_linecleaning_local)
# 	return df_linecleaning_local

# def compare_ideal_loss(df_linecleaning_local,df_ideal_loss_local):
# 	#log.debug("In ideal loss module")
# 	#log.info("Checking the ideal loss and total loss of whole day")
# 	#print(df_ideal_loss_local)
# 	#print(df_linecleaning_local)
# 	for row in range(0,len(df_linecleaning_local)):

# 		# print(row, df_linecleaning_local.loc[row,"date"],df_linecleaning_local.loc[row,"prod_id"])

# 		ideal_temp= df_ideal_loss_local.loc[(df_ideal_loss_local['date'] == df_linecleaning_local.loc[row,"date"]) & (df_ideal_loss_local['prod_id'] == df_linecleaning_local.loc[row,"prod_id"]), ['sb_loss','ideal_loss','loc_loss']]
# 		# print(ideal_temp)
# 		# print(ideal_temp["sb_loss"].values[0],ideal_temp["ideal_loss"].values[0])
# 		if ideal_temp.empty:
# 			pass
# 		else:
# 			if (ideal_temp["sb_loss"].values[0])>0:
# 				#df_linecleaning_local.loc[row,"weight"]-= W_IDEAL_LOSS_COMPARE
# 				df_linecleaning_local.loc[row,"ideal_f"]=0
				
# 			elif (abs( ideal_temp["sb_loss"].values[0])-ideal_temp["ideal_loss"].values[0])<=IDEAL_CONFIDENCE_LOSS:
# 				df_linecleaning_local.loc[row,"ideal_f"]=((abs( ideal_temp["sb_loss"].values[0])-ideal_temp["ideal_loss"].values[0])/IDEAL_CONFIDENCE_LOSS)*IDEAL_CONFIDENCE_LOSS
				

# 			else:
# 				df_linecleaning_local.loc[row,"ideal_f"]=100
# 				# df_linecleaning_local.loc[row,"sb_loss"] = df_ideal_loss_local.loc[line,"sb_loss"]
# 				# df_linecleaning_local.loc[row,"loc_loss"] = df_ideal_loss_local.loc[line,"loc_loss"]
			
		
# 	#print(df_linecleaning_local)
# 	return df_linecleaning_local

def compare_ideal_loss(base_data_df,df_ideal_loss_local):
	try:
		# print(df_ideal_loss_local)
		if(len(df_ideal_loss_local)>0):
			base_data_df=base_data_df.reset_index(drop=True)
			for line in range(0,len(df_ideal_loss_local)):
				if (df_ideal_loss_local.loc[line,"sb_loss"])>0:
					#df_linecleaning_local.loc[row,"weight"]-= W_IDEAL_LOSS_COMPARE

					base_data_df.loc[(base_data_df['date'] == df_ideal_loss_local.loc[line,"date"]) & (base_data_df['prod_id'] == df_ideal_loss_local.loc[line,"prod_id"]) & (base_data_df['loc_f'] == 0),["ideal_f","sb_loss","loc_loss"]]=W_IDEAL_LOSS,df_ideal_loss_local.loc[line,"sb_loss"],df_ideal_loss_local.loc[line,"loc_loss"]
					base_data_df.loc[(base_data_df['date'] == df_ideal_loss_local.loc[line,"date"]) & (base_data_df['prod_id'] == df_ideal_loss_local.loc[line,"prod_id"]) & (base_data_df['loc_f'] == 1),["sb_loss","loc_loss"]]=df_ideal_loss_local.loc[line,"sb_loss"],df_ideal_loss_local.loc[line,"loc_loss"]

					base_data_df.loc[(base_data_df['date'] == df_ideal_loss_local.loc[line,"date"]) & (base_data_df['prod_id'] == df_ideal_loss_local.loc[line,"prod_id"]) & (base_data_df['loc_f'] == 0),"weight"]-=W_IDEAL_LOSS
					
				elif (abs( df_ideal_loss_local.loc[line,"sb_loss"])-df_ideal_loss_local.loc[line,"ideal_loss"])<=IDEAL_CONFIDENCE_LOSS:
					# df_linecleaning_local.loc[row,"ideal_f"]=((abs( ideal_temp["sb_loss"].values[0])-ideal_temp["ideal_loss"].values[0])/IDEAL_CONFIDENCE_LOSS)*IDEAL_CONFIDENCE_LOSS
					# print("ideal loss....")
					base_data_df.loc[(base_data_df['date'] == df_ideal_loss_local.loc[line,"date"]) & (base_data_df['prod_id'] == df_ideal_loss_local.loc[line,"prod_id"])  & (base_data_df['loc_f'] == 0),["ideal_f","sb_loss","loc_loss"]]=W_IDEAL_LOSS,df_ideal_loss_local.loc[line,"sb_loss"],df_ideal_loss_local.loc[line,"loc_loss"]
					base_data_df.loc[(base_data_df['date'] == df_ideal_loss_local.loc[line,"date"]) & (base_data_df['prod_id'] == df_ideal_loss_local.loc[line,"prod_id"])  & (base_data_df['loc_f'] == 1),["sb_loss","loc_loss"]]=df_ideal_loss_local.loc[line,"sb_loss"],df_ideal_loss_local.loc[line,"loc_loss"]

					base_data_df.loc[(base_data_df['date'] == df_ideal_loss_local.loc[line,"date"]) & (base_data_df['prod_id'] == df_ideal_loss_local.loc[line,"prod_id"]) & (base_data_df['loc_f'] == 0),"weight"]-=W_IDEAL_LOSS

				else:
					base_data_df.loc[(base_data_df['date'] == df_ideal_loss_local.loc[line,"date"]) & (base_data_df['prod_id'] == df_ideal_loss_local.loc[line,"prod_id"]),["sb_loss","loc_loss"]]=df_ideal_loss_local.loc[line,"sb_loss"],df_ideal_loss_local.loc[line,"loc_loss"]
					pass
					# df_linecleaning_local.loc[row,"sb_loss"] = df_ideal_loss_local.loc[line,"sb_loss"]
					# df_linecleaning_local.loc[row,"loc_loss"] =

				# # print(base_data_df.loc[(base_data_df['date'] == df_location_feature.loc[line,"date"]) & (base_data_df['time'] == df_location_feature.loc[line,"time"]),"loc_f"])
				# base_data_df.loc[(base_data_df['date'] == df_location_feature.loc[line,"date"]) & (base_data_df['time'] == df_location_feature.loc[line,"time"]),"ideal_f"]=W_IDEAL_LOSS
				# base_data_df.loc[(base_data_df['date'] == df_location_feature.loc[line,"date"]) & (base_data_df['time'] == df_location_feature.loc[line,"time"]),"weight"]-=W_IDEAL_LOSS

		return base_data_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)

def split_date(df_summation):
	# for i in range(0,len(df_summation["date"])):
	# 		df_summation.loc[i,"date"],df_summation.loc[i,"time"]=str(df_summation.loc[i,"date"]).split(" ")
	# print(type(df_summation['date']))
	df_summation['date']=df_summation['date'].apply(str)
	df_summation['date'], df_summation['time'] = df_summation['date'].str.split(' ').str
	# print(df_summation.head())
	# sys.exit()
	return df_summation

def get_summation(df_location,df_summation,new_date,end_date):
	#print("IN summation")
	#print(type(df_location['date']))
	#print(df_location['date'])
	# for index in range(len(df_location['date'])):
	# 	df_location.loc[index,'date']=datetime.strptime(df_location.loc[index,'date'], '%Y-%m-%d %H:%M')
	df_location["date"]=pd.to_datetime(df_location["date"])
	i=0
	while new_date<=end_date:
		datetime_temp = (new_date + timedelta(hours=24))
		df_location_local=df_location[(df_location['date'] > new_date) & (df_location['date'] <= datetime_temp)]
		#print(df_location_local)
		#print(df_summation)
		if df_location_local.empty:
			pass
		else:
			df_location_local=df_location_local.reset_index(drop=True)
			prod_uniq=df_location_local["product_id"].unique()
			#print("prod-uniq==",prod_uniq)
			differ_sum = 0
			for prod in prod_uniq:
				df_location_local1=df_location_local[df_location_local["product_id"]==prod]
				df_location_local1=df_location_local1.reset_index(drop=True)
				#print("code in get summation")
				poured_sum= df_location_local1["poured"].sum()
				sold_sum= df_location_local1["sold"].sum()
				loss_perc=(sold_sum*SOLD_MAGIC_NUM)/100

				differ= sold_sum- poured_sum
				if poured_sum==0:
					variance=100
				else:
					variance= (differ/poured_sum)*100
				df_summation.loc[i,"date"]=new_date
				#print(df_location_local1)
				no_of_sold= df_location_local1["sold"].count()

				# count_diff= count_poured - count_sold
				
				#print(no_of_sold)
				#print(df_location_local1)
				df_summation.loc[i,"location_id"]= df_location_local1.loc[0,"location_id"]
				df_summation.loc[i,"location_name"]= df_location_local1.loc[0,"location_name"]
				df_summation.loc[i,"product_id"]= df_location_local1.loc[0,"product_id"]
				df_summation.loc[i,"product_name"]= df_location_local1 .loc[0,"product_name"]
				#df_summation.loc[i,"no_of_sold"]=no_of_sold
				# df_summation.loc[i,"count_diff"]= count_diff
				df_summation.loc[i,"poured"]= poured_sum
				df_summation.loc[i,"sold"]= sold_sum
				df_summation.loc[i,"sb_loss"]= differ
				#df_summation.loc[i,"%\loss"]=round(variance,2)
				df_summation.loc[i,"ideal_loss"]= loss_perc

				differ_sum = differ_sum + differ
				i+=1

			df_summation.loc[df_summation['date']==new_date,'loc_loss'] = differ_sum
			#print (df_summation)
					#print(df_summation)
		new_date=datetime_temp
	#print(df_summation)
	df_summation= df_summation.loc[(df_summation["poured"]!=0)]# & (df_summation["sold"]!=0)]
	df_summation= df_summation.reset_index(drop=True)
	#print(df_summation)
	return df_summation

# def split_quantity(df_location):
# 	for i in range(0,len(df_location["poured"])): 
# 		df_location.loc[i,"date"]=datetime.strptime(df_location.loc[i,"date"], '%Y-%m-%d %H:%M')
# 		if df_location.loc[i,"poured"]=="0":
# 			df_location.loc[i,"poured"]=float(df_location.loc[i,"poured"])
# 		else:
# 			df_location.loc[i,"poured"],df_location.loc[i,"waste"]=df_location.loc[i,"poured"].split(" ")
			
# 			df_location.loc[i,"poured"]=float(df_location.loc[i,"poured"])

# 		if df_location.loc[i,"sold"]=="0":
# 			df_location.loc[i,"sold"]=float(df_location.loc[i,"sold"])
# 		else:
# 			df_location.loc[i,"sold"],df_location.loc[i,"waste"]=df_location.loc[i,"sold"].split(" ")
		
# 			df_location.loc[i,"sold"]=float(df_location.loc[i,"sold"])
# 	print(df_location.head())
# 	sys.exit()
# 	return df_location

def split_quantity(df_location):
	df_location['poured'], df_location['waste'] = df_location['poured'].str.split(' ', 1).str
	df_location['sold'], df_location['waste'] = df_location['sold'].str.split(' ', 1).str
	df_location['poured']=pd.to_numeric(df_location['poured'], errors='coerce')
	df_location['sold']=pd.to_numeric(df_location['sold'], errors='coerce')
	# print(df_location.head())
	# sys.exit()
	return df_location

# In raw table we have to give 1 extra day to get the data
def update_end_date(to_date):
	to_date_temp= ""+str(to_date)+" 00:00:00"
	to_date_temp=datetime.strptime(to_date_temp, '%Y-%m-%d %H:%M:%S')
	to_date_temp= (to_date_temp + timedelta(hours=24))
	to_date_temp= str(to_date_temp)
	to_date,to_date_temp=to_date_temp.split(" ")
	return to_date

def compute_ideal_loss(base_data_df,raw_data_df,start_date_sys,end_date_sys):
	#print("In ideal loss calc")
	#print("Analysing Ideal loss for "+sys.argv[1]+"")
	#log.info("Analysing Ideal loss for "+sys.argv[1]+"")
	pd.set_option('expand_frame_repr', False)
	pd.set_option('display.max_colwidth', -1)
	pd.options.display.max_rows= 999
	
	#print(sys.argv[1],sys.argv[2],sys.argv[3])
	to_date= sys.argv[3]												###
	from_date= sys.argv[2]												### To calculate ideal loss for 1 day we need sys args 
	# to_date= end_date_sys												###  To calculate ideal loss for 7 days we need this
	# from_date= start_date_sys											###
	to_date= update_end_date(to_date)
	#print(to_date)
	df_location= raw_data_df
	# print(type(df_location["date"]))
	df_location=split_quantity(df_location)
	#df_location["date"]=datetime.strptime(df_location["date"], '%Y-%m-%d %H:%M:%S')
	df_location=df_location[["date","location_id","location_name","product_id","product_name","poured","sold"]]
	df_location=df_location.sort_values(by="date")
	df_location=df_location.reset_index(drop=True)
	column=["date","location_id","location_name","product_id","product_name","poured","sold","sb_loss","ideal_loss"]#,"optimized"]
	df_summation=pd.DataFrame(columns=column)
	new_date=from_date+START_TIME
	end_date=to_date+END_TIME
	end_date= datetime.strptime(end_date, '%Y-%m-%d %H:%M:%S')
	#print(datetime.strptime(new_date, '%Y-%m-%d %H:%M:%S').timestamp())
	new_date=datetime.strptime(new_date, '%Y-%m-%d %H:%M:%S')
	# print(new_date)
	#end_date= (end_date + timedelta(hours=24))
	# print(end_date)
	df_summation= get_summation(df_location,df_summation,new_date,end_date)

	#print(df_summation)
	# for row in range(0,len(df_summation)):
	# 	df_summation.loc[row,"date"]=t.strftime('%Y-%m-%d %H:%M:%S', t.localtime(df_summation.loc[row,"date"]))
	if df_summation.empty:
		pass
	else:
		df_summation=split_date(df_summation)
		#temp_df= df_summation.sort_values(by="sb_loss")
		#print(temp_df)
		#df_summation= df_summation[df_summation["sb_loss"]<POSITIVE_LOSS_MAGIC_NUM]
		df_summation= df_summation.drop(["time"],axis=1)
		#average_perc_loss=df_summation["%\loss"].mean()
		#print(average_perc_loss)
		df_summation=df_summation.sort_values(by="date", ascending=True)
		df_summation= df_summation.reset_index(drop=True)
		df_summation= df_summation.rename(columns={'location_id':'loc_id','location_name':'loc_name','product_id':'prod_id','product_name':'prod_name'})

	#print(df_summation)

	return df_summation

def ideal_loss_main(base_data_df,raw_data_df,start_date_sys,end_date_sys):
	# print(raw_data_df)
	# print("HIIII")
	df_summation= compute_ideal_loss(base_data_df,raw_data_df,start_date_sys,end_date_sys)
	# print(df_summation)
	#df_summation.to_csv('./'+str(sys.argv[1])+'_il_dump.csv',index = False)
	base_data_df["ideal_f"]=0														###default..
	base_data_df["sb_loss"]=0
	base_data_df["loc_loss"]=0
	base_data_df, resp= compare_ideal_loss(base_data_df,df_summation)

	return base_data_df, resp


def get_ideal_loss(base_data_df,raw_data_df,start_date_sys,end_date_sys):
	base_data_df,resp=ideal_loss_main(base_data_df,raw_data_df,start_date_sys,end_date_sys)
	return base_data_df,resp
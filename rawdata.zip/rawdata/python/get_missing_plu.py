'''
Title: Missing PLU
Auther: Muzzamil


'''

import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import traceback
import pandas as pd
from termcolor import colored
import datetime
from datetime import datetime, timedelta
import time
import json

from constants import *
from logger_config import log


# MY_SQL_HOST_NAME = cs.MY_SQL_HOST_NAME
# MY_SQL_USER_NAME = cs.MY_SQL_USER_NAME
# MY_SQL_PASSWORD = cs.MY_SQL_PASSWORD
# MY_SQL_DB_NAME = cs.MY_SQL_DB_NAME
# LINE_CLEANING_PLU_TABLE = cs.LINE_CLEANING_PLU_TABLE
# LINE_CLEANING_TABLE = cs.LINE_CLEANING_TABLE

# W_PRODUCT_PLU = cs.PLU_MISSING_WEIGHT

def get_poured_sold_data(raw_data_df,plu_data_df):
	
	poured_product_df = pd.DataFrame()
	sold_producet_df = pd.DataFrame()
	plu_product_df = pd.DataFrame()
	try:
		poured_product_df = raw_data_df[raw_data_df['poured'] != '0']
		poured_product_df = poured_product_df[['product_id','product_name','date']]
		sold_producet_df = raw_data_df[raw_data_df['sold'] != '0']
		sold_producet_df = sold_producet_df[['product_id','product_name','date']]
		plu_product_df = plu_data_df[['product_id','date']]
	except Exception as e:
		log.error(e)

	return poured_product_df , sold_producet_df, plu_product_df

def get_missing_products(poured_product_id_df,sold_product_id_df):

	missing_porduces_df = poured_product_id_df[~poured_product_id_df.product_id.isin(sold_product_id_df.product_id)]
	return missing_porduces_df

def cross_check_missing_plu(missing_porducts_df, location_id,date_,plu_df_date):
	try:
		really_missing_list = []
		if(len(plu_df_date)>0):
			
			missing_porducts_df_values = missing_porducts_df[~missing_porducts_df.product_id.isin(plu_df_date.product_id)]
			for index, row in missing_porducts_df_values.iterrows():
				missing_dic_value = {}
				missing_dic_value['product_id'] = row['product_id']
				missing_dic_value['product_name'] = row['product_name']
				really_missing_list.append(missing_dic_value)
			return really_missing_list
		else:
			return really_missing_list

	except Exception as e:
		log.error(e)

def increment_date(date):
	date = datetime.strptime(date, "%Y-%m-%d")
	modified_date = date + timedelta(days=1)
	date = datetime.strftime(modified_date, "%Y-%m-%d")
	return date

def decrement_date(date):
	date = datetime.strptime(date, "%Y-%m-%d")
	modified_date = date - timedelta(days=1)
	date = datetime.strftime(modified_date, "%Y-%m-%d")
	return date

def convert_missing_plu_data_into_proper_formath(missing_products_from_plu):
	missing_products_plu_df =  pd.DataFrame (missing_products_from_plu)
	missing_list = []
	for i, r in missing_products_plu_df.iterrows():
		missing_dic = {}
		missing_dic['product_id']=r['product_id']
		missing_dic['product_name']=r['product_name']
		missing_list.append(missing_dic)
	return missing_list

def display_missing_progucts(location_id,date,list_products):
	log.debug("Plu's missing for the location "+location_id+" on "+date)
	for r in list_products:
		log.debug (r)
	log.debug ("")


# checking for missing plu
# if any product is not having plu then decreasing the weight accordingly
def check_for_missing_plu(json_missing_plu,date,product_id):
	product_present = False
	if (json_missing_plu['Success'] == "TRUE"):
		json_data_list = json_missing_plu['data']
		for dic in json_data_list: 
			if dic['Date'].strip() == str(date):
				if len(dic['missing_plu'])>0:
					for product_dic in dic['missing_plu']:
						if (product_dic['product_id'] == product_id):
							product_present = True
							break
				break

	return product_present

def missing_plu_process(base_data_df,plu_json):
	if len(base_data_df) != 0:
		for index, data_prod_value in base_data_df.iterrows():
			is_product_plu_missing = check_for_missing_plu(plu_json,data_prod_value['date'],data_prod_value['prod_id'])
			if(is_product_plu_missing == True):
				base_data_df.loc[index,'weight'] = float(base_data_df.loc[index,'weight']) - MISSING_PLU_WEIGHT
				base_data_df.loc[index,'missing_plu_weight'] = MISSING_PLU_WEIGHT
			else:
				base_data_df.loc[index,'missing_plu_weight'] = 0.0
	return base_data_df
			
def get_start_end_date (raw_data_df):
	start_date = min(raw_data_df['date'])
	end_date = max(raw_data_df['date'])
	location_id_sys = raw_data_df.location_id.unique()
	return start_date,end_date,location_id_sys[0]


def main_body(raw_data_df,plu_data_df,base_data_df):
	script_start_time = time.time()
	poured_product_id_list = []
	sold_producet_id_list = []
	start_date_sys,end_date_sys,location_id_sys = get_start_end_date(raw_data_df)
	location_id_sys = str(location_id_sys)
	end_date_sys = increment_date(end_date_sys)
	main_dic = {}
	main_dic['Success'] = 'TRUE'
	date_list = []

	poured_product_id_df , sold_producet_id_df, plu_df = get_poured_sold_data(raw_data_df,plu_data_df)

	while (start_date_sys != end_date_sys):	
		try:
			date_dic = {}
			date_dic['Date']=start_date_sys
			poured_product_id_list = []
			sold_producet_id_list = []
			if(len(poured_product_id_df)>0):
				poured_product_id_df_date = poured_product_id_df.loc[poured_product_id_df['date'].str.contains(start_date_sys)]
				poured_product_id_df_date = poured_product_id_df_date.drop('date', 1)
				poured_product_id_df_date = poured_product_id_df_date.drop_duplicates(keep='first')
				#poured_product_id_list = poured_product_id_df_date.T.to_dict().values()
			else:
				poured_product_id_df_date = pd.DataFrame()

			if(len(sold_producet_id_df)>0):
				sold_producet_id_df_date = sold_producet_id_df.loc[sold_producet_id_df['date'].str.contains(start_date_sys)]
				sold_producet_id_df_date = sold_producet_id_df_date.drop('date', 1)
				sold_producet_id_df_date = sold_producet_id_df_date.drop_duplicates(keep='first')
			else:
				poured_product_id_df_date = pd.DataFrame()

			if(len(plu_df)>0):
				plu_df_date = plu_df.loc[plu_df['date'].str.contains(start_date_sys)]
				plu_df_date = plu_df_date.drop('date', 1)
				plu_df_date = plu_df_date.drop_duplicates(keep='first')
			else:
				poured_product_id_df_date = pd.DataFrame()

			if(len(poured_product_id_df_date)>0 and len(sold_producet_id_df_date)== 0):
				missing_products_from_plu = cross_check_missing_plu(poured_product_id_df_date,location_id_sys,start_date_sys,plu_df_date)
				if(len(missing_products_from_plu)>0):
					log.debug("Missing plu's are pressent")
					display_missing_progucts(str(location_id_sys),start_date_sys,missing_products_from_plu)
					date_dic['message']="Missing plu's are pressent"
					date_dic['missing_plu']=convert_missing_plu_data_into_proper_formath(missing_products_from_plu)
				else:
					log.debug("No missing PLU for the location "+str(location_id_sys)+" on "+start_date_sys)
					date_dic['message']="No missing PLU"
					date_dic['missing_plu']=[]

			elif (len(poured_product_id_df_date)>0 and len(sold_producet_id_df_date)>0):
				missing_products_from_sold = get_missing_products(poured_product_id_df_date, sold_producet_id_df_date)
				if(len(missing_products_from_sold)>0):
					missing_products_from_plu = cross_check_missing_plu (missing_products_from_sold,location_id_sys,start_date_sys,plu_df_date)
					if(len(missing_products_from_plu)>0):
						log.debug("Missing plu's are pressent")
						display_missing_progucts(str(location_id_sys),start_date_sys,missing_products_from_plu)
						date_dic['message']="Missing plu's are pressent"
						date_dic['missing_plu']=convert_missing_plu_data_into_proper_formath(missing_products_from_plu)					
					else:
						log.debug("No missing PLU for the location "+str(location_id_sys)+" on "+start_date_sys)
						date_dic["message"]="No missing plu"
						date_dic['missing_plu']=[]
				else:
					log.debug("No missing PLU for the location "+str(location_id_sys)+" on "+start_date_sys)
					date_dic["message"]="No missing plu"
					date_dic['missing_plu']=[]
			else:
				log.debug("No data avilable for the location "+str(location_id_sys)+" on "+start_date_sys)
				date_dic["message"]="No data avilable"
				date_dic['missing_plu']=[]
			date_list.append(date_dic)
			start_date_sys = increment_date(start_date_sys)
		except Exception as e:
			log.error(e)

	main_dic['data']= date_list
	main_json = json.dumps(main_dic) 
	elapsed_time = time.time() - script_start_time
	elapsed_time = float("{0:.2f}".format(elapsed_time))
	base_data_df = missing_plu_process(base_data_df,json.loads(main_json))
	base_data_df=base_data_df.rename(columns={'missing_plu_weight':'m_plu_w'})
	return base_data_df, "Success"

def get_missing_plu_fun(raw_data_df,plu_data_df,base_data_df):
	return main_body(raw_data_df,plu_data_df,base_data_df)

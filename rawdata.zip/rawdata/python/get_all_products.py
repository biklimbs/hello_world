import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
from os import listdir
import csv
import pandas as pd
import datetime
from logger_config import log
import requests
import json
import time,datetime
import csv
import os.path


USER_API = "http://betaapi.beerboard.com/nodejsserver/getCustomers?beta=0&userId=1"
LOCATION_API = "http://betaapi.beerboard.com/nodejsserver/getLocation?beta=0&userId=1&customerId="
PRODUCT_API = "http://betaapi.beerboard.com/nodejsserver/getLocationProducts?beta=0&userId=1&locationId="
PRODUCT_API_2 = "&all=1&alphabet=miller"

FOLDER = './customer_product'

def api_call(url):
	response  = ""
	response_code = 0
	while (response == "" and response_code != 200):
		try:
			response = requests.get(url,timeout = 60)
			response_code = response.status_code
		except:
			log.error("API CALL TIME OUT. RETRYING ... ")
			time.sleep(300)
			#traceback.print_stack()
	return response

def get_customers_id(file_name,location_file_name):
	request = api_call(USER_API)
	data = request.json()
	customers_data = data['customers']
	customers_data_df = pd.DataFrame(customers_data)
	customers_data_df['flag'] = 0
	customers_data_df.to_csv(file_name,index=False)
	customers_data_df.reset_index()
	location_df = pd.DataFrame()
	location_df.to_csv(location_file_name)
	return customers_data_df

def get_merge_locations(location_df_1,location_df_2):
	location_df = pd.concat([location_df_1,location_df_2])
	return location_df

def get_merge_product(product_df_1,product_df_2):
	product_df = pd.concat([product_df_1,product_df_2])
	return product_df

def get_location_id(customer_file_name,location_file_name):
	customers_data_df = pd.read_csv(customer_file_name)
	location_df = pd.read_csv(location_file_name)
	compleated  = False
	try:
		for index,customers_id in customers_data_df.iterrows():
			log.info ("Customer length:"+str(len(customers_data_df))+ " Compleated: "+str(index) )
			if (customers_id['flag'] == 0):
				request_customer = api_call(LOCATION_API+str(customers_id['id']))
				request_location = request_customer.json()
				location_df_pd = pd.DataFrame(request_location['location'])
				location_df = get_merge_locations(location_df,location_df_pd)
				location_df['flag'] = 0
				customers_data_df.loc[customers_data_df['id'] == customers_id['id'],'flag'] = 1
				time.sleep(60)
			if (len(customers_data_df) == index+1):
				compleated = True
			customers_data_df.to_csv(customer_file_name,index=False)
			location_df.to_csv(location_file_name,index=False)
	except Exception as e :
		log.error(e)
	finally:
		customers_data_df.reset_index()
		location_df.reset_index()
		return customers_data_df,location_df,compleated

def get_product_id(location_folder_name,product_folder_name):
	location_df = pd.read_csv(location_folder_name)
	product_df = pd.read_csv(product_folder_name)
	product_compleated  = False
	try:
		for index, location_id in location_df.iterrows():
			log.info ("Location length:"+str(len(location_df))+ " Compleated: "+str(index) )
			if (location_id['flag']==0):
				request_product = api_call(PRODUCT_API+str(location_id['locationId'])+PRODUCT_API_2)
				request_product = request_product.json()
				product_df_pd = pd.DataFrame(request_product['products'])
				product_df = get_merge_product(product_df,product_df_pd)
				location_df.loc[location_df['locationId'] == location_id['locationId'],'flag'] = 1
				time.sleep(60)
			if (len(location_df) == index+1):
				product_compleated = True
			product_df.to_csv(product_folder_name,index=False)
			location_df.to_csv(location_folder_name,index=False)

	except Exception as e:
		log.error(e)
	finally:
		location_df.reset_index()
		product_df.reset_index()
		return location_df,product_df,product_compleated

def remove_duplicate_products(product_df_pro):
	product_df_pro = product_df_pro.drop_duplicates(subset=['id', 'name'], keep='first')
	return product_df_pro

def main():
	if (len(sys.argv)==2):
		date = sys.argv[1]
		print (date)
		if(os.path.isfile(FOLDER+'/customers_'+date+'.csv') == False):
			customers_data_df = get_customers_id(FOLDER+'/customers_'+date+'.csv',FOLDER+'/location_'+date+'.csv')
		else: 
			customers_data_df = pd.read_csv(FOLDER+'/customers_'+date+'.csv')

		if (len(customers_data_df)>0):
			compleated = False
			log.info("Fetched all Customers.")
			while(compleated ==False):
				customers_data_df,location_df,compleated = get_location_id(FOLDER+'/customers_'+date+'.csv',FOLDER+'/location_'+date+'.csv')	
				customers_data_df.to_csv(FOLDER+'/customers_'+date+'.csv',index=False)
				#location_df['flag'] = 0
				location_df.to_csv(FOLDER+'/location_'+date+'.csv',index=False)
				if (compleated == True and len(location_df)>0):
					log.info("Fetched all locations.")
					product_compleated = False
					product_df = pd.DataFrame()
					product_df.to_csv(FOLDER+'/product_'+date+'.csv')
					while(product_compleated ==False):
						location_df_pro,product_df_pro,product_compleated = get_product_id(FOLDER+'/location_'+date+'.csv',FOLDER+'/product_'+date+'.csv')
						product_df_pro.reset_index()
						product_df_pro.to_csv(FOLDER+'/product_'+date+'.csv',index=False)
						if (product_compleated == True):
							log.info("Fetched all Products.")
							product_df_pro = remove_duplicate_products(product_df_pro)
							product_df_pro.reset_index()
							product_df_pro.to_csv(FOLDER+'/product_distinct_'+date+'.csv',index=False)
							print (product_df_pro)


	else:
		log.info("Enter Date")
	
main()



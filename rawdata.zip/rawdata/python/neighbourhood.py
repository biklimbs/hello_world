"""
Title: Implements neighbourhood feature
Description: What is neighbourhood?
			A given day result is scanned and the heighest spike without sold data is identified and after that a check is done whether neighbouring 
			datapoints is having poured only data and assign the weight accordingly neighbours are given weight.
Example: if the maximum is having a neighbour then the neighbour will be awarded weight. If the neighbour datapoint is having sold and poured then weight is not awarded.
"""


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pandas as pd
from logger_config import log
try:
	from constants import *
except:
	log.error("constants.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()




# checking the neighbourhood feature, for the datapoint in linecleaning dataframe with sold data zero
# if any near by datapoint is having maximum weight then that datapoint will be assignd maximum weight
# this is product wise
def compute_neighbourhood_feature(df_linecleaning_local,data_point):
	#print("In check neighbourhood")
	#latest_i=int(i)
	if df_linecleaning_local.loc[data_point,"sold"]==0 and df_linecleaning_local.loc[data_point,"weight"]!=MAX_NEIGHBOUR:
		
		prev_flag=True
		nxt_flag=True
		for j in range(data_point):
			prev=int(data_point-j)
			nxt=int(data_point+j)
			#print("...it is j",str(int(latest_i-j)))
			
			if prev_flag==True:
				#log.debug("prev="+str(prev))
				#print("prev=",prev)
				if prev!=0 and df_linecleaning_local.loc[prev-1,"weight"]==MAX_NEIGHBOUR:
					#log.debug("prev======"+str(prev))
					#print("prev======",prev)
					df_linecleaning_local.loc[data_point,"neigh_f"]=MAX_NEIGHBOUR-0.05
					df_linecleaning_local.loc[data_point,"weight"]=MAX_NEIGHBOUR-0.05
					#log.debug("weight changed in prev")
					#print("date and time==",df_linecleaning_local.loc[data_point,"date"],df_linecleaning_local.loc[data_point,"time"])
					#print("weight changed in prev")
					prev_flag=False
					break

				elif prev==0 or df_linecleaning_local.loc[prev-1,"sold"]!=0:
					#log.debug("prev flag is False")
					#print("prev flag is False")
					prev_flag=False
					#break
			if nxt_flag==True:
				#log.debug("nxt=="+str(nxt))
				#print("nxt==",nxt)
				#print("length=",(len(df_linecleaning_local)-1))
				if nxt!=(len(df_linecleaning_local)-1) and df_linecleaning_local.loc[nxt+1,"weight"]==MAX_NEIGHBOUR:
					df_linecleaning_local.loc[data_point,"neigh_f"]=MAX_NEIGHBOUR-0.05
					df_linecleaning_local.loc[data_point,"weight"]=MAX_NEIGHBOUR-0.05
					#log.debug("weight changed in next")
					#print("date and time==",df_linecleaning_local.loc[data_point,"date"],df_linecleaning_local.loc[data_point,"time"])
					#print("weight changed in next")
					nxt_flag=False
					break
				elif nxt==(len(df_linecleaning_local)-1) or df_linecleaning_local.loc[nxt+1,"sold"]!=0:
					#log.debug("next flag is False")
					#print("next flag is False")
					nxt_flag=False

			if prev_flag==False and nxt_flag==False:
				#log.debug("Both False")
				#print("Both False")
				break

		return df_linecleaning_local
	else:
		return df_linecleaning_local


def neighbourhood_main(base_data_df):
	try:
		# print(base_data_df)
		#MAX = base_data_df['t_weight'].max()
		# base_data_df["neigh_w"]=0
		# base_data_df["neigh_f"]=0
		prod_uniq=base_data_df["prod_id"].unique()
		result_df = pd.DataFrame()
		for product_id in prod_uniq:
			filter_prod_df = base_data_df[base_data_df["prod_id"] == product_id]
			filter_prod_df=filter_prod_df.sort_values(by=['date','time'],ascending=True)
			filter_prod_df= filter_prod_df.reset_index(drop=True)
			# print(filter_prod_df)
			filter_prod_df["neigh_f"]= 0  													## Default means it is max already

			for index,row in filter_prod_df.iterrows():
				filter_prod_df = compute_neighbourhood_feature(filter_prod_df,index)
			result_df = result_df.append(filter_prod_df)
		result_df= result_df.reset_index(drop=True)
		#print(result_df)
		return result_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)
def get_neighbourhood(base_data_df):
	return neighbourhood_main(base_data_df)
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time
import random
import json
import csv
import pandas as pd
import datetime
import traceback

MY_SQL_HOST_NAME = 'hadoop.vmokshagroup.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Power@1234'
MY_SQL_DB_NAME = 'beerboardLocalDb'
NORMILIZED_TABLE = 'norm_poured_sold_ln'
LINE_CLEANING_TABLE = 'poured_sold'

VAR_MIN=20
START_TIME_CONST=" 00:00:00"

def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)
	return connection_hadoop_internal

def get_date(var1,connection_hadoop_internal):
		try:
			with connection_hadoop_internal.cursor() as hadoop_cursor:
				#sql = "select date,user_id,location_id, location_name, product_id, product_name, poured, sold from linecleaningTable ORDER BY date LIMIT 10, 5;"
				sql="SELECT date from (SELECT  *, STR_TO_DATE(date, '%Y-%m-%d %H:%i') as DATE1 FROM "+LINE_CLEANING_TABLE+")AS derivTable order by DATE1 "+var1+" limit 1;"
				hadoop_cursor.execute(sql)
				#time_interval=hadoop_cursor.fetchall()
				#print(time_interval)
				time_ret=hadoop_cursor.fetchall()
				start_date,start_time=(time_ret[0]["date"]).split(" ")
				time_ret=start_date+START_TIME_CONST
				#print(time_ret)
				return (time_ret)

		except:
			print("error1")
			traceback.print_exc()

def get_table_data(i,j,date_list,connection_hadoop_internal):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		sql="SELECT * from (SELECT  *, STR_TO_DATE(date, '%Y-%m-%d %H:%i') as DATE1 FROM "+LINE_CLEANING_TABLE+")AS derivTable where DATE1 between '"+date_list[i]+"' and (SELECT SUBTIME ('"+date_list[j]+"','0 0:0:1'));"
		hadoop_cursor.execute(sql)
		time_interval=hadoop_cursor.fetchall()
		time_interval_df=pd.DataFrame(time_interval)

	return(time_interval_df)


def write_data(date_var,time_var,user_var,loc,loc_var,prod_id,product_name,line_number_data,line_number_flag,poured_tot,sold_tot,hadoop_cursor):
	try:
		sql = "insert into "+NORMILIZED_TABLE+" (date, time, user_id, location_id,location_name, product_id,product_name,line_number,multi_line, poured, sold) VALUES ('"+str(date_var)+"','"+str(time_var)+"',"+str(user_var)+","+str(loc)+",\""+loc_var+"\","+str(prod_id)+",\""+product_name+"\",'"+str(line_number_data)+"','"+str(line_number_flag)+"','"+str(poured_tot)+"','"+str(sold_tot)+"')"
		hadoop_cursor.execute(sql)

	except:
		print("error4")
		traceback.print_exc()

def write_null_data(i,date_list,hadoop_cursor):
	try:
		date_var=date_list[i]
		#print(".........",date_var)
		date_var,time_var=date_var.split(" ")
		print(date_var, time_var)
		user_var="0"
		loc="0"
		loc_var="0"
		prod_id = "0"
		prod_value = "0"
		line_number_data= "0"
		line_number_flag= 0
		poured_tot="0"
		sold_tot="0"
		sql = "insert into "+NORMILIZED_TABLE+" (date, time, user_id, location_id,location_name, product_id,product_name,line_number,multi_line,poured, sold) VALUES ('"+str(date_var)+"','"+str(time_var)+"',"+str(user_var)+","+str(loc)+",'"+loc_var+"',"+str(prod_id)+",'"+prod_value+"','"+str(line_number_data)+"','"+str(line_number_flag)+"','"+str(poured_tot)+"','"+str(sold_tot)+"')"
		hadoop_cursor.execute(sql)
		#print("0 data updated")
	except:
		traceback.print_exc()
		print("error5")
	

def split_data(time_interval_df,temp_poured_sold):
	for t in range(0,len(time_interval_df[temp_poured_sold])):
		try:
			time_interval_df.loc[t,temp_poured_sold+'_list'], time_interval_df.loc[t,'waste'] = time_interval_df.loc[t,temp_poured_sold].split(" ")
		except:
			time_interval_df.loc[t,temp_poured_sold+'_list']=time_interval_df.loc[t,temp_poured_sold]
	return (time_interval_df)

def single_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor):
	time_interval_df_temp_prod_ln= time_interval_df_temp_prod
	#print(time_interval_df_temp_prod_ln)
	time_interval_df_temp_prod_ln = time_interval_df_temp_prod_ln.reset_index(drop=True)
	#print(time_interval_df_temp_prod_ln)
	user_var=time_interval_df_temp_prod_ln.loc[0,"user_id"]
	print("user id=",user_var)
	loc=time_interval_df_temp_prod_ln.loc[0,"location_id"]
	print("location id=",loc)
	loc_var=time_interval_df_temp_prod_ln.loc[0,"location_name"]
	print("location name=",loc_var)
	prod_id = time_interval_df_temp_prod_ln.loc[0,"product_id"]
	print("product id=",prod_id)
	prod_value = time_interval_df_temp_prod_ln.loc[0,"product_name"]
	print("product name=",prod_value)
	if len(unique_line_number)>1  and 0 in unique_line_number:
		unique_line_number.remove(0)
	line_number_data= unique_line_number[0]
	print("line number= ",line_number_data)
	poured_tot= pd.to_numeric(time_interval_df_temp_prod_ln.poured_list).sum()
	poured_tot=round(poured_tot,2)
	sold_tot=pd.to_numeric(time_interval_df_temp_prod_ln.sold_list).sum()
	sold_tot=round(sold_tot,2)
	print("poured=",poured_tot)
	print("sold=",sold_tot)
	write_data(date_var,time_var,user_var,loc,loc_var,prod_id,prod_value,line_number_data,0,poured_tot,sold_tot,hadoop_cursor)

def multi_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor):
	print ("------------------------------------------------------------------------")
	print ("------------------------------------------------------------------------")
	print ("------------------------------------------------------------------------")
	print (unique_line_number)
	sold_tot=0
	if 0 in unique_line_number:
		zero_line_df= time_interval_df_temp_prod.loc[time_interval_df_temp_prod["line_number"]==0]
		sold_tot=pd.to_numeric(zero_line_df.sold_list).sum()
		unique_line_number.remove(0)
	
	for line_number_uniq in unique_line_number:
		print("line number=======",line_number_uniq)
		time_interval_df_temp_prod_ln= time_interval_df_temp_prod[time_interval_df_temp_prod["line_number"]== line_number_uniq]
		#print(time_interval_df_temp_prod_ln)
		time_interval_df_temp_prod_ln = time_interval_df_temp_prod_ln.reset_index(drop=True)
		#print(time_interval_df_temp_prod_ln)
		user_var=time_interval_df_temp_prod_ln.loc[0,"user_id"]
		print("user id=",user_var)
		loc=time_interval_df_temp_prod_ln.loc[0,"location_id"]
		print("location id=",loc)

		loc_var=time_interval_df_temp_prod_ln.loc[0,"location_name"]
		print("location name=",loc_var)
		prod_id = time_interval_df_temp_prod_ln.loc[0,"product_id"]
		print("product id=",prod_id)
		prod_value = time_interval_df_temp_prod_ln.loc[0,"product_name"]
		print("product name=",prod_value)
		line_number_data= time_interval_df_temp_prod_ln.loc[0,"line_number"]
		print("line number= ",line_number_data)
		poured_tot= pd.to_numeric(time_interval_df_temp_prod_ln.poured_list).sum()
		poured_tot=round(poured_tot,2)
		print("poured=",poured_tot)
		print("sold=",sold_tot)
		write_data(date_var,time_var,user_var,loc,loc_var,prod_id,prod_value,line_number_data,1,poured_tot,sold_tot,hadoop_cursor)

def line_number_condn(date_var,time_var,unique_line_number,time_interval_df_temp_prod,hadoop_cursor):
	print (unique_line_number)
	if len(unique_line_number)<=2 and 0 in unique_line_number:
		single_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor)
	elif (len(unique_line_number)== 1 and 0 not in unique_line_number):
		single_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor)
	else:
		multi_line_logic(date_var,time_var,unique_line_number, time_interval_df_temp_prod,hadoop_cursor)


def main():
	connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
	time_interval={}

	start_time=get_date("asc",connection_hadoop_internal)
	#print(start_time)
	end_time=get_date("desc",connection_hadoop_internal)
	end_time=pd.to_datetime(end_time)
	date_list=[]
	
	datetime_temp=pd.to_datetime(start_time)
	date_list.append(str(datetime_temp))
	while(str(datetime_temp)<str(end_time)):
		datetime_temp = (datetime_temp + datetime.timedelta(minutes=VAR_MIN))
		date_list.append(str(datetime_temp))
		

	for i in range(0,len(date_list)):
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			j=i+1
			start_time1 = time.time()
			try:
				time_interval_df=get_table_data(i,j,date_list,connection_hadoop_internal)
				connection_hadoop_internal.commit()
				date_var=date_list[i]
				
				date_var,time_var=date_var.split(" ")
				print("date=",date_var)
				print("time=",time_var)
				#print (date_var)
				temp_poured="poured"
				temp_sold="sold"
				time_interval_df=split_data(time_interval_df,temp_poured)
				time_interval_df=split_data(time_interval_df,temp_sold)
				poured_list=time_interval_df["poured_list"]
				sold_list=time_interval_df["sold_list"]
				location_id_list=time_interval_df["location_id"]
				unique_loc=time_interval_df["location_id"].unique()
				print("..................",len(unique_loc),unique_loc)
				#print(unique_loc)
				#print (time_interval_df)
				
				for loc in unique_loc:
					time_interval_df_temp = time_interval_df[time_interval_df["location_id"] == loc]
					#print("..................,,,,,,,,,,,,,,,,,,",time_interval_df_temp)
					time_interval_df_temp = time_interval_df_temp.reset_index()

					unique_product_list = time_interval_df_temp["product_id"].unique()
					print ("unique product list=",unique_product_list)
					for product_id_unique in unique_product_list:
						print("product_id======= ",product_id_unique)
						#print(".........................................",time_interval_df_temp)
						time_interval_df_temp_prod = time_interval_df_temp[time_interval_df_temp["product_id"] == product_id_unique]
						#print("..................,,,,,,,,,,,,,,,,,,",time_interval_df_temp)
						time_interval_df_temp_prod = time_interval_df_temp_prod.reset_index(drop=True)
						unique_line_number= time_interval_df_temp_prod["line_number"].unique()
						print(unique_line_number)
						unique_line_number= list(unique_line_number)

						line_number_condn(date_var,time_var,unique_line_number,time_interval_df_temp_prod,hadoop_cursor)

						# for line_number_uniq in unique_line_number:
						# 	print("line number=======",line_number_uniq)
						# 	time_interval_df_temp_prod_ln= time_interval_df_temp_prod[time_interval_df_temp_prod["line_number"]== line_number_uniq]
						# 	#print(time_interval_df_temp_prod_ln)
						# 	time_interval_df_temp_prod_ln = time_interval_df_temp_prod_ln.reset_index(drop=True)
						# 	#print(time_interval_df_temp_prod_ln)
						# 	user_var=time_interval_df_temp_prod_ln.loc[0,"user_id"]
						# 	print("user id=",user_var)
						# 	print("location id=",loc)
						# 	loc_var=time_interval_df_temp_prod_ln.loc[0,"location_name"]
						# 	print("location name=",loc_var)
						# 	prod_id = product_id_unique
						# 	print("product id=",prod_id)
						# 	prod_value = time_interval_df_temp_prod_ln.loc[0,"product_name"]
						# 	print("product name=",prod_value)
						# 	line_number_data= time_interval_df_temp_prod_ln.loc[0,"line_number"]
						# 	print("line number= ",line_number_data)
						# 	poured_tot= pd.to_numeric(time_interval_df_temp_prod_ln.poured_list).sum()
						# 	poured_tot=round(poured_tot,2)
						# 	sold_tot=pd.to_numeric(time_interval_df_temp_prod_ln.sold_list).sum()
						# 	sold_tot=round(sold_tot,2)
						# 	print("poured=",poured_tot)
						# 	print("sold=",sold_tot)
						# 	write_data(date_var,time_var,user_var,loc,loc_var,prod_id,prod_value,line_number_data,poured_tot,sold_tot,hadoop_cursor)
					
				print("%.3f ms" % (((time.time() - start_time1)*1000)/len(unique_loc)))

			except:
				traceback.print_exc()
				print("0 data updated")
				print(date_list[i],"     ",date_list[j])
				write_null_data(i,date_list,hadoop_cursor)
		connection_hadoop_internal.commit()
	
if __name__=='__main__':
	main()

import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pandas as pd
import os
import os.path
import datetime
from subprocess import call
from termcolor import colored
import csv
from logger_config import log

try:
	import linecleaning_main
except:
	log.critical("linecleaning_main.py file not found.")
	sys.exit()

FILE_PATH_DUMP = './../../test/data_dump/'
FILE_NAME_DUMP = '_dump'
FILE_PATH_gt = './../../test/ground_truth_test/'
FILE_NAME_gt = '_gt'
FILE_PATH_gtp = './../../test/accuracy/'
FILE_NAME_gtp = '_gtp'
ACCURACY_FILE_NAME = 'accuracy'
EXT = '.csv'
CONFIDANCE_LEVEL = 75



def get_processed_data(data_dump,data_gt):
	#print (data_gt)
	for index, row in data_dump.iterrows():
		filter_data = data_gt[(data_gt.date == row['date'])&(data_gt.start_time == row['start_time'])&(data_gt.prod_id == row['prod_id'])]
		#print (len(filter_data))
		if (len(filter_data)>0):
			gt_row = filter_data.iloc[0]
			#print (gt_row)
			if (gt_row['ground_truth'] == 1):
				#print ("Ground_truth = 1")
				data_dump.loc[index, 'ground_truth'] = 1
	return data_dump

def gtp(file,data_dump,accuracy_file_name):
	if check_if_file_exists(FILE_PATH_gt,file)==True:
		data_gt = pd.read_csv(FILE_PATH_gt+file, encoding='utf-8')
		data_gtp = get_processed_data(data_dump,data_gt)
		if (len(data_gtp)>0):
			location_id =  data_gtp.loc_id.unique()
			location_name = data_gtp.loc_name.unique()
			list_of_zeros = [0] * len(data_gtp)
			data_gtp['truth'] =  pd.Series(list_of_zeros)
			for index, row in data_gtp.iterrows():	
				if (row['confidence'] >=CONFIDANCE_LEVEL and row['ground_truth'] == 1):
					data_gtp.loc[index, 'positive'] = 1
					data_gtp.loc[index, 'truth'] = 1
				elif (row['confidence'] <CONFIDANCE_LEVEL and row['ground_truth'] == 0):
					data_gtp.loc[index, 'positive'] = 1
				elif (row['confidence'] >=CONFIDANCE_LEVEL and row['ground_truth'] == 0):
					data_gtp.loc[index, 'false_positive'] = 1
				elif (row['confidence'] <CONFIDANCE_LEVEL and row['ground_truth'] == 1):
					data_gtp.loc[index, 'false_negative'] = 1

			sum_positive = data_gtp['ground_truth'].sum()
			sum_false_positive = data_gtp['false_positive'].sum()
			sum_false_negative = data_gtp['false_negative'].sum()
			len_data = len(data_gtp)
			sum_negative = sum_false_positive + sum_false_negative
			accuracy = sum_positive/len_data*100
			print (accuracy,sum_positive,len_data)
			false_positive_percentage = sum_false_positive/len_data*100
			false_negative_percentage = sum_false_negative/len_data*100
			false_positive_percentage = float("{0:.2f}".format(false_positive_percentage))
			false_negative_percentage = float("{0:.2f}".format(false_negative_percentage))
			accuracy = float("{0:.2f}".format(accuracy))
			log.debug("Algrothm accuracy for this location is "+str(accuracy))
			accuracy_csv = pd.read_csv(FILE_PATH_gtp+accuracy_file_name, encoding='utf-8')
			#print (accuracy_csv)
			columns = ['location_id','location_name','accuracy','false_positive','false_negative','average_accuracy']
			list_insert = [location_id[0],location_name[0],accuracy,false_positive_percentage,false_negative_percentage,'']
			df_row = pd.DataFrame([list_insert],columns=columns)
			frames = [accuracy_csv,df_row]
			accuracy_csv = pd.concat(frames)

			data_gtp.to_csv(FILE_PATH_gtp+file)
			accuracy_csv.to_csv(FILE_PATH_gtp+accuracy_file_name, index = False, columns=columns)
	else:
		log.warning(str(file)+" does not exists")
		#print (str(file)+" does not exists")
def check_if_file_exists(path,file_name):
	return os.path.exists(path+file_name)

def get_data_dump_file(file_path,file_name):
	data = pd.read_csv(file_path+file_name, encoding='utf-8')
	return data

def create_accuracy_file():
	time_now = datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S')
	accuracy_file_name = ACCURACY_FILE_NAME+"_"+time_now+EXT
	with open(FILE_PATH_gtp+accuracy_file_name, 'w') as csvfile:
	    filewriter = csv.writer(csvfile, delimiter=',' , quotechar='|', quoting=csv.QUOTE_MINIMAL)
	    filewriter.writerow(["location_id","location_name","accuracy","average_accuracy"])
	return accuracy_file_name

def average_accuracy(accuracy_file_name):
	accuracy_df = pd.read_csv(FILE_PATH_gtp+accuracy_file_name, encoding='utf-8')
	average_accuracy_sum = accuracy_df['accuracy'].sum()
	len_accuracy = len(accuracy_df)
	columns = ['location_id','location_name','accuracy','false_positive','false_negative','average_accuracy']
	acc = average_accuracy_sum/len_accuracy
	acc = float("{0:.2f}".format(acc))
	columns = ['location_id','location_name','accuracy','false_positive','false_negative','average_accuracy']
	list_insert = ['','','','','',acc]
	df_acc_row = pd.DataFrame([list_insert],columns=columns)
	frames = [accuracy_df,df_acc_row]
	accuracy_csv = pd.concat(frames)
	accuracy_csv.to_csv(FILE_PATH_gtp+accuracy_file_name, index = False,  columns=columns)

def main():
	#if(check_if_file_exists(FILE_PATH_gtp,ACCURACY_FILE_NAME+EXT)!= True):
	accuracy_file_name = create_accuracy_file()
	pd.options.display.max_rows=1000
	pd.set_option('expand_frame_repr', False)
	# if(len(sys.argv)<2):
	# 	log.critical(colored("Date range arguments are missing",'red'))
	# 	sys.exit(0)
	# elif(len(sys.argv)<3):
	# 	log.critical(colored("To date argument is missing",'red'))
	# 	sys.exit(0)

	from_date = sys.argv[1]
	to_date = sys.argv[2]

	files = os.listdir(FILE_PATH_gt)
	for file in files:
		
		location_id = file.split('_gt.csv')[0]
		# print (logging.getEffectiveLevel())

		print("Analysing for location "+location_id)
		#print ("Analysing for location ",location_id)
		#linecleaning_product.main()
		call(["python", "linecleaning_main.py",location_id,from_date,to_date])
		if(check_if_file_exists(FILE_PATH_DUMP,location_id+FILE_NAME_DUMP+EXT) == True):
			data = get_data_dump_file(FILE_PATH_DUMP,location_id+FILE_NAME_DUMP+EXT)
			gtp(file,data,accuracy_file_name)
		else:
			log.warning(str(location_id+FILE_NAME_DUMP+EXT)+" does not exists")
			#print (str(location_id+FILE_NAME_DUMP+EXT)+" does not exists")
		print(colored("--------------------------------",'red'))
	average_accuracy(accuracy_file_name)
if __name__ == '__main__':
	main()
#----------- Importing Required Libraries ----------
# 
# Title: Add Exception from smart bar exception table to "location_date_table" table
# Author: Pavan Chunchula
# Date: 22-05-2018

# Modification history
# Date: 22-May-2018 updated url to get all the exceotions (Earlier only L1 Queue was considered,i.e, Type:L1 Queue )
# Now Type filter is removed from the api url,this gives all exceptions from exception table.The parameter limit in api is set to 1000 so that it won't truncate the result.
# 
import requests
import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
from new_api_data_insert_to_mysql import raw_data_download 
sys.path.append('./../misc/data_wrangling/')
from normalized_poured_sold_optimized_updated import main as normalized_poured_sold_main
from constants import NUMBER_OF_DAYS_TO_RUN_THE_ALGO
from constants import MY_SQL_HOST_NAME
from constants import MY_SQL_USER_NAME
from constants import MY_SQL_PASSWORD
from constants import MY_SQL_DB_NAME
from constants import LOCATION_DATE_TABLE
from constants import NEGITIVE_VARIENCE_L1_LIMIT

#----------- Url link to get exception details based on date ----------
Basic_URL="http://34.236.166.193:1342"
secondary_URL="/SBarException/?limit=1000&skip=0&where={\"ReportedDate\":\""


#----------- Rest API where returns response in json fromat ----------
def api_call(sele_date):
    response  = ""
    while (response == ""):
        try:
        	# print(Basic_URL+secondary_URL+sele_date+"\",\"Type\":\"L1 Queue\"}&sort=Id ASC")
        	response = requests.get(Basic_URL+secondary_URL+sele_date+"\"}&sort=Id ASC",timeout = 6000) # for only L1 Queue exceptions for limit of 1000
        	# response = requests.get(Basic_URL+secondary_URL+sele_date+"\"}&sort=Id ASC",timeout = 6000) # for entire exceptions for limit of 1000 (start Date : 20th May 2018)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()


#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()

			#print(line_cleaning_table_result)
			return db_check_result

	except:
		#traceback.print_stack()
		return None
    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False

#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	connection_hadoop_internal = pymysql.connect(host=host,
                             user=user,
                             password=password,
                             db=db,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

	return connection_hadoop_internal
    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)

		except Exception as e:
			log.error(e)
			t.sleep(30)

	return connection_hadoop_check

#-----------Validating date format  ----------         
def validate(date_text):
    try:
        datetime.strptime(date_text, '%Y-%m-%d')
        return True
    except Exception as e:
        return False
# UserID,LocationID,LocationName

#-----------Establishing Connection to MySQL Server ----------         
# connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)

#-----------Update / new records insertion to location table based on request date ----------         		
def write_data_to_loation_table(connection_hadoop_internal,sele_date):
    if(check_if_Table_exits(connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME))):
        with connection_hadoop_internal.cursor() as hadoop_cursor:
            try:
                # print("hai")
                hadoop_cursor.execute("select location_id,date from "+LOCATION_DATE_TABLE+" ;")
                distinct_locatons = hadoop_cursor.fetchall()
                # print("select location_id,date from "+LOCATION_DATE_TABLE+" ;")
                # print(len(distinct_locatons))
                if(len(distinct_locatons) > 0):
                	loations_date_table=pd.DataFrame(distinct_locatons)
                	res_array=[]
	                res_=api_call(sele_date)
	                count=0
	                for i in res_.get("ViewModels"):
	                	# print(i.get("Variance"))
	                	# print(float(i.get("Variance"))< -40 or float(i.get("Variance"))> 10)
	                	if(float(i.get("Variance"))<= float(NEGITIVE_VARIENCE_L1_LIMIT)):
	                		count=count+1
	                		ReportedDate=datetime.strptime(str(i.get("ReportedDate")), '%Y-%m-%d')
	                		for x in range(NUMBER_OF_DAYS_TO_RUN_THE_ALGO):
	                			
	                			ReportedDate_formate=str(str(ReportedDate).split(" ")[0])
	                			log.info("Checking for date  "+str(ReportedDate_formate))
			                	if(ReportedDate_formate not in list(loations_date_table.loc[loations_date_table['location_id']==int(i.get("LocationId"))]['date'])):
			                		# start_date, cur_date = cur_date, cur_date-timedelta(days=1)
			                		# print (ReportedDate_formate)
			                		# print ("-------------------------------------------------------------------------------------------")
			                		log.info("Inserting   "+i.get("LocationId"))
			                		a=str(i.get("Location")).split(" - ")
			                		if(str(sele_date)==str(ReportedDate_formate)):
			                			if(ReportedDate_formate not in list(loations_date_table.loc[loations_date_table['location_id']==int(i.get("LocationId"))]['date'])):
			                				sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date,exceflag) VALUES ('"+str(i.get("CustomerId"))+"','"+str(a[0])+"','"+str(i.get("LocationId"))+"','"+str(a[1])+"',0,0,'"+str(i.get("Variance"))+"','"+ ReportedDate_formate +"',1)"
			                			else:
			                				sql = "update "+LOCATION_DATE_TABLE+" set exceflag=1 where user_id="+str(i.get("CustomerId"))+" and location_id="+str(i.get("LocationId"))+"and date= '"+ ReportedDate_formate +"')"
			                				print(sql)

			                				# UPDATE beerboardLocalDb.poured_sold_t SET user_name= \""+user_name_+"\" where user_id = "+str(data[i]["user_id"])+";"

			                			# sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date,exceflag) VALUES ('"+str(i.get("CustomerId"))+"','"+str(a[0])+"','"+str(i.get("LocationId"))+"','"+str(a[1])+"',0,0,'"+str(i.get("Variance"))+"','"+ ReportedDate_formate +"',1)"
			                		else:
			                			# print("========================================================================================")
			                			sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date,exceflag) VALUES ('"+str(i.get("CustomerId"))+"','"+str(a[0])+"','"+str(i.get("LocationId"))+"','"+str(a[1])+"',0,0,'"+str(i.get("Variance"))+"','"+ ReportedDate_formate +"',0)"
			                		# sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date) VALUES ('"+str(i.get("CustomerId"))+"','"+str(a[0])+"','"+str(i.get("LocationId"))+"','"+str(a[1])+"',0,0,'"+str(i.get("Variance"))+"','"+ ReportedDate_formate +"')"
			                		hadoop_cursor.execute(sql)
			                	else:
			                		log.info(i.get("LocationId")+" of "+ ReportedDate_formate+"already exits ")
			                	ReportedDate=ReportedDate-timedelta(days=1)
			                # log.info("-------------------------------------------")
			                log.info(count)
                else:
                	res_array=[]
	                res_=api_call(sele_date)
	                for i in res_.get("ViewModels"):
	                	# print(i.get("Variance"))
	                	if(float(i.get("Variance"))< 0):
	                		ReportedDate=datetime.strptime(str(i.get("ReportedDate")), '%Y-%m-%d')
	                		for x in range(NUMBER_OF_DAYS_TO_RUN_THE_ALGO):
	                	
	                			ReportedDate_formate=str(str(ReportedDate).split(" ")[0])
		                		log.info("Inserting    "+ i.get("LocationId"))
		                		a=str(i.get("Location")).split(" - ")
		                		print(str(sele_date)==str(ReportedDate_formate))
		                		if(str(sele_date)==str(ReportedDate_formate)):
		                			sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date,exceflag) VALUES ('"+str(i.get("CustomerId"))+"','"+str(a[0])+"','"+str(i.get("LocationId"))+"','"+str(a[1])+"',0,0,'"+str(i.get("Variance"))+"','"+ ReportedDate_formate +"',1)"
		                		else:
		                			sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date,exceflag) VALUES ('"+str(i.get("CustomerId"))+"','"+str(a[0])+"','"+str(i.get("LocationId"))+"','"+str(a[1])+"',0,0,'"+str(i.get("Variance"))+"','"+ ReportedDate_formate +"',0)"
		                		# sql = "insert into "+LOCATION_DATE_TABLE+" (user_id,user_name,location_id,location_name,rawflag,normflag,variance,date) VALUES ('"+str(i.get("CustomerId"))+"','"+str(a[0])+"','"+str(i.get("LocationId"))+"','"+str(a[1])+"',0,0,'"+str(i.get("Variance"))+"','"+ ReportedDate_formate +"')"
		                		ReportedDate=ReportedDate-timedelta(days=1)
		                		hadoop_cursor.execute(sql)
            
                connection_hadoop_internal.commit()
                t.sleep(5)
                log.info("Success")
                # if(count>0):
                # 	raw_data_download(sele_date)
                # 	normalized_poured_sold_main(sele_date)
                # 	save_linecleaning_result_main(sele_date)


                # print(res_array)
                # write_csv("location_april/"+res_.get("info").get("criteria").get("ReportedDate")+".csv",res_array,['UserID','UserName','LocationID','LocationName'])

            except Exception as e:
                log.error("Exception"+str(e))
                #traceback.print_exc()



#-----        Main Start From HERE      ---------------


# try:
# 	if(len(sys.argv)>=2):
# 		if(validate(sys.argv[1])):
# 			write_data_to_loation_table(connection_hadoop_internal,str(sys.argv[1]))
# 		else:
# 			log.error("Invalid Date Format.   Use  : python "+sys.argv[0]+ "  YYYY-MM-DD")
# 	else:
# 		log.error("Invalid Usage.   Use  : python "+sys.argv[0]+ "  YYYY-MM-DD")
# except Exception as e:
# 	log.error(e)
# 	print(new_date.strftime("%Y-%m-%d"))
# 	print(str(cur_date)+"-----> Inserted ")












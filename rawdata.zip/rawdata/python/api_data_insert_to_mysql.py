	#!/usr/bin/python
import sys, traceback
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time
import random
import json
import csv
import datetime
from datetime import datetime, timedelta
from time import gmtime, strftime
from termcolor import colored
import pandas as pd
import inspect, os
import traceback
from logger_config import log


MY_SQL_HOST_NAME = 'hadoop.vmoksha.com'
MY_SQL_USER_NAME = 'root'
MY_SQL_PASSWORD = 'Power@1234'
MY_SQL_DB_NAME = 'beerboardLocalDb'
URL1 = "http://betaapi.beerboard.com/nodejsserver/downloadLocationData?beta=0&userId="
URL2 = "&location="
URL3 = "&date="

LINE_CLEANING_TABEL = 'poured_sold'
LINE_CLEANING_PLU_TABEL = 'plu'
#LINE_CLEANING_TABEL = 'bb_001_025'
#LINE_CLEANING_PLU_TABEL = 'bb_001_025_plu'
#LINE_CLEANING_TABEL = 'bb_026_050'
#LINE_CLEANING_PLU_TABEL = 'bb_026_050_plu'
#LINE_CLEANING_TABEL = 'bb_051_075'
#LINE_CLEANING_PLU_TABEL = 'bb_051_075_plu'
#LINE_CLEANING_TABEL = 'bb_076_100'
#LINE_CLEANING_PLU_TABEL = 'bb_076_100_plu'
#LINE_CLEANING_TABEL = 'bb_101_125'
#LINE_CLEANING_PLU_TABEL = 'bb_101_125_plu'
#LINE_CLEANING_TABEL = 'bb_126_150'
#LINE_CLEANING_PLU_TABEL = 'bb_126_150_plu'
#LINE_CLEANING_TABEL = 'bb_151_175'
#LINE_CLEANING_PLU_TABEL = 'bb_151_175_plu'
#LINE_CLEANING_TABEL = 'bb_176_200'
#LINE_CLEANING_PLU_TABEL = 'bb_176_200_plu'
#LINE_CLEANING_TABEL = 'bb_201_225'
#LINE_CLEANING_PLU_TABEL = 'bb_201_225_plu'
#LINE_CLEANING_TABEL = 'bb_226_250'
#LINE_CLEANING_PLU_TABEL = 'bb_226_250_plu'
#LINE_CLEANING_TABEL = 'bb_251_275'
#LINE_CLEANING_PLU_TABEL = 'bb_251_275_plu'
#LINE_CLEANING_TABEL = 'bb_276_300'
#LINE_CLEANING_PLU_TABEL = 'bb_276_300_plu'
#LINE_CLEANING_TABEL = 'bb_301_325'
#LINE_CLEANING_PLU_TABEL = 'bb_301_325_plu'
#LINE_CLEANING_TABEL = 'bb_326_350'
#LINE_CLEANING_PLU_TABEL = 'bb_326_350_plu'
#LINE_CLEANING_TABEL = 'bb_351_375'
#LINE_CLEANING_PLU_TABEL = 'bb_351_375_plu'
#LINE_CLEANING_TABEL = 'bb_376_400'
#LINE_CLEANING_PLU_TABEL = 'bb_376_400_plu'
#LINE_CLEANING_TABEL = 'bb_401_425'
#LINE_CLEANING_PLU_TABEL = 'bb_401_425_plu'
#LINE_CLEANING_TABEL = 'bb_426_450'
#LINE_CLEANING_PLU_TABEL = 'bb_426_450_plu'
#LINE_CLEANING_TABEL = 'bb_451_475'
#LINE_CLEANING_PLU_TABEL = 'bb_451_475_plu'
#LINE_CLEANING_TABEL = 'bb_475_500'
#LINE_CLEANING_PLU_TABEL = 'bb_475_500_plu'
#LINE_CLEANING_TABEL = 'bb_501_525'
#LINE_CLEANING_PLU_TABEL = 'bb_501_525_plu'
#LINE_CLEANING_TABEL = 'bb_526_550'
#LINE_CLEANING_PLU_TABEL = 'bb_526_550_plu'
#LINE_CLEANING_TABEL = 'bb_551_575'
#LINE_CLEANING_PLU_TABEL = 'bb_551_575_plu'
#LINE_CLEANING_TABEL = 'bb_576_600'
#LINE_CLEANING_PLU_TABEL = 'bb_576_600_plu'
#LINE_CLEANING_TABEL = 'bb_601_625'
#LINE_CLEANING_PLU_TABEL = 'bb_601_625_plu'
#LINE_CLEANING_TABEL = 'bb_626_650'
#LINE_CLEANING_PLU_TABEL = 'bb_626_650_plu'
#LINE_CLEANING_TABEL = 'bb_651_675'
#LINE_CLEANING_PLU_TABEL = 'bb_651_675_plu'
#LINE_CLEANING_TABEL = 'bb_676_700'
#LINE_CLEANING_PLU_TABEL = 'bb_676_700_plu'
#LINE_CLEANING_TABEL = 'bb_701_725'
#LINE_CLEANING_PLU_TABEL = 'bb_701_725_plu'
#LINE_CLEANING_TABEL = 'bb_726_750'
#LINE_CLEANING_PLU_TABEL = 'bb_726_750_plu'
#LINE_CLEANING_TABEL = 'bb_751_775'
#LINE_CLEANING_PLU_TABEL = 'bb_751_775_plu'
#LINE_CLEANING_TABEL = 'bb_776_800'
#LINE_CLEANING_PLU_TABEL = 'bb_776_800_plu'

PROBLEM_PRODUCT_TABLE = 'rowProblemProductTable'
PROBLEM_LOCATION_TABLE = 'rowProblemLocationTable'
PROBLEM_PRODUCT_PLU_TABLE = 'pluProblemProductTable'
PROBLEM_LOCATION_PLU_TABLE = 'pluProblemLocationTable'
 
LOCATION_CSV_FILE_NAME = 'location_master.csv'
PRODUCT_CSV_FILE_NAME = 'product_master.csv'
USERID_LOCATION_ID_CSV_FILE_NAME = 'download_location.csv'
	
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_001_025.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_025_050.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_051_075.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_076_100.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_101_125.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_126_150.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_151_175.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_176_200.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_201_225.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_226_250.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_251_275.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_276_300.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_301_325.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_326_350.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_351_375.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_376_400.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_401_425.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_426_450.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_451_475.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_476_500.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_501_525.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_526_550.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_551_575.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_576_600.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_601_625.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_626_650.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_651_675.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_676_700.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_701_725.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_726_750.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_751_775.csv'
#USERID_LOCATION_ID_CSV_FILE_NAME = 'batch_776_800.csv'

#dir_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))+'/data/'
DIR_PATH = './data/'
api_date = ""
list_of_locid_and_usrid = []

START_DATE = "2018-03-23"
end_date = "2018-03-30"


def connect_to_db(host,user,password,db):
	try:
		connection_hadoop_internal = pymysql.connect(host=host,
	                             user=user,
	                             password=password,
	                             db=db,
	                             charset='utf8mb4',
	                             cursorclass=pymysql.cursors.DictCursor)
		return connection_hadoop_internal
	except Exception as e:
		log.error(e)
		return None

def check_if_Table_exits(connection_hadoop_internal):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+LINE_CLEANING_TABEL+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			line_cleaning_table_result = hadoop_cursor.fetchone()

			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+LINE_CLEANING_PLU_TABEL+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			line_cleaning_plu_table_result = hadoop_cursor.fetchone()

			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+PROBLEM_PRODUCT_TABLE+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			problem_product_table = hadoop_cursor.fetchone()

			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+PROBLEM_LOCATION_TABLE+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			problem_location_table = hadoop_cursor.fetchone()

			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+PROBLEM_LOCATION_PLU_TABLE+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			problem_location_plu_table = hadoop_cursor.fetchone()

			sql_quary = "SELECT * FROM information_schema.tables WHERE table_schema = '"+MY_SQL_DB_NAME+"' AND table_name = '"+PROBLEM_PRODUCT_PLU_TABLE+"' LIMIT 1;"
			hadoop_cursor.execute(sql_quary)
			problem_product_plu_table = hadoop_cursor.fetchone()
			
			if(line_cleaning_table_result != None and line_cleaning_plu_table_result != None and problem_product_table != None
				and problem_location_table != None and problem_location_plu_table != None and problem_product_plu_table != None):
				return True
			else:
				return False
	except Exception as e:
		log.warning(e)
		#traceback.print_stack()
		return False

def api_call(url):
	response  = ""
	response_code = 0
	while (response == "" and response_code != 200):
		try:
			response = requests.get(url,timeout = 30)
			response_code = response.status_code
		except:
			log.error("API CALL TIME OUT. RETRYING ... ")
			time.sleep(300)
			#traceback.print_stack()
	return response

def get_url(url_user_id,url_location_id,url_date):
	return URL1+str(url_user_id)+URL2+str(url_location_id)+URL3+url_date

def increment_date(start_date):
	date = datetime.strptime(start_date, "%Y-%m-%d")
	modified_date = date + timedelta(days=1)
	start_date = datetime.strftime(modified_date, "%Y-%m-%d")
	return start_date

def parsing_poured_problem_data(hadoop_cursor,raw_dic,user_id,location_id,location_df,product_df,current_date):
	#print ("parsing problem")
	try:
		date = raw_dic['timekey']
		product_name = raw_dic['product']
		poured =  raw_dic['Poured']
		lineCleaning = raw_dic['lineCleaning']
		lineNo = raw_dic['lineNo']
		try:
			location_name = location_df.loc[location_df['id'] == int(location_id),'name'].iloc[0]
		except:
			location_name = ""
		try:
			product_id = product_df.loc[product_df['name'] == product_name,'id'].iloc[0]
		except:
			product_id = 0

		sold = '0'

		if(location_name == "" and product_id == 0):
			sql = "insert into "+PROBLEM_PRODUCT_TABLE+"(date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber,plu_size) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+",0,0)"
		elif (product_id == 0):
			sql = "insert into "+PROBLEM_PRODUCT_TABLE+"(date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber,plu_size) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+",0,0)"
		else:
			sql = "insert into "+PROBLEM_LOCATION_TABLE+"(date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber,plu_size) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+",0,0)"
		hadoop_cursor.execute(sql)
	except Exception as e:
		log.warning(e)
		pass

def parsing_sold_problem_data(hadoop_cursor,raw_dic,user_id,location_id,location_df,product_df,current_date):
	try:
		date = raw_dic['timekey']
		#user_id = dic['UserID']
		#location_id = dic['LocationID']
		product_name = raw_dic['product']
		sold =  raw_dic['Sold']
		lineCleaning = 0
		lineNo = 0
		quantity = raw_dic['quantity']
		pluNumber = raw_dic['pluNumber']
		try:
			location_name = location_df.loc[location_df['id'] == int(location_id),'name'].iloc[0]
		except:
			location_name = ""
		try:
			product_id = product_df.loc[product_df['name'] == product_name,'id'].iloc[0]
		except:
			product_id = 0
		poured = '0'

		if(location_name == "" and product_id == 0):
			#print ("Inserting into problem raw product table")
			sql = "insert into "+PROBLEM_PRODUCT_TABLE+"(date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber,plu_size) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+",0,0)"
		elif (product_id == 0):
			#print ("Inserting into problem raw product table")
			sql = "insert into "+PROBLEM_PRODUCT_TABLE+"(date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber,plu_size) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+",0,0)"
		else:
			#print ("Inserting into problem raw lcoation table")
			sql = "insert into "+PROBLEM_LOCATION_TABLE+"(date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber,plu_size) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+",0,0)"

		hadoop_cursor.execute(sql)
	except Exception as e:
		log.warning(e)
		pass

def parsing_Plu_problem_data(hadoop_cursor,plu_dic,user_id,location_id,location_df,product_df,current_date):
	try:
		#user_id = dic['UserID']
		#location_id = dic['LocationID']
		product_name = plu_dic['name']
		#print (product_name)
		plu_num=plu_dic["plu"]
		plu_size=plu_dic["size"]

		try:
			location_name = location_df.loc[location_df['id'] == int(location_id),'name'].iloc[0]
		except:
			location_name = ""

		try:
			product_id = product_df.loc[product_df['name'] == product_name,'id'].iloc[0]
		except:
			product_id = 0

		if(location_name == "" and product_id == 0):
			#print ("Inserting into problem plu product table")
			sql = "insert into "+PROBLEM_PRODUCT_PLU_TABLE+" (date,user_id,user_name,location_id,location_name,product_id,product_name,plu_num,plu_size) VALUES ('"+current_date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\","+str(plu_num)+",'"+plu_size+"')"
		elif (product_id == 0):
			#print ("Inserting into problem plu product table")
			sql = "insert into "+PROBLEM_PRODUCT_PLU_TABLE+" (date,user_id,user_name,location_id,location_name,product_id,product_name,plu_num,plu_size) VALUES ('"+current_date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\","+str(plu_num)+",'"+plu_size+"')"
		else:
			#print ("Inserting into problem plu location table")
			sql = "insert into "+PROBLEM_LOCATION_PLU_TABLE+" (date,user_id,user_name,location_id,location_name,product_id,product_name,plu_num,plu_size) VALUES ('"+current_date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\","+str(plu_num)+",'"+plu_size+"')"

		#print ("Cursor Generated "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f'))
		
		#print ("SQL quary generated"+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f'))
		hadoop_cursor.execute(sql)
	except Exception as e:
		log.warning(e)
		pass

def insertIntoProblemLocationTable(hadoop_cursor,data_json_obj,loop_name,user_id,location_id,location_df,product_df,current_date):
	if(loop_name == 'poured'):
		parsing_poured_problem_data (hadoop_cursor,data_json_obj,user_id,location_id,location_df,product_df,current_date)
	elif (loop_name == 'sold'):
		parsing_sold_problem_data(hadoop_cursor,data_json_obj,user_id,location_id,location_df,product_df,current_date)
	else:
		parsing_Plu_problem_data(hadoop_cursor,data_json_obj,user_id,location_id,location_df,product_df,current_date)
	

def poured_data_insert(connection_hadoop_internal,raw_poured_json_array,user_id,location_id,location_df,product_df,current_date):
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		for raw_dic in raw_poured_json_array:
			try:
				date = raw_dic['timekey']
				#user_id = dic['UserID']
				#location_id = dic['LocationID']
				product_name = raw_dic['product']
				poured =  raw_dic['Poured']
				lineCleaning = raw_dic['lineCleaning']
				lineNo = raw_dic['lineNo']
				location_name = location_df.loc[location_df['id'] == int(location_id),'name'].iloc[0]
				product_id = product_df.loc[product_df['name'] == product_name,'id'].iloc[0]
				sold = '0'
				sql = "insert into "+LINE_CLEANING_TABEL+" (date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+lineNo+",0,0)"
				hadoop_cursor.execute(sql)	
			except Exception as e:
				log.warning(e)
				insertIntoProblemLocationTable(hadoop_cursor,raw_dic,'poured',user_id,location_id,location_df,product_df,current_date)
				
							
	connection_hadoop_internal.commit()
	log.debug ("Insterted  pourd data in to db"+" Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))	

def sold_data_insert(connection_hadoop_internal,raw_sold_json_array,user_id,location_id,location_df,product_df,current_date):
	log.debug ("start sold data parsing Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))	
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		for raw_dic in raw_sold_json_array:
			try:				
				date = raw_dic['timekey']
				#user_id = dic['UserID']
				#location_id = dic['LocationID']
				product_name = raw_dic['product']
				sold =  raw_dic['Sold']
				lineCleaning = 0
				lineNo = 0
				quantity = raw_dic['quantity']
				pluNumber = raw_dic['pluNumber']
				location_name = location_df.loc[location_df['id'] == int(location_id),'name'].iloc[0]
				product_id = product_df.loc[product_df['name'] == product_name,'id'].iloc[0]
				poured = '0'
				sql = "insert into "+LINE_CLEANING_TABEL+" (date,user_id,user_name,location_id,location_name,product_id,product_name,poured,sold,line_cleaning,line_number,quantity,pluNumber) VALUES ('"+date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\",'"+poured+"','"+sold+"',"+str(lineCleaning)+","+str(lineNo)+","+str(quantity)+","+str(pluNumber)+")"
				hadoop_cursor.execute(sql)																			
			except Exception as e:
				log.warning(e)
				insertIntoProblemLocationTable(hadoop_cursor,raw_dic,'sold',user_id,location_id,location_df,product_df,current_date)
				#traceback.print_exc()
							
	connection_hadoop_internal.commit()
	log.debug ("Insterted sold data in to db Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

def plu_data_insert(connection_hadoop_internal,plu_data_json_obj,user_id,location_id,location_df,product_df,current_date):
	print ("start plu parsing Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
	print ("MySQL DB Connection cursor "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f'))
	with connection_hadoop_internal.cursor() as hadoop_cursor:
		for plu_dic in plu_data_json_obj:
			try:						
				#user_id = dic['UserID']
				#print (user_id)
				#location_id = dic['LocationID']
				product_name = plu_dic['name']
				plu_num=plu_dic["plu"]
				plu_num = plu_num.replace("$","")
				plu_size=plu_dic["size"]
				location_name = location_df.loc[location_df['id'] == int(location_id),'name'].iloc[0]
				product_id = product_df.loc[product_df['name'] == product_name,'id'].iloc[0]
				sql = "insert into "+LINE_CLEANING_PLU_TABEL+" (date,user_id,user_name,location_id,location_name,product_id,product_name,plu_num,plu_size) VALUES ('"+current_date+"',"+str(user_id)+",' ',"+str(location_id)+",\""+location_name+"\","+str(product_id)+",\""+product_name+"\","+str(plu_num)+",'"+plu_size+"')"
				hadoop_cursor.execute(sql)
			except Exception as e:
				log.warning(e)
				insertIntoProblemLocationTable(hadoop_cursor,plu_dic,'plu',user_id,location_id,location_df,product_df,current_date)
				#traceback.print_exc()
							
	connection_hadoop_internal.commit()
	log.info ("SQL quary commit"+ datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f'))			
	log.info ("Insterted plu data in to db Time: "+ datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

def insert_based_on_date():
	table_missing_bol = False
	start_date = START_DATE

	try:
		locid_userid_df = pd.read_csv(DIR_PATH+USERID_LOCATION_ID_CSV_FILE_NAME)
		location_df = pd.read_csv(DIR_PATH+LOCATION_CSV_FILE_NAME)
		product_df = pd.read_csv(DIR_PATH+PRODUCT_CSV_FILE_NAME)
	except:
		log.critical ("CSV File's missing")
		sys.exit(0)

	while (start_date != end_date):
		
		api_date = start_date
		log.info ("Date Range")
		log.info ("Start Date = "+start_date+"End Date = "+end_date)

		start_time_ = datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')
		log.info ("Start Time for  Date = "+start_date +" is "+start_time_)

		if (len(locid_userid_df) > 0 and len(product_df) > 0 and len(location_df) > 0):
			m = 0
			for index, dic in locid_userid_df.iterrows():
				try:
					connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
					if(connection_hadoop_internal != None):
						if(check_if_Table_exits(connection_hadoop_internal)!= True):
							log.error("TABLE DOES NOT EXIST'S IN THE DATABASE")
							table_missing_bol = True		
					else:
						table_missing_bol = True
						
					if (table_missing_bol != True):
						log.debug ("Conected to MySQLDB  "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%ms'))
						full_url = get_url(dic['UserID'],dic['LocationID'],api_date)
						log.debug ("Starting API Call"+" Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
						response = api_call(full_url)
						log.debug ("API call done Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

						data = response.json()
						raw_data_json_obj = data['Raw Data']
						raw_poured_json_array = raw_data_json_obj['poured']
						raw_sold_json_array = raw_data_json_obj['sold']
						plu_data_json_obj = data['PLU List']
						
						#file_log = open('log.txt','a+')
						#file_log.write("Log "+str(m)+": "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"API_DATE ="+api_date+" UserID="+str(dic['UserID'])+" LocationonID="+str(dic['LocationID'])+"\n")
						#file_log.close()
						log.debug ("Log "+str(m)+": "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')+"API_DATE ="+api_date+" UserID="+str(dic['UserID'])+" LocationonID="+str(dic['LocationID']))
						m += 1
						poured_data_insert(connection_hadoop_internal, raw_poured_json_array,dic['UserID'],dic['LocationID'],location_df,product_df,api_date)
						sold_data_insert(connection_hadoop_internal, raw_sold_json_array,dic['UserID'],dic['LocationID'],location_df,product_df,api_date)
						plu_data_insert(connection_hadoop_internal, plu_data_json_obj,dic['UserID'],dic['LocationID'],location_df,product_df,api_date)
									
						log.debug ("API Call result processed "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
					#time.sleep(30)
				except Exception as e:
					log.error(e)
					pass
				finally:
					if(connection_hadoop_internal != None): 
						connection_hadoop_internal.close()
					if (table_missing_bol == True):
						sys.exit(0)
						break
				
		else:
			log.error  ("CSV File's missing")

		start_date = increment_date(start_date)
		end_time_ = datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')
		log.info("End Time for  Date = "+start_date +" is "+end_time_)
		start_dt = datetime.strptime(start_time_, '%Y-%m-%d %H:%M:%S:%f')
		end_dt = datetime.strptime(end_time_, '%Y-%m-%d %H:%M:%S:%f')
		diff = (end_dt - start_dt)
		log.info("Duration = "+str(diff))
		if (table_missing_bol == True):
			break

def insert_based_on_location():
	table_missing_bol = False
	
	try:
		locid_userid_df = pd.read_csv(DIR_PATH+USERID_LOCATION_ID_CSV_FILE_NAME)
		location_df = pd.read_csv(DIR_PATH+LOCATION_CSV_FILE_NAME)
		product_df = pd.read_csv(DIR_PATH+PRODUCT_CSV_FILE_NAME)
	except:
		log.critical ("CSV File's missing")
		sys.exit(0)
	total_location = len(locid_userid_df)
	location_executiog = 0
	if (len(locid_userid_df) > 0 and len(product_df) > 0 and len(location_df) > 0):
		for index, dic in locid_userid_df.iterrows():
			start_date = START_DATE
			m = 1
			log.info ("Date Range")
			log.info ("Start Date = "+start_date+" End Date = "+end_date)
			start_time_ = datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')
			log.info ("Start Time for User id = "+str(dic['UserID'])+", User Name= "+dic['UserName']+", Location id= "+str(dic['LocationID']) +" and Location Name= "+dic['LocationName']+" is "+start_time_)
			try:
				connection_hadoop_internal = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
				if(check_if_Table_exits(connection_hadoop_internal)!= True):
					log.debug("TABLE DOES NOT EXIST'S IN THE DATABASE")
					table_missing_bol = True
					break
				if (table_missing_bol != True):
					while (start_date != end_date):
						log.debug ("API CAll")
						api_date = start_date
						log.debug ("Conected to MySQLDB  "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%ms'))
						full_url = get_url(dic['UserID'],dic['LocationID'],api_date)
						log.debug ("Starting API Call "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
						response = api_call(full_url)
						log.debug ("API call done "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

						data = response.json()
						raw_data_json_obj = data['Raw Data']
						raw_poured_json_array = raw_data_json_obj['poured']
						raw_sold_json_array = raw_data_json_obj['sold']
						plu_data_json_obj = data['PLU List']
						
						#file_log = open('log.txt','a+')
						#file_log.write("Log "+str(m)+": "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"API_DATE ="+api_date+" UserID="+str(dic['UserID'])+" LocationonID="+str(dic['LocationID'])+"\n")
						#file_log.close()
						log.debug ("Locations Compleated: "+str(location_executiog)+"/"+str(total_location))
						log.info ("Log "+str(m)+": "+"Time: "+datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')+" API_DATE ="+api_date+" User id = "+str(dic['UserID'])+", User Name= "+dic['UserName']+", Location id= "+str(dic['LocationID']) +" and Location Name= "+dic['LocationName'])
						m += 1
						poured_data_insert(connection_hadoop_internal, raw_poured_json_array,dic['UserID'],dic['LocationID'],location_df,product_df,api_date)
						sold_data_insert(connection_hadoop_internal, raw_sold_json_array,dic['UserID'],dic['LocationID'],location_df,product_df,api_date)
						plu_data_insert(connection_hadoop_internal, plu_data_json_obj,dic['UserID'],dic['LocationID'],location_df,product_df,api_date)
									
						log.info ("API Call result processed "+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))	
						time.sleep(45)
						start_date = increment_date(start_date)
			except Exception as e:
				log.error (e)
				#print ("Execption1")
				#traceback.print_exc()
				pass
			finally: 
				connection_hadoop_internal.close()

			end_time_ = datetime.now().strftime('%Y-%m-%d %H:%M:%S:%f')
			log.info ("End Time for User id = "+str(dic['UserID'])+" and Locationon id= "+str(dic['LocationID']) +" is "+end_time_)
			
			start_dt = datetime.strptime(start_time_, '%Y-%m-%d %H:%M:%S:%f')
			end_dt = datetime.strptime(end_time_, '%Y-%m-%d %H:%M:%S:%f')
			diff = (end_dt - start_dt)
			log.debug("Duration = "+str(diff))
			location_executiog += 1
			
	else:
		log.error ("CSV File's missing")

def main():
	#insert_based_on_date()
	insert_based_on_location()

if __name__ == '__main__':
	log.debug ("Exicuting the API data insert to MySQL python script")
	main()
				



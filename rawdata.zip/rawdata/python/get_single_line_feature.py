"""
Title: Execute All Features

Description: Takes the input dataframes from linecleaning_main.py and run all the features one by one 
			and pass the dataframe after adding each feature like( get_standard_deviation, get_sold_null,
			get_neighbourhood, get_linecleaning_location,get_multiday_issue, get_internet_issue, get_ideal_loss,
			check_one_hour_sold, get_missing_plu_fun, get_min_volume).
			After that return the dataframe with all the features to linecleaning_main.py.
"""

import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import traceback
import pandas as pd
from termcolor import colored
import datetime
from datetime import datetime, timedelta
import time as t
import json

FILE_FLAG=True
ERROR=""
try:
	from constants import *
except:
	log.error("constants.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", constants.py file not found."
	#print("linecleaning_location.py file not found.")

try:
	from linecleaning_common import *
except:
	log.error("linecleaning_common.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", linecleaning_common.py file not found."
		#print("linecleaning_common.py file not found.")

try:
	from logger_config import log
except:
	log.error("logger_config.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+" logger_config.py file not found."
	#print("linecleaning_location.py file not found.")
		
	
try:
	from standard_deviation import get_standard_deviation
except Exception as e:
	log.error("standerd_devation.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", standerd_devation.py file not found."


try:
	from sold_null import get_sold_null
except Exception as e:
	log.error("sold_null.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", sold_null.py file not found."

try:
	from linecleaning_location import get_linecleaning_location
except:
	traceback_print_exc()
	log.error("linecleaning_location.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", linecleaning_location.py file not found."
	#print("linecleaning_location.py file not found.")

try:
	from internet_issue_location import get_internet_issue
except Exception as e:
	log.error("internet_issue_location.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", internet_issue_location.py file not found."
	#print("linecleaning_location.py file not found.")

try:
	from neighbourhood import get_neighbourhood
except Exception as e:
	log.error("neighbourhood.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", neighbourhood.py file not found."

try:
	from multiday_issue import get_multiday_issue
except Exception as e:
	log.error("multiday_issue.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", multiday_issue.py file not found."

try:
	from check_one_hour_sold import check_one_hour_sold
except Exception as e:
	#print(e)
	log.error("check_one_hour_sold.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", check_one_hour_sold.py file not found."

try:
	from get_missing_plu import get_missing_plu_fun
except Exception as e:
	log.error("get_missing_plu.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", get_missing_plu.py file not found."


try:
	from ideal_loss import get_ideal_loss
except Exception as e:
	log.error("ideal_loss.py file not found.")
	FILE_FLAG=False
	ERROR=ERROR+", ideal_loss.py file not found."








### call all the features with all the dataframes like ( base_data_df,raw_data_df,raw_data_df_new,plu_data_df)
### and with start_date,end_date
def single_line_feature_main(base_data_df,raw_data_df,raw_data_df_new,plu_data_df,start_date_sys,end_date_sys):
	
	single_line_df= base_data_df.reset_index(drop=True)
	single_line_df=single_line_df.rename(columns={'location_id':'loc_id','location_name':'loc_name','product_id':'prod_id','product_name':'prod_name'})
	single_line_df=single_line_df.sort_values(by=['date','time'],ascending=True)
	# print(single_line_df)
	

	# calling get_standard_deviation module to calculate the weights of standard deviation for the base_dataframe 
	start_time1 = t.time()
	log.info("Analysing for standard deviation")
	single_line_df, resp = get_standard_deviation(single_line_df)		
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))

	# calling get_sold_null module to calculate the weights of sold data for the base_dataframe 
	start_time1 = t.time()
	log.info("Analysing for sold null")
	single_line_df , resp= get_sold_null(single_line_df)		
	#print(single_line_df)
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	
	# calling get_neighbourhood module to calculate the weights of neighbourhoods of maximum for the base_dataframe 
	start_time1 = t.time()
	log.info("Analysing for neighbourhood")
	single_line_df, resp = get_neighbourhood(single_line_df)
	
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))		
	
	# calling get_linecleaning_location module to calculate the weights for the base_dataframe by comparing with corresponding location spikes or linecleanings 
	start_time1 = t.time()
	log.info("Analysing location for linecleaning")
	single_line_df , resp= get_linecleaning_location(single_line_df)		
	
	#print(single_line_df)
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	

	# calling get_multiday_issue module to calculate the weights for the base_dataframe by comparing with corresponding multiday spikes
	start_time1 = t.time()
	log.info("Analysing for multiday issue")
	single_line_df, resp = get_multiday_issue(single_line_df)
	
	#base_data_df = compare_location_and_multiday(base_data_df)
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	
	
	# calling get_internet_issue module to calculate the weights for the base_dataframe by comparing with corresponding internet issue spikes
	start_time1 = t.time()
	log.info("Analysing for internet issue")
	single_line_df, resp = get_internet_issue(single_line_df)
	
	# print(single_line_df)	
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	

	# calling get_ideal_loss module to calculate the weights for the base_dataframe by comparing with corresponding ideal loss spikes
	start_time1 = t.time()
	log.info("Analysing for ideal loss")
	single_line_df, resp = get_ideal_loss(single_line_df,raw_data_df_new,start_date_sys,end_date_sys)
	
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	# single_line_df.to_csv('./'+str(single_line_df.loc[0,"loc_id"])+'_dump1.csv',index = False)
	# sys.exit()
	
	# calling check_one_hour_sold module to calculate the weights for the base_dataframe by checking that there is sold data or not in that 1 hour.
	start_time1 = t.time()
	log.info("Analysing for One hour sold feature")
	single_line_df, resp = check_one_hour_sold(single_line_df)
	
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	
	# calling get_missing_plu_fun module to calculate the weights for the base_dataframe by checking that there is plu missing or not for products.
	start_time1 = t.time()
	log.info("Analysing for plu issue")
	single_line_df , resp= get_missing_plu_fun(raw_data_df,plu_data_df,single_line_df)
	log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	
	# # calling get_min_volume module to calculate the weights for the base_dataframe by checking that the amount of poured is greater than the cut off or not.
	# start_time1 = t.time()
	# log.info("Analysing for minimum volume")
	# single_line_df , resp= get_min_volume(single_line_df)
	# log.info("%.3f s with %s \n" % ((t.time() - start_time1),resp))
	
	
	
	return single_line_df, resp


### call the single_line_feature_main function with all the dataframes
def get_single_line_feature(base_data_df,raw_data_df,raw_data_df_new,plu_data_df,start_date_sys,end_date_sys):
	if FILE_FLAG==True:
		single_line_df,res_str=single_line_feature_main(base_data_df,raw_data_df,raw_data_df_new,plu_data_df,start_date_sys,end_date_sys)
		return single_line_df, res_str
	else:
		# print(FILE_FLAG, ERROR)
		return None, ERROR

"""
Title: Multiday feature

Description: Computes multiday at the product level. 
Algorithm: Checked for each datapoint that the datapoint belongs to multiday issue or not.
			Ckecked with the 10 datapoints forward and backward that the points are having the sold data or not. 
"""


import sys
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
import requests
import time as t
import random
import json
import csv
import pandas as pd
import datetime
import traceback
from datetime import datetime, time
from termcolor import colored
import os, inspect
from logger_config import log
try:
	from constants import *
except:
	log.error("constants.py file not found.")
	#print("linecleaning_location.py file not found.")
	sys.exit()



# Computing the multiday issue feature for a spike datapoint 
# by checking forward and backward of that datapoint 
# we check till the sold data comes or a limit of 9 datapoints with only poured data and no sold data
# and assigning the highest weight to datapoint as a multiday issue
def compute_multiday_feature(df_multiday_local2,data_point):
	#print(df_multiday_local2)
	#print(data_point)
	if df_multiday_local2.loc[data_point,"sold"]==0:
		
		prev_flag=True
		nxt_flag=True
		count_prev=0
		count_nxt=0
		for j in range(0,len(df_multiday_local2)):
			prev=int(data_point-j)
			nxt=int(data_point+j)
			#print("...it is j",str(int(latest_i-j)))
			
			if prev_flag==True:
				#print("prev=",prev)
				if prev!=0 and df_multiday_local2.loc[prev-1,"sold"]==0:
					#print("prev======",prev)
					count_prev+=1
					if count_prev > MULTIDAY_LIMIT_CHECK:
						df_multiday_local2.loc[data_point,"mult_f"]=LINECLEANING_W_MULTIDAY_MAIN
						df_multiday_local2.loc[data_point,"weight"]-=LINECLEANING_W_MULTIDAY_MAIN
						# print(df_multiday_local2.loc[data_point,"mult_f"])
						# print("date and time==",df_multiday_local2.loc[data_point,"date"],df_multiday_local2.loc[data_point,"time"])
						# print("weight changed in prev............")
						prev_flag=False

				elif prev==0 or df_multiday_local2.loc[prev-1,"sold"]!=0:
					# print("prev flag is False")
					prev_flag=False
					# print("prev flag becomes False")
					#break
			else:
				pass

			if nxt_flag==True:
				#print("nxt==",nxt)
				#print("length=",(len(df_multiday_local2)-1))
				if nxt!=(len(df_multiday_local2)-1) and df_multiday_local2.loc[nxt+1,"sold"]==0:
					count_nxt+=1
					#print("count===",count_nxt)
					if count_nxt > MULTIDAY_LIMIT_CHECK:
						df_multiday_local2.loc[data_point,"mult_f"]=LINECLEANING_W_MULTIDAY_MAIN
						df_multiday_local2.loc[data_point,"weight"]-=LINECLEANING_W_MULTIDAY_MAIN
						# print(df_multiday_local2.loc[data_point,"mult_f"])
						# print("date and time==",df_multiday_local2.loc[data_point,"date"],df_multiday_local2.loc[data_point,"time"])
						# print("weight changed in next.............")
						nxt_flag=False
				elif nxt==(len(df_multiday_local2)-1) or df_multiday_local2.loc[nxt+1,"sold"]!=0:
					# print("next flag is False")
					nxt_flag=False
					# print("next flag becomes False")

			else:
				pass

			if (count_nxt+count_prev)>MULTIDAY_LIMIT_CHECK:
				df_multiday_local2.loc[data_point,"mult_f"]=LINECLEANING_W_MULTIDAY_MAIN
				df_multiday_local2.loc[data_point,"weight"]-=LINECLEANING_W_MULTIDAY_MAIN
				#print(count_nxt,count_prev,LINECLEANING_LIMIT_CHECK_MAIN)
				#print("weight increased here...",df_multiday_local2.loc[data_point,"mult_f"])
				break
			elif prev_flag==False and nxt_flag==False:
				#print("Both False")
				break
			else:
				#print("in new else")
				#print("prev flag",prev_flag)
				#print("nxt flag", nxt_flag)
				pass

		return df_multiday_local2
	else:
		#print("weight.............",df_multiday_local2.loc[data_point,"mult_f"])
		return df_multiday_local2



def multiday_main(base_data_df):
	try:
		#print ("Analysing multiday issue for "+sys.argv[1]+"")
		#log.info("Analysing multiday issue for "+sys.argv[1]+"")
		pd.set_option('expand_frame_repr', False)

		result_df=pd.DataFrame()
		prod_uniq=base_data_df["prod_id"].unique()
		for prod in prod_uniq:
			df_multiday=base_data_df[base_data_df["prod_id"]==prod]
			df_multiday=df_multiday.sort_values(by=['date','time'],ascending=True)
			df_multiday=df_multiday.reset_index(drop=True)
			
			df_multiday["mult_f"]= 0
			for i in range(0,len(df_multiday)):
				if df_multiday.loc[i,"loc_f"]==0:												### To run the multiday at product when location feature is not there
					df_multiday=compute_multiday_feature(df_multiday,i)
			
			#print(df_multiday)
			
			#print(df_multiday)
			result_df=result_df.append(df_multiday)
			# print("prod: ",prod)
			# if prod==35239:
			# 	sys.exit()
		# result_df=result_df.sort_values(by=['date','time'])
		result_df=result_df.reset_index(drop=True)
		#log.info(result_df)
		return result_df, "Success"
	except Exception as e:
		log.error(str(e))
		return base_data_df, str(e)

	
	
def get_multiday_issue(base_data_df):
	return multiday_main(base_data_df)
import requests
import sys
import pymysql.cursors
import time as t
from time import sleep
import datetime
from datetime import datetime, time
from flask import Flask, render_template, request,Response,redirect,url_for,Markup,jsonify
from termcolor import colored
import os, inspect
from datetime import date, timedelta
from logger_config import log
from operator import itemgetter
import pandas as pd
import json

app = Flask(__name__)

#-----------Checking Database available or not  ----------             
def check_if_DB_exists(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '"+MY_SQL_DB_NAME+"';"
			hadoop_cursor.execute(sql)
			db_check_result = hadoop_cursor.fetchone()
			return db_check_result
	except:
		return None

    
#-----------Checking table available or not  ----------             
def check_if_Table_exits(connection_to_db):
	try:
		with connection_to_db.cursor() as hadoop_cursor:
			sql_query = "desc "+LOCATION_DATE_TABLE+" ;"
			hadoop_cursor.execute(sql_query)
			table_check_result = hadoop_cursor.fetchone()
			return True
	except Exception as e:
		log.error(e)
		traceback.print_stack()
		return False


#-----------Connecting to database server ----------    
def connect_to_db(host,user,password,db):
	try:
		connection_hadoop_internal = pymysql.connect(host=host,
	                             user=user,
	                             password=password,
	                             db=db,
	                             charset='utf8mb4',
	                             cursorclass=pymysql.cursors.DictCursor)

		return connection_hadoop_internal
	except Exception as e:
		print(e)
		return " "

    
#-----------Checking connection established or not  ----------                 
def check_connection(host,user,password):
	connection_hadoop_check = 0
	while (connection_hadoop_check==0):
		try:
			connection_hadoop_check = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)
		except Exception as e:
			log.error(e)
			t.sleep(30)
	return connection_hadoop_check


def get_tables(connection_hadoop_internal,db):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql="SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE  TABLE_SCHEMA='"+db+"'"
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall()
			response_code=sorted(list(pd.DataFrame(response_code)['TABLE_NAME'])) if(len(response_code)>0) else []
			return response_code
	except Exception as e :
		print(e)
		return "[]"


def get_database(connection_hadoop_internal):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql="SHOW DATABASES;"
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall()
			response_code=response_code if(len(response_code)>1) else []
			return response_code
	except Exception as e :
		print(e)
		return "[]"

# def convert_markup_tables(json_,param):
# 	res_tags="<option value='"+param+"' selected='selected' >"+param+"</option>"
# 	for table in json_:
# 		res_tags=res_tags+"<option value='"+str(table[param])+"' >"+str(table[param])+"</option>"
# 	return Markup(res_tags)


def set_graph_content(connection_hadoop_internal,search_dic):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			table=str(search_dic['table'])
			param1=str(search_dic['xaxis'])
			param2=str(search_dic['yaxis'])
			sql="select "+param1+","+param2 +" from "+table
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall() 
			return get_formated_array(response_code,param1,param2)
	except Exception as e:
		print(e)
		return []	


def get_formated_array(response_code,param1,param2):
	res_array=[]
	for row in response_code:
		try:
			ind_array=[]
			ind_array.append(float(row[param1])) if(str(row[param1])!='None') else ind_array.append(0.0)
			ind_array.append(float(row[param2])) if(str(row[param2])!='None') else ind_array.append(0.0)
			res_array.append(ind_array)
		except Exception as e:
			print(e)
	return res_array


def get_int_fields(connection_hadoop_internal,table,param):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql="SELECT distinct(COLUMN_NAME) FROM information_schema.columns WHERE TABLE_NAME = '"+table+"' and DATA_TYPE in ('int','float') and COLUMN_NAME!='"+param+"'"
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall() 
			response_code=list(pd.DataFrame(response_code)['COLUMN_NAME']) if(len(response_code)>0) else []
			return response_code
	except Exception as e:
		print(e)
		return []	


def get_row(connection_hadoop_internal,table,param1,param2,p1,p2):
	try:
		with connection_hadoop_internal.cursor() as hadoop_cursor:
			sql="SELECT * from "+table+" where "+param1+" like "+p1+" and "+param2+" like "+p2
			hadoop_cursor.execute(sql)
			response_code = hadoop_cursor.fetchall() 
			return response_code
	except Exception as e:
		print(e)
		return []	


# #-----------Flask Starts Here ----------         
@app.route("/")
def index():
	try:
		return render_template("scatter.html",xaxis=Markup("<option value='xaxis' selected='selected' >xaxis</option>"),yaxis=Markup("<option value='yaxis' selected='selected' >yaxis</option>"),table=Markup("<option value='TABEL' selected='selected' >TABEL</option>"),dataase=Markup("<option value='DATABASE' selected='selected' >DATABASE</option>"))	
	except Exception as e:
		return 'something went wrong'+str(e)


@app.route("/Execute", methods = ['POST'])
def Execute(): 
	try:
		# print(request.form)
		search_dic=request.form
		if('table' in search_dic and 'database' in search_dic and 'xaxis' in search_dic and 'yaxis' in search_dic):
			if(str(search_dic['database'])!='Database' and str(search_dic['table'])!='TABEL' and str(search_dic['xaxis'])!='xaxis' and str(search_dic['yaxis'])!='yaxis'):
				connection_hadoop_internal = connect_to_db(search_dic['host_name'],search_dic['user'],search_dic['password'],str(request.form['database']))
				return render_template('graph.html',res_=Markup(set_graph_content(connection_hadoop_internal,search_dic)),x_title=Markup(str(search_dic['xaxis'])), y_title=Markup(str(search_dic['yaxis'])),title=Markup("'"+str(search_dic['yaxis'])+" v/s "+str(search_dic['xaxis'])+"'"),table=Markup(str(request.form['table'])),db=Markup(str(request.form['database'])),host_name=str(search_dic['host_name']),user=str(search_dic['user']),password=str(search_dic['password']))
			else:
				return 'select all parameters'
		else:
			return 'select all parameters'
	except Exception as e:
		print(e)
		return  str(e)


@app.route('/TABELS', methods=["GET", "POST"])
def TABELS():
	try:
		# print(str(request.form))
		MY_SQL_DB_NAME=str(request.form['database'])
		# print(request.form['host'],request.form['user'],request.form['password'],MY_SQL_DB_NAME)
		connection_hadoop_internal = connect_to_db(request.form['host_name'],request.form['user'],request.form['password'],MY_SQL_DB_NAME)
		return jsonify(get_tables(connection_hadoop_internal,MY_SQL_DB_NAME))
	except Exception as e:
		print(e)
		return str(e)


@app.route('/INT_FILED', methods=["GET", "POST"])
def INT_FILED():
	try:
		MY_SQL_DB_NAME=str(request.form['database'])
		connection_hadoop_internal = connect_to_db(request.form['host_name'],request.form['user'],request.form['password'],MY_SQL_DB_NAME)
		return jsonify(get_int_fields(connection_hadoop_internal,str(request.form['table']),''))
	except Exception as e:
		print(e)
		return str(e)


@app.route('/yaxis', methods=["GET", "POST"])
def yaxis():
	try:
		MY_SQL_DB_NAME=str(request.form['database'])
		connection_hadoop_internal = connect_to_db(request.form['host_name'],request.form['user'],request.form['password'],MY_SQL_DB_NAME)
		return jsonify(get_int_fields(connection_hadoop_internal,str(request.form['table']),str(request.form['xaxis'])))
	except Exception as e:
		print(e)
		return str(e)		


@app.route('/GET_ROW', methods=["GET", "POST"])
def GET_ROW():
	try:
		search_dic=request.form
		MY_SQL_DB_NAME=str(search_dic['db'])
		connection_hadoop_internal = connect_to_db(request.form['host_name'],request.form['user'],request.form['password'],MY_SQL_DB_NAME)
		return str(get_row(connection_hadoop_internal,str(search_dic['table']),str(search_dic['x']),str(search_dic['y']),str(search_dic['x_axis']),str(search_dic['y_axis'])))
	except Exception as e:
		print(e)
		return str(e)	


@app.route('/FILL_DB', methods=["GET", "POST"])
def FILL_DB():
	try:
		dic=request.form
		MY_SQL_HOST_NAME = str(dic['host_name'])
		MY_SQL_USER_NAME = str(dic['user'])
		MY_SQL_PASSWORD = str(dic['password'])
		connection_hadoop_internal = connect_to_db(str(dic['host_name']),str(dic['user']),str(dic['password']),"")
		if(str(connection_hadoop_internal) != " "):
			l=get_database(connection_hadoop_internal)
			return jsonify([d['Database'] for d in l])
		else:
			return "Check"
	except Exception as e:
		print(e)
		return str(e)	


if __name__ == "__main__":
	app.run(host='0.0.0.0' ,port=89)


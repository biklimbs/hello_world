import os,sys
import pandas as pd
sys.path.append('/usr/local/lib/python3.5/dist-packages')
import pymysql.cursors
from time import sleep
from datetime import datetime
import requests 
import re
from logger_config import *
import logger_config
from termcolor import colored
import random
import math

#---Server credentials---
HOST= "spark.vmokshagroup.com"
USER="root"
PASSWORD="Vmmobility@1234"
SOURCE_DATABASE='avtojp_pipeline'

#---DB TABLE NAMES---
MAKE_MODEL_TABLE='make_model_non_uss'
DOWNLOAD_PLAN_TABLE="download_plan_3_months"

#---Time Delay---
MIN_MODEL_DELAY=900
MAX_MODEL_DELAY=1800

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#---SQL queries---
MAKE_MODEL_QUERY="SELECT * FROM "+MAKE_MODEL_TABLE+" where download_flag=0 and download_fail=0"

#---Connection to "DATABASE_Exception"---
def connect_to_db(database_name):
	connection = pymysql.connect(host=HOST,
                                     user=USER,
                                     password=PASSWORD,
                                     db=database_name,
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)
	return connection

#---Read the data from  table in the db---
def read_data_from_db(connection,sql_query):
	with connection.cursor() as cursor:
		try:
			sql=sql_query
			#print(sql)
			cursor.execute(sql)
			if cursor.rowcount > 0:
				df=pd.DataFrame(cursor.fetchall())
				return df
			else:
				print("Empty Results")	
		except Exception as e:
			log.error(e)

def generate_query(min_offset,max_offset,make,model):
    '''
    This function generates query
    '''
    query="http://75.125.226.218/xml/json?&ip=10.10.0.0&code=y19Hfrte_Dm&sql=select+*+from+stats+where+MARKA_NAME%3D%27"+make+"%27+and+MODEL_NAME%3D%27"+model+"%27"+"and+AUCTION+not+like+%27USS%25%27+LIMIT+"+str(min_offset)+"%2C+"+str(max_offset)
    return query

def get_query(df):
    '''
    This function takes the count of make,model and returns a query along with offset
    '''
    #get_count_=int(str(get_count(marka,model)[0]['TAG0']))
    for index,row in df.iterrows():
        get_count_=df.at[index,"count"]
        
        if(get_count_>250):
            try:
                count = get_count_/250
                loop_int=math.ceil(count)
                st_limt=0
                end_limt=0
                for let in range(loop_int):
                    st_limt=st_limt
                    end_limt=250
                    query=generate_query(st_limt,end_limt,str(df.at[index,"make"]),df.at[index,"model"])
                    insert_into_db(str(df.at[index,"make"]),str(df.at[index,"model"]),get_count_,query)
                    st_limt=st_limt+250
            except Exception as e:
                log.error(e)
        else:
            try:
                st_limt=0
                end_limt=250
                query=generate_query(st_limt,end_limt,str(df.at[index,"make"]),df.at[index,"model"])
                insert_into_db(str(df.at[index,"make"]),str(df.at[index,"model"]),get_count_,query)
            except Exception as e:
                log.error(e)

#---Inserts into database---
def insert_into_db(make,model,count,query):
    connection=connect_to_db(SOURCE_DATABASE)
    local_time=datetime.now().strftime ("%Y-%m-%d %H:%M:%S")
    with connection.cursor() as cursor:
        try:			                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
            #---change table name in which you want to update---                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
            sql = "INSERT INTO "+DOWNLOAD_PLAN_TABLE+" (`make`, `model`, `count`, `query`, `local_date`, `download_flag`, `download_fail`) values(%s,%s,%s,%s,%s,%s,%s)"
            data=(make,model,str(count),query,str(local_time),str(0),str(0))
            cursor.execute(sql,data)
            connection.commit()
            log.info(colored("Inserting data","yellow"))
        except pymysql.err.IntegrityError as e:
            log.error("duplicate key: "+str(e))
        except Exception as e:
            log.error(str(e))	
    connection.close()
    return "updated Successfully"
#---Main function---
def main():
    connection=connect_to_db(SOURCE_DATABASE)
    df=read_data_from_db(connection,MAKE_MODEL_QUERY)
    get_query(df)
    connection.close()

#---Main function called---
if __name__=="__main__":
    main()
    
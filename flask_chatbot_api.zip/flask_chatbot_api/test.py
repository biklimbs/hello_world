import json
#---Returns all distinct rate---
def get_all_rate(mileage):
    mileage_low=0
    mileage_high=0
    mileage=int(mileage)
    if mileage<20000:
        mileage_low=0
        mileage_high=20000
    elif (mileage>=20000 and mileage<30000):
        mileage_low=20000
        mileage_high=30000
    elif (mileage>=30000 and mileage<40000):
        mileage_low=30000
        mileage_high=40000
    elif (mileage>=40000 and mileage<50000):
        mileage_low=40000
        mileage_high=50000
    elif (mileage>=50000 and mileage<60000):
        mileage_low=50000
        mileage_high=60000
    elif (mileage>=60000 and mileage<70000):
        mileage_low=60000
        mileage_high=70000
    elif (mileage>=70000 and mileage<80000):
        mileage_low=70000
        mileage_high=80000
    elif (mileage>=80000 and mileage<90000):
        mileage_low=80000
        mileage_high=90000
    elif (mileage>=90000 and mileage<100000):
        mileage_low=90000
        mileage_high=100000
    elif (mileage>=100000 and mileage<110000):
        mileage_low=100000
        mileage_high=110000
    elif (mileage>=110000 and mileage<120000):
        mileage_low=110000
        mileage_high=120000
    elif (mileage>=120000 and mileage<130000):
        mileage_low=120000
        mileage_high=130000
    elif (mileage>=130000 and mileage<140000):
        mileage_low=130000
        mileage_high=140000
    elif (mileage>=140000 and mileage<150000):
        mileage_low=140000
        mileage_high=150000
    elif (mileage>=140000 and mileage<150000):
        mileage_low=140000
        mileage_high=150000
    elif (mileage>=150000 and mileage<160000):
        mileage_low=150000
        mileage_high=160000
    elif (mileage>=160000):
        mileage_low=160000
        mileage_high=mileage
    '''
    elif (mileage>160000 and mileage<170000):
        mileage_low=160000
        mileage_high=170000
    elif (mileage>170000 and mileage<180000):
        mileage_low=170000
        mileage_high=180000
    elif (mileage>180000 and mileage<190000):
        mileage_low=180000
        mileage_high=190000
    elif (mileage>190000 and mileage<200000):
        mileage_low=190000
        mileage_high=200000
    elif (mileage>200000 and mileage<210000):
        mileage_low=200000
        mileage_high=210000
    elif (mileage>210000 and mileage<220000):
        mileage_low=210000
        mileage_high=220000
    elif (mileage>220000 and mileage<230000):
        mileage_low=220000
        mileage_high=230000
    elif (mileage>230000 and mileage<240000):
        mileage_low=230000
        mileage_high=240000
    elif (mileage>240000 and mileage<250000):
        mileage_low=240000
        mileage_high=250000
    elif (mileage>250000 and mileage<260000):
        mileage_low=250000
        mileage_high=260000
    elif (mileage>260000 and mileage<270000):
        mileage_low=260000
        mileage_high=270000
    elif (mileage>270000 and mileage<280000):
        mileage_low=270000
        mileage_high=280000
    elif (mileage>280000 and mileage<290000):
        mileage_low=280000
        mileage_high=290000
    elif (mileage>290000 and mileage<300000):
        mileage_low=290000
        mileage_high=300000
    elif (mileage>300000 and mileage<310000):
        mileage_low=300000
        mileage_high=310000
    elif (mileage>310000 and mileage<320000):
        mileage_low=310000
        mileage_high=320000
    elif (mileage>320000 and mileage<330000):
        mileage_low=320000
        mileage_high=330000
    elif (mileage>330000 and mileage<340000):
        mileage_low=330000
        mileage_high=340000
    elif (mileage>340000 and mileage<350000):
        mileage_low=340000
        mileage_high=350000
    elif (mileage>350000 and mileage<360000):
        mileage_low=350000
        mileage_high=360000
    elif (mileage>360000 and mileage<370000):
        mileage_low=360000
        mileage_high=370000
    elif (mileage>370000 and mileage<380000):
        mileage_low=370000
        mileage_high=380000
    elif (mileage>380000 and mileage<390000):
        mileage_low=380000
        mileage_high=390000
    elif (mileage>390000 and mileage<400000):
        mileage_low=390000
        mileage_high=400000
    elif (mileage>400000 and mileage<410000):
        mileage_low=400000
        mileage_high=410000
    elif (mileage>410000 and mileage<420000):
        mileage_low=410000
        mileage_high=420000
    elif (mileage>420000 and mileage<430000):
        mileage_low=420000
        mileage_high=430000
    elif (mileage>430000 and mileage<440000):
        mileage_low=430000
        mileage_high=440000
    elif (mileage>440000 and mileage<450000):
        mileage_low=440000
        mileage_high=450000
    elif (mileage>450000 and mileage<460000):
        mileage_low=450000
        mileage_high=460000
    elif (mileage>460000 and mileage<470000):
        mileage_low=460000
        mileage_high=470000
    elif (mileage>470000 and mileage<480000):
        mileage_low=470000
        mileage_high=480000
    elif (mileage>480000 and mileage<490000):
        mileage_low=480000
        mileage_high=490000
    elif (mileage>490000 and mileage<500000):
        mileage_low=490000
        mileage_high=500000
    '''
    return mileage_low,mileage_high


##---Returns mileage range based on the selected option---
def select_rating(input_option):
    #input_option
    switcher = { 
        
        "R": "Damaged and repair", 
        "RA": "Minor Damaged and repair",
        "1": "Flood damage", 
        "2": "Bad condition ", 
        "3": "Many exterior scratches", 
        "3.5": "Noticeable large scratches",
        "4": "<150000km", 
        "4.5": "<100,000km", 
        "5": "<50,000km.",
        "6": "<30,000km 36 months",
        "s": "<10,000km 12 months", 
    }
    try:
        return switcher[input_option],True
    except Exception as e:
        return str(e),False

def map_rating(input_option):
    switcher = { 
        'a': ["s","6","5"], 
        'b': ["4.5","4","3.5"],
        'c': ["3"], 
        'd': ["RA","R"]   
    }
    try:
        return switcher[input_option]
    except Exception as e:
        return str(e)


input_option='c'
print(map_rating(input_option))
'''
test_str="20001 and 30000"
print(test_str)
print(test_str.replace("and","-").split("-"))


#---Replace single quote to double quote---
def replace_quote(temp):
    temp="\""+temp+"\""
    return temp

list_1=['3.5','4','r']
print(json.dumps(list_1))
#print(list(map(replace_quote,list_1)))
'''

switcher = { 
        1: "0 and 30000", 
        2: "30001 and 60000", 
        3: "60001 and 90000",
        4: "90001 and 120000", 
        5: ">160000" 
    }

print(5)
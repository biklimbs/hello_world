from flask import Flask,render_template,request,make_response,jsonify
import random
from total_car_count import *
import flask
app = Flask(__name__)

#---Global variable---
make_g=""
model_g=""
year_g=""
low_mileage_g=0
high_mileage_g=0
rate_g=[]
kuzov_g=""

# print(make_name)

# function for responses
def results():
    # build a request object
    req = request.get_json(force=True)

    # fetch action from json
    action = req.get('queryResult').get('number')
    print("request from chatbot: "+str(req))
    print("entity :"+str(action))
    # return a fulfillment response
    rand_num=str(random.randint(0, 10))
    print(rand_num)
    #rand_num_dict={}
    #rand_num_dict["rand_num"]=rand_num
    return {'fulfillmentText': str(rand_num)}


def total_car_count():
    # build a request object
    req = request.get_json(force=True)
    # fetch action from json
    action = req.get('queryResult').get('number')
    print("request from chatbot: "+str(req))
    print("entity :"+str(action))
    # return a fulfillment response
    rand_num=str(random.randint(50000,75000))
    print(rand_num)
    #rand_num_dict={}
    #rand_num_dict["rand_num"]=rand_num
    return {'fulfillmentText': str(rand_num)}



# create a route for webhook
@app.route('/webhook', methods=['GET', 'POST'])
def webhook():
    global make_g,model_g,year_g,rate_g,low_mileage_g,high_mileage_g,kuzov_g
    # make_name= "vikas"
    req = request.get_json(silent=True)
    #print(make_name)
    print(req)
    intend_name=req.get('queryResult').get('intent').get('displayName')
    if str(intend_name)=='welcome':
        #make=req.get('queryResult').get('parameters').get('make')[0]
        #model=req.get('queryResult').get('parameters').get('model')[0]
        #print(make,model)
        #make_name= make
        #print(make_name)

        total_vehicle_count=get_total_count()
        welcome_text="Welcome to AutoWorldJapan. Today we have "+str(total_vehicle_count)+" vehicle in auction. Do you want us to show what we have.\n https://images.unsplash.com/photo-1518001589401-1743b61d1def?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1000&q=80"
        print(welcome_text)
        res_str={'fulfillmentText': str(welcome_text)}

    elif str(intend_name)=='first_customer_interaction':
        #make_name=req.get('queryResult').get('parameters').get('make')[0]
        #print(make_name)
        #make_g=make_name
        make_list="These are the available Makes for auction: "+str(get_all_make())
        #make_list=get_all_make()
        res_str={'fulfillmentText': str(make_list)}

    elif str(intend_name)=='make':
        make_name=req.get('queryResult').get('parameters').get('make')[0]
        print(make_name)
        make_g=make_name
        model_list=get_all_model(make_name)
        #make_list=get_all_make()
        res_str={'fulfillmentText': str(model_list)}
    
    elif str(intend_name)=='model': 
        #make_name=req.get('queryResult').get('parameters').get('make')
        #print(make_name)
        model_name=req.get('queryResult').get('parameters').get('model')[0]
        model_g=model_name
        year_list=get_all_years(make_g,model_name)
        res_str={'fulfillmentText': str(year_list)}

        #model_list=get_all_model(make_name)
        #res_str={'fulfillmentText': str(model_list)}
    
    elif str(intend_name)=='year': 
        #print(make_name)
        #make_name=req.get('queryResult').get('parameters').get('make')
        #model_name=req.get('queryResult').get('parameters').get('model')
        year_g=req.get('queryResult').get('parameters').get('year')[0]
        print(make_g,model_g,year_g)
        year_list=get_all_mileage(make_g,model_g,year_g)
        res_str={'fulfillmentText': str(year_list)}
    
    
    elif str(intend_name)=='mileage': 
        #print(make_name)
        #make_name=req.get('queryResult').get('parameters').get('make')
        #model_name=req.get('queryResult').get('parameters').get('model')
        mileage_g=req.get('queryResult').get('parameters').get('mileage')[0]
        if make_g!='' and model_g!='':
            print(make_g,model_g,mileage_g)
            mileage_list,low_mileage_g,high_mileage_g=get_all_rate(make_g,model_g,mileage_g)
        else:
            mileage_list="please supply valid make and models"
        res_str={'fulfillmentText': str(mileage_list)}
    
    elif str(intend_name)=='rating': 
        #print(make_name)
        rating_g=req.get('queryResult').get('parameters').get('rating')
        rating_str="you have selected following rating: "+str(rating_g)
        res_str={'fulfillmentText': str(rating_str)}

    elif str(intend_name)=='average_price': 
        if make_g!='' and model_g!='' and str(year_g)!='':
            response_dict=call_bid_lambda("ARU","6","1",make_g,model_g,year_g,"2018","","8PBLR",[],[],rate_g,[])
            d = json.loads(response_dict)
            price="The price is "+str(d["price"])
            res_str={'fulfillmentText': str(price)}
        else:
            mileage_list="please supply valid make and models"
            res_str={'fulfillmentText': str(mileage_list)}
    else:
        res_str={'fulfillmentText': str("Sorry intend could not be identified")}
    return make_response(jsonify(res_str))
    


# create a route for webhook
@app.route('/total_car_in_auction', methods=['GET', 'POST'])
def total_car_in_auction():
    # return response
    
    res_str=total_car_count()
    print("Response to chatbot: "+str(res_str))
    return make_response(jsonify(res_str))

@app.route('/get_total_count')
def get_total_car_count():
    df=get_total_count()
    return "Total car: "+str(df.iloc[0,0])


def get_make_model_count(make,model):
    try:
        df=get_make_model_total_count(make,model)
        return "Total car for "+make+" "+model+": "+str(df.iloc[0,0])
    except Exception as e:
        print(str(e))


'''
# create a route for webhook
@app.route('/model_count', methods=['GET', 'POST'])
def total_car_in_auction():
    # return response
    
    res_str=total_car_count()
    print("Response to chatbot: "+str(res_str))
    return make_response(jsonify(res_str))
'''
#---function starts here---
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=89)
marka_name="hello"
def get_total_car_count():
    global marka_name
    print(marka_name)
    marka_name="hi"
get_total_car_count()

print(marka_name)
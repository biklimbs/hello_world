import pandas as pd
import numpy as np
import pymysql.cursors
from random import shuffle,sample,randrange
import traceback
import sys
from datetime import datetime,date, timedelta
import time as t


MY_SQL_HOST_NAME = 'mysqldb.stg.chanceworldautomall.com'
MY_SQL_USER_NAME = 'vicibi'
MY_SQL_PASSWORD = 'vicibi!46'
MY_SQL_DB_NAME = 'cwam'
PORT=3307

# MY_SQL_HOST_NAME = '172.0.0.1'
# MY_SQL_USER_NAME = 'root'
# MY_SQL_PASSWORD = 'Power@1234'
# MY_SQL_DB_NAME = 'cawm_rawdata'
TABLE = 'history'


RATE=["***","R","RA","1","2","3","3.5","4","4.5","5","6","S"]

AUCTION_HANDLER="JU%"

    
def check_if_Table_exits(connection_to_db,table):
	try:
		with connection_to_db.cursor() as db_cursor:
			sql_query = "desc "+table+" ;"
			db_cursor.execute(sql_query)
			table_check_result = db_cursor.fetchone()
			#print(line_cleaning_table_result)
			return True

	except Exception as e:
		print(e)
		# traceback.print_stack()
		return False

def connect_to_db(host,user,password,db):
	connection = 0
	while (connection==0):
		try:
			connection = pymysql.connect(host=host,
		                             user=user,
		                             password=password,
		                             port=PORT,
		                             db=db,
		                             charset='utf8mb4',
		                             cursorclass=pymysql.cursors.DictCursor)
		except Exception as e:
			print(e)
			t.sleep(10)

	return connection
    

def fetch_data(company,model,start_year,end_year, start_mileage, end_mileage,kuzov,veh_grade,veh_cc,rate,color):
	
	empty_df=pd.DataFrame()

	try:
		connection = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		if(check_if_Table_exits(connection,TABLE)!=True):
		
			return empty_df,"Table "+TABLE+" is not in the "+MY_SQL_DB_NAME+" Database."
		# connection_to_db.set_character_set('utf8')
	except Exception as e:

		print("Database "+MY_SQL_DB_NAME+" connection not established.")
		return empty_df,"Database "+MY_SQL_DB_NAME+" connection not established."
	

	try:
		# print(rate)
		# print(color)
		print(start_year,end_year)
		
		# print(company,model,start_year,end_year, start_mileage, end_mileage,kuzov,rate,rate_forward,rate_backward,color)
		# print(LOCAL_TIME)
		# LOCAL_TIME_TEMP=pd.to_datetime(LOCAL_TIME) - timedelta(days=28)
		# print(LOCAL_TIME_TEMP)
		price = 0
		success = False
		message = ""
		# connection = connect_to_db(MY_SQL_HOST_NAME,MY_SQL_USER_NAME,MY_SQL_PASSWORD,MY_SQL_DB_NAME)
		sql_empty = "select FINISH FROM "+TABLE
		sql_where = "select * FROM "+TABLE+" Where AUCTION not like \"USS%\" and AUCTION not like \""+AUCTION_HANDLER+"\" and FINISH != 0  and "
		sql = sql_empty
		if (company == "" and model == "" and start_year == "" and end_year == "" and start_mileage == "" and end_mileage == "" and kuzov == ""):
			#sql = sql_empty
			price = 0
			success = False
			message = "No Configuration Selected."
			return price, success, message
		else:
			sql = sql_where
			if (company != ""):
				sql = sql+"MARKA_NAME = \""+company+"\""+" and "

			if (model != ""):
				sql = sql+"MODEL_NAME = \""+model+"\""+" and "

			if (start_year != "") and (end_year != ""):
				sql = sql+"YEAR between "+start_year+" and "+end_year+" and "
			elif (start_year == "") and (end_year != ""):
				sql = sql+"YEAR <= "+end_year+" and "
			elif (start_year != "") and (end_year == ""):
				sql = sql+"YEAR <= "+start_year+" and "

			if (start_mileage != "") and (end_mileage != ""):
				sql = sql+"MILEAGE between "+start_mileage+" and "+end_mileage+" and "
			elif (start_mileage != "") and (end_mileage == ""):
				sql = sql+"MILEAGE >= "+start_mileage+" and "

			if (kuzov != ""):
				sql = sql+"KUZOV = \""+kuzov+"\""+" and "

			if (veh_grade != [] and len(veh_grade)!=1):
				veh_grade=tuple(veh_grade)
				veh_grade=str(veh_grade)
				# print(rate)
				sql = sql+"GRADE in "+veh_grade+" and "

			elif (veh_grade != [] and len(veh_grade)==1):
				veh_grade_= "(\""+str(veh_grade[0])+"\")"
				sql = sql+"GRADE in "+veh_grade_+" and "

			if (veh_cc != [] and len(veh_cc)!=1):
				veh_cc=tuple(veh_cc)
				veh_cc=str(veh_cc)
				# print(rate)
				sql = sql+"ENG_V in "+veh_cc+" and "

			elif (veh_cc != [] and len(veh_cc)==1):
				veh_cc_= "(\""+str(veh_cc[0])+"\")"
				sql = sql+"ENG_V in "+veh_cc_+" and "

			if (rate != [] and len(rate)!=1):
				rate=tuple(rate)
				rate=str(rate)
				# print(rate)
				sql = sql+"RATE in "+rate+" and "
			elif (rate != [] and len(rate)==1):
				rate_= "(\""+str(rate[0])+"\")"
				sql = sql+"RATE in "+rate_+" and "
			


			# sql=sql+"LOCAL_TIME between \'"+str(LOCAL_TIME_TEMP)+"\' and \'"+str(LOCAL_TIME)+"\' ;"

			if (color != [] and len(color)!=1):
				color=tuple(color)
				color=str(color)
				# print(color)
				sql = sql+"COLOR in "+color+" and "
			elif (color != [] and len(color)==1):
				color_= "(\""+str(color[0])+"\")"
				sql = sql+"COLOR in "+color_+" and "

			sql = sql[0:-4]
			print (sql)
			# sys.exit()

		
			with connection.cursor() as db_cursor:
				# sql="select FINISH FROM "+TABLE+" where MARKA_NAME='"+company+"' and MODEL_NAME ='"+model+"' and YEAR >="+year+" and MILEAGE>="+mileage+" and KUZOV =\""+kuzov+"\" and  AUCTION not like 'USS%' and FINISH != 0;"
				db_cursor.execute(sql)
				car_details = db_cursor.fetchall()
				print(pd.DataFrame(car_details))
	except Exception as e:
		print(str(e))
		return empty_df,"Error in creating query..."
		# traceback.print_exc()
	return car_details, sql

def Three_sigma_algorithm(res_df):
	if(len(res_df)>2):
		res_array = np.asarray(res_df["FINISH"])
		# print(res_array)
		res_df["FINISH"]=res_df["FINISH"].astype(int)
		print("BEFORE REMOVING OUTLIER MEAN: "+str(round(res_df["FINISH"].mean(),2)))
		print("BEFORE REMOVING OUTLIER MEDIAN: "+str(res_df["FINISH"].median()))
		max_value_outlier=res_df["FINISH"].mean() + 3 * res_df["FINISH"].std()
		min_value_outlier= res_df["FINISH"].mean() - 3 * res_df["FINISH"].std()
	 	# print(res_df)
		df_= res_df[(res_df["FINISH"] > int(min_value_outlier)) & (res_df["FINISH"] < int(max_value_outlier))]
		# print(df_)
		print("AFTER REMOVING OUTLIER MEAN: "+str(round(df_["FINISH"].mean(),2)))
		print("AFTER REMOVING OUTLIER MEDIAN: "+str(df_["FINISH"].median()))

		# price = round(df_["FINISH"].mean(),2)
		price = df_["FINISH"].median()
		success = True
		message = "success"
		return price, success, message
	else:
		print(res_df)
		res_df["FINISH"]=res_df["FINISH"].astype(int)
		print("AFTER REMOVING OUTLIER MEAN: "+str(round(res_df["FINISH"].mean(),2)))
		price = round(res_df["FINISH"].mean(),2)
		# print("AFTER REMOVING OUTLIER MEDIAN:",res_df["FINISH"].median())
		# price = res_df["FINISH"].median()
		success = True
		message = "success"
		return price, success, message



def car_price_prediction(car_details):
	res_df=pd.DataFrame(car_details)
	# print(res_df)
	len_count= len(res_df)
	res_df= res_df.sort_values(by="AUCTION_DATE")

	# res_df= check_mileage_range(res_df,mileage)
	res_df["MILEAGE"]=res_df["MILEAGE"].astype(int)

	res_df= res_df.reset_index(drop=True)
	# print(res_df)
	price, success, message=Three_sigma_algorithm(res_df)
	return price, success, message, len_count

# def rate_update(rate,backward,forward):
# 	if forward:
# 		if rate in RATE:
# 			pos= RATE.index(rate)
# 			if pos==(len(RATE)-1):
# 				rate_forward= rate
# 			else:
# 				rate_forward=RATE[pos+1]
# 			print("New start rate= "+rate_forward)
# 			return rate_forward
# 		else:
# 			return rate
# 	else:
# 		if rate in RATE:
# 			pos= RATE.index(rate)
# 			if pos==0:
# 				rate_backward= rate
# 			else:
# 				rate_backward=RATE[pos-1]
# 			print("New end rate= "+rate_backward)
# 			return rate_backward
# 		else:
# 			return rate


def get_avg_price(company,model,start_year,end_year, start_mileage, end_mileage,kuzov,veh_grade,veh_cc,rate,color):
	try:
		# rate_forward=""
		# rate_backward=""
		car_details, sql=fetch_data(company,model,start_year,end_year, start_mileage, end_mileage,kuzov,veh_grade,veh_cc,rate,color)
		# car_data_rate_flag=True
		# car_details=[]
		if (len(car_details)>0):
			price, success, message, len_count= car_price_prediction(car_details)
			return price, success, message, len_count, sql
		
		else:
			price = 0
			success = False
			message = "No cars found based on the above configuration."
			len_count= 0
			return price, success, message, len_count, sql

	except Exception as e:
		# traceback.print_exc()
		print(str(e))
		price = 0
		success = False
		message = str(e)
		len_count= 0
		sql=''
		return car_price_prediction, success, message, len_count, sql
	
def search_car(company,model,year_range_start,year_range_end, mileage_range, kuzov,veh_grade,veh_cc,rate,color):
	try:
		# if "-" in year_range:
		# 	start_year,end_year= year_range.split("-")
		# if "<" in year_range_start:
		# 	start_year,end_year= year_range.split("<=")
		# elif year_range == "":
		# 	start_year,end_year= "",""
		# 	# print(start_year,end_year)
		FLAG_YEAR=0

		if "<" in year_range_start:
			FLAG_YEAR +=1
			temp_year,start_year= year_range_start.split("<=")
		elif year_range_start=="":
			start_year,temp_year="",""
		else:
			start_year=year_range_start
			# print(search_start_year,search_end_year)

		if "<" in year_range_end:
			FLAG_YEAR +=1
			temp_year,end_year= year_range_end.split("<=")
		elif year_range_end=="":
			end_year,temp_year="",""
		else:
			end_year= year_range_end
			# print(search_start_year,search_end_year)

		if FLAG_YEAR ==2:
			start_year,end_year="",end_year



		if "-" in mileage_range:
			start_mileage, end_mileage= mileage_range.split("-")
		elif ">" in mileage_range:
			end_mileage,start_mileage= mileage_range.split(">=")
		elif mileage_range == "":
			start_mileage, end_mileage= "",""
			# print(start_mileage,end_mileage)

		# print(company+","+model+","+kuzov+","+start_year+","+end_year+"," +start_mileage+"," +end_mileage+","+str(rate)+","+str(color))
		return get_avg_price(company,model,start_year,end_year,start_mileage, end_mileage,kuzov,veh_grade,veh_cc,rate,color)
	except Exception as e:
		print(str(e))
		return 0,False,str(e),0,''

# if __name__=="__main__":
# 	search_make=str(sys.argv[1])
# 	search_model=str(sys.argv[2])
# 	search_kuzov=str(sys.argv[3])
# 	veh_grade= []
# 	veh_cc= []
# 	search_start_year_range="2006"
# 	search_end_year_range="2006"
# 	# search_year_range="<=2000"
# 	search_mileage_range=str(sys.argv[4])
# 	# search_mileage_range=">=120000"
# 	# search_rate=str(sys.argv[6])
# 	# search_color=str(sys.argv[7])
# 	search_rate=['3.5','4']
# 	# search_rate=[]
# 	search_color=['silver','white']
# 	# search_color=""
# 	# if "-" in search_year_range:
# 	# 	search_start_year,search_end_year= search_year_range.split("-")
# 	FLAG_YEAR=0

# 	if "<" in search_start_year_range:
# 		FLAG_YEAR +=1
# 		temp_year,search_start_year= search_start_year_range.split("<=")
# 	elif search_start_year_range=="":
# 		search_start_year,temp_year="",""
# 	else:
# 		search_start_year=search_start_year_range
# 		# print(search_start_year,search_end_year)

# 	if "<" in search_end_year_range:
# 		FLAG_YEAR +=1
# 		temp_year,search_end_year= search_end_year_range.split("<=")
# 	elif search_end_year_range=="":
# 		search_end_year,temp_year="",""
# 	else:
# 		search_end_year= search_end_year_range
# 		# print(search_start_year,search_end_year)

# 	if FLAG_YEAR ==2:
# 		search_start_year,search_end_year="",search_end_year

# 	if "-" in search_mileage_range:
# 		search_start_mileage, search_end_mileage= search_mileage_range.split("-")
# 	elif ">" in search_mileage_range:
# 		search_end_mileage,search_start_mileage= search_mileage_range.split(">=")
# 	elif search_mileage_range == "":
# 		search_start_mileage, search_end_mileage="",""
# 		# print(search_start_mileage,search_end_mileage)
# 	print(search_start_year,search_end_year)
# 	# log.info(search_make+","+search_model+","+search_kuzov)
# 	print(get_avg_price(search_make,search_model,search_start_year,search_end_year,search_start_mileage, search_end_mileage,search_kuzov,veh_grade,veh_cc,search_rate,search_color))	 	

# print(search_car("AUDI","A3","2001", "2018","","8PBLR",[ "2.0 fsi", "2.0FSI", "A3 SB 2.0 FSI", "Sports Back", "Sports back 2.0 FSI", "Sportsback 2.0 FSI", "a3", "sports back 2.0fsi" ],[],[],[]))
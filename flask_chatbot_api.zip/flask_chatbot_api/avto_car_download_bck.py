import datetime
import sys,os
sys.path.append('/usr/local/lib/python3.5/dist-packages')
sys.path.append(os.path.abspath(os.path.join('./scripts')))
import pandas as pd
import pymysql.cursors
import time as t
import json
from time import sleep
from datetime import datetime, time
from logger_config import *
import logger_config
from datetime import date, timedelta
import random
from termcolor import colored
import requests



#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#---Server credentials---
HOST= "spark.vmokshagroup.com"
USER="root"
PASSWORD="Vmmobility@1234"
SOURCE_DATABASE='avtojp_pipeline'

#---DB TABLE NAMES---
MAKE_MODEL_TABLE='make_model_non_uss'
HISTORY_TABLE='history_non_uss'

SQL_LEFT="\""
SQL_RIGHT="\","

#---Time Delay---
MIN_IN_MODEL_250_DELAY=60
MAX_IN_MODEL_250_DELAY=90

#HISTORY_DOWNLOAD_PLAN_TABLE='download_plan_historic'
HISTORY_BASE_URL="http://75.125.226.218/xml/json?&ip=10.10.0.0&code=y19Hfrte_Dm&sql="

#---SQL queries---
MAKE_MODEL_QUERY="SELECT * FROM "+MAKE_MODEL_TABLE+" order by count desc limit 1"

#---Connection to "DATABASE_Exception"---
def connect_to_db(database_name):
	connection = pymysql.connect(host=HOST,
                                     user=USER,
                                     password=PASSWORD,
                                     db=database_name,
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)
	return connection

#---Read the data from  table in the db---
def read_data_from_db(connection,sql_query):
	with connection.cursor() as cursor:
		try:
			sql=sql_query
			print(sql)
			cursor.execute(sql)
			if cursor.rowcount > 0:
				df=pd.DataFrame(cursor.fetchall())
				return df
			else:
				print("Empty Results")	
		except Exception as e:
			log.error(e)

#----------- Rest API based on marka and model, where returns response in json fromat ----------
def api_call_model(marka,model,st_limt,end_limt):
    response  = ""
    while (response == ""):
        try:
            pass
            response = requests.get("http://75.125.226.218/xml/json?&ip=10.10.0.0&code=y19Hfrte_Dm&sql=select+*+from+stats+where+MARKA_NAME%3D%27"+marka+"%27+and+MODEL_NAME%3D%27"+model+"%27"+"and+AUCTION+not+like+%27USS%25%27+LIMIT+"+str(st_limt)+"%2C+"+str(end_limt),timeout = 6000)
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()
#----------- Rest API based on marka and model, where returns response in json fromat ----------
def get_count(marka,model):
    response  = ""
    while (response == ""):
        try:
        	response = requests.get("http://75.125.226.218/xml/json?&ip=10.10.0.0&code=y19Hfrte_Dm&sql=select+count%28*%29+from+stats+where+MARKA_NAME%3D%27"+marka+"%27+and+MODEL_NAME%3D%27"+model+"%27and+AUCTION+not+like+%27USS%25%27",timeout = 6000)        	
        except Exception as e:
            print("API CALL TIME OUT",e)
    return response.json()
    

#----------- Inserting data to car_future_all table for each car done here  ----------
def insert_to_table(db_connection_obj,ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,EQUIP,RATE,START,FINISH,STATUS,TIME,AVG_PRICE,AVG_STRING,IMAGES,stock_id_):
    try:
        sql_=""
        with db_connection_obj.cursor() as hadoop_cursor:
            today_=str(str(datetime.today())[:16])		
            sql = "insert into "+HISTORY_TABLE+" (ID,LOT,AUCTION_DATE,AUCTION,MARKA_ID,MODEL_ID,MARKA_NAME,MODEL_NAME,YEAR,ENG_V,PW,KUZOV,GRADE,COLOR,KPP,KPP_TYPE,PRIV,MILEAGE,EQUIP,RATE,START,FINISH,STATUS,TIME,AVG_PRICE,AVG_STRING,IMAGES,LOCAL_TIME,STOCK_ID) VALUES(\""+ID+"\","+LOT+",\""+AUCTION_DATE+"\",\""+AUCTION+"\","+MARKA_ID+","+MODEL_ID+",\""+MARKA_NAME+"\",\""+MODEL_NAME+"\","+YEAR+",\""+ENG_V+"\",\""+str(PW)+"\",\""+KUZOV+"\",\""+GRADE+"\",\""+COLOR+"\",\""+KPP+"\","+KPP_TYPE+",\""+PRIV+"\","+MILEAGE+",\""+EQUIP+"\",\""+RATE+"\","+START+",\""+FINISH+"\",\""+STATUS+"\",\""+TIME+"\","+AVG_PRICE+",\""+AVG_STRING+"\",\""+IMAGES+"\",\""+today_+"\","+str(stock_id_)+")"
            hadoop_cursor.execute(sql)
            db_connection_obj.commit()
            print("Inserting into table")

    except Exception as e:
        log.error(e)
        log.error(sql_)

#---This function increments the counter  in "lot_number" table---
def update_db(make,model):
    connection=connect_to_db(SOURCE_DATABASE)
    with connection.cursor() as cursor:
        try:			
            sql ="update "+MAKE_MODEL_TABLE+" set download_flag=1 where make= "+SQL_LEFT+str(make)+SQL_LEFT+"and model="+SQL_LEFT+str(model)+SQL_LEFT
            cursor.execute(sql)
            connection.commit()
            log.info(colored("Updating table","yellow"))
        except Exception as e:
            log.error(colored(str(e),"red"))
    connection.close()

#----------- Get cars based on MARKA and MODEL and Inserted to table done here ----------
def download_car_info_(json_):
    try:
        db_connection_obj = connect_to_db(SOURCE_DATABASE)
        start_time=t.time()
        stock_id_=1
        for car_model in range(int(len(json_))):
            stock_id_=stock_id_+1
            today_=str(str(datetime.today())[:16])
            car_model_details=json_[car_model]
            if('AVG_PRICE' in car_model_details and 'AVG_STRING' in car_model_details):
                insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],car_model_details['AVG_PRICE'],car_model_details['AVG_STRING'],car_model_details['IMAGES'],stock_id_)
            if('AVG_PRICE' not in car_model_details and 'AVG_STRING' not in car_model_details):
                insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],'0','NULL',car_model_details['IMAGES'],stock_id_)
            elif('AVG_STRING' not in car_model_details):
                insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],car_model_details['AVG_PRICE'],'NULL',car_model_details['IMAGES'],stock_id_)
            elif('AVG_PRICE' not in car_model_details):
                insert_to_table(db_connection_obj,car_model_details['ID'],car_model_details['LOT'],car_model_details['AUCTION_DATE'],car_model_details['AUCTION'],car_model_details['MARKA_ID'],car_model_details['MODEL_ID'],car_model_details['MARKA_NAME'],car_model_details['MODEL_NAME'],car_model_details['YEAR'],car_model_details['ENG_V'],car_model_details['PW'],car_model_details['KUZOV'],car_model_details['GRADE'],str(car_model_details['COLOR']),car_model_details['KPP'],car_model_details['KPP_TYPE'],car_model_details['PRIV'],car_model_details['MILEAGE'],car_model_details['EQUIP'],car_model_details['RATE'],car_model_details['START'],car_model_details['FINISH'],car_model_details['STATUS'],car_model_details['TIME'],'0',car_model_details['AVG_STRING'],car_model_details['IMAGES'],stock_id_)

        end_time=t.time()-start_time
        log.info("time taken to download is "+str(end_time))
        db_connection_obj.close()
    except Exception as e:
        log.error(e)	

#----------- Get cars based on MARKA and MODEL and Inserted to table done here ----------
def download_car_info(marka,model):
    try:
        get_count_=int(str(get_count(marka,model)[0]['TAG0']))
        if(get_count_>250):
            try:
                count = get_count_/250
                loop_int=int(count)+1 if(int(count)<count) else int(count)
                st_limt=0
                end_limt=0
                for let in range(loop_int):
                    st_limt=st_limt
                    end_limt=st_limt+250
                    download_car_info_(api_call_model(marka,model,st_limt,end_limt))
                    st_limt=end_limt
                    sleep(random.randint(MIN_IN_MODEL_250_DELAY,MAX_IN_MODEL_250_DELAY))
                    #log.info("time taken to download "+str(model)+"   "+str(end_time))
                    #log.info(model)
                update_db(marka,model)
                return True,get_count_
            except Exception as e:
                log.error(e)
        else:
            try:
                start_time=t.time()
                download_car_info_(api_call_model(marka,model,'0','250'))
                end_time=t.time()-start_time
                log.info("time taken to download "+str(model)+"   "+str(end_time))
                log.info(model)
                update_db(marka,model)
                return True,get_count_	
            except Exception as e:
                log.error(e)
    except Exception as e:
        log.error(e)
        return False
		
#-----------Checking date,inserting data and updating flag done here ----------                 
def download_scheduler(make,model):
    try:	
        status_,count=download_car_info(str(make),str(model))
        return count			
    except Exception as e:
        log.error(e)

#---Gets make,model from database---
def get_make_model(make,model,query):

    count=download_scheduler(make,model)
    return count


#----------- Main starts from here----------      
def main():
    try:
        #count=get_make_model()
        print(count)
        '''
        connection=connect_to_db(SOURCE_DATABASE)
        df=read_data_from_db(connection,MAKE_MODEL_QUERY)
        print(df)
        ##check_connection(HOST,USER,PASSWORD,PORT)
        #today_date=str(datetime.now().strftime("%Y-%m-%d"))
        #for row in load_download_plan(today_date):
        #download_scheduler("NISSAN","SKYLINE")
        #log.info("downloaded done for "+today_date)
        '''
    except Exception as e:
        log.error(e)



#----------- Main ----------      
if __name__ == "__main__":
	main()

	

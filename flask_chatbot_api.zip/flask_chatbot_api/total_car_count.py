import datetime
import sys,os
sys.path.append('/usr/local/lib/python3.5/dist-packages')
sys.path.append(os.path.abspath(os.path.join('./scripts')))
import pandas as pd
import pymysql.cursors
import time as t
import json
from time import sleep
from datetime import datetime, time
from logger_config import *
import logger_config
from datetime import date, timedelta
import random
from termcolor import colored
import requests
import http.client



#---Lambda function credential---
QUOTE_LAMBDA_URL="49d98nf2r7.execute-api.ap-northeast-1.amazonaws.com"
QUOTE_LAMBDA_EXTENSION_URL="/api/v1/spotquote"
QUOTE_LAMBDA_POSTMAN_TOKEN="80a92761-81cc-e80e-f0b9-ad92d503f0e6"
QUOTE_LAMBDA_METHOD="POST"  

#---Configuring log filename---
log_file=os.path.splitext(os.path.basename(__file__))[0]+".log"
log = logger_config.configure_logger('default', ""+DIR+""+LOG_DIR+"/"+log_file+"")

#---Server credentials---
HOST_NAME= "spark.vmokshagroup.com"
USER_NAME="root"
PASSWORD="Vmmobility@1234"
DATABASE_NAME='recommendation_model'

'''
HOST_NAME = 'mysqldb.stg.chanceworldautomall.com'
USER_NAME = 'vicibi'
PASSWORD = 'vicibi!46'
DATABASE_NAME = 'cwam'
PORT=3307
'''

HISTORY_TABLE="future_recommendation_preprocess"

TOTAL_COUNT_QUERY="SELECT  count(*) FROM "+HISTORY_TABLE

SQL_LEFT="\""
SQL_RIGHT="\","

#MAKE_MODEL_COUNT_QUERY="SELECT  count(*) FROM "+HISTORY_TABLE+" where MARKA_NAME="+

#---Connection to "DATABASE_Exception"---
def connect_to_db(database_name):
	connection = pymysql.connect(host=HOST_NAME,
                                     user=USER_NAME,
                                     password=PASSWORD,
                                     db=database_name,
                                     charset='utf8mb4',
                                     cursorclass=pymysql.cursors.DictCursor)
	return connection

#---Read the data from  table in the db---
def read_data_from_db(connection,sql_query):
    with connection.cursor() as cursor:
        try:
            sql=sql_query
            print(sql)
            cursor.execute(sql)
            if cursor.rowcount > 0:
                df=pd.DataFrame(cursor.fetchall())
            else:
                df=pd.DataFrame()
                print("Empty Results")	
        except Exception as e:
            log.error(e)
    connection.close()
    return df

#---Returns total car count---
def get_total_count():
    connection=connect_to_db(DATABASE_NAME)
    return read_data_from_db(connection,TOTAL_COUNT_QUERY).iloc[0,0]

#---Returns make,model total count---
def get_make_model_total_count(make,model):
    connection=connect_to_db(DATABASE_NAME)
    make_model_query=TOTAL_COUNT_QUERY+" where MARKA_NAME="+SQL_LEFT+make+SQL_LEFT+" and MODEL_NAME="+SQL_LEFT+model+SQL_LEFT
    return read_data_from_db(connection,make_model_query)


#---Returns all distinct make---
def get_all_make():
    connection=connect_to_db(DATABASE_NAME)
    make_query="SELECT  MARKA_NAME,count(*) FROM "+HISTORY_TABLE+" group by MARKA_NAME order by count(*) desc limit 10"
    df=read_data_from_db(connection,make_query)
    make_list=list(df["MARKA_NAME"])
    make_list=sorted(make_list)
    return str(' '.join(make_list))

#---Returns all distinct model---
def get_all_model(make):
    connection=connect_to_db(DATABASE_NAME)
    model_query="SELECT MODEL_NAME,count(*) FROM "+HISTORY_TABLE+" where MARKA_NAME="+SQL_LEFT+make+SQL_LEFT+" group by MODEL_NAME order by count(*) desc limit 10"
    #model_query="SELECT  distinct MODEL_NAME FROM "+HISTORY_TABLE+" where MARKA_NAME="+SQL_LEFT+make+SQL_LEFT
    df=read_data_from_db(connection,model_query)
    model_list=list(df["MODEL_NAME"])
    model_list=sorted(model_list)
    return str(','.join(model_list))

#---Returns all distinct kuzov---
def get_all_kuzov(make,model):
    connection=connect_to_db(DATABASE_NAME)
    model_query="SELECT  distinct KUZOV FROM "+HISTORY_TABLE+" where MARKA_NAME="+SQL_LEFT+make+SQL_LEFT+" and MODEL_NAME="+SQL_LEFT+model+SQL_LEFT
    df=read_data_from_db(connection,model_query)
    kuzov_list=list(df["KUZOV"])
    kuzov_list=sorted(kuzov_list)
    return str(' '.join(kuzov_list))

#---Returns all distinct year---
def get_all_years(make,model,kuzov):
    now=datetime.now()
    next_year=str(int(now.year)+1)
    connection=connect_to_db(DATABASE_NAME)
    year_query="SELECT  distinct YEAR FROM "+HISTORY_TABLE+" where MARKA_NAME="+SQL_LEFT+make+SQL_LEFT+" and MODEL_NAME="+SQL_LEFT+model+SQL_LEFT+" and YEAR<"+SQL_LEFT+next_year+SQL_LEFT+" and KUZOV="+SQL_LEFT+kuzov+SQL_LEFT
    df=read_data_from_db(connection,year_query)
    year_list=list(df["YEAR"])
    year_list=sorted(year_list)
    #''.join(map(str, my_lst))
    return str(' '.join(map(str,year_list)))

#---Returns all distinct mileage---
def get_all_mileage(make,model,year,kuzov):
    connection=connect_to_db(DATABASE_NAME)
    mileage_query="SELECT  distinct MILEAGE FROM "+HISTORY_TABLE+" where MARKA_NAME="+SQL_LEFT+make+SQL_LEFT+" and MODEL_NAME="+SQL_LEFT+model+SQL_LEFT+" and YEAR="+SQL_LEFT+year+SQL_LEFT+" and KUZOV="+SQL_LEFT+kuzov+SQL_LEFT
    df=read_data_from_db(connection,mileage_query)
    if df.empty:
        return "",False
    else:
        mileage_list=list(df["MILEAGE"])
        return mileage_list,True

#---Returns all distinct rate---
def get_all_rate(make,model,mileage,year,kuzov):
    mileage_low=0
    mileage_high=0
    '''
    #mileage=int(mileage)
    if mileage<20000:
        mileage_low=0
        mileage_high=20000
    elif (mileage>=20000 and mileage<30000):
        mileage_low=20000
        mileage_high=30000
    elif (mileage>=30000 and mileage<40000):
        mileage_low=30000
        mileage_high=40000
    elif (mileage>=40000 and mileage<50000):
        mileage_low=40000
        mileage_high=50000
    elif (mileage>=50000 and mileage<60000):
        mileage_low=50000
        mileage_high=60000
    elif (mileage>=60000 and mileage<70000):
        mileage_low=60000
        mileage_high=70000
    elif (mileage>=70000 and mileage<80000):
        mileage_low=70000
        mileage_high=80000
    elif (mileage>=80000 and mileage<90000):
        mileage_low=80000
        mileage_high=90000
    elif (mileage>=90000 and mileage<100000):
        mileage_low=90000
        mileage_high=100000
    elif (mileage>=100000 and mileage<110000):
        mileage_low=100000
        mileage_high=110000
    elif (mileage>=110000 and mileage<120000):
        mileage_low=110000
        mileage_high=120000
    elif (mileage>=120000 and mileage<130000):
        mileage_low=120000
        mileage_high=130000
    elif (mileage>=130000 and mileage<140000):
        mileage_low=130000
        mileage_high=140000
    elif (mileage>=140000 and mileage<150000):
        mileage_low=140000
        mileage_high=150000
    elif (mileage>=140000 and mileage<150000):
        mileage_low=140000
        mileage_high=150000
    elif (mileage>=150000 and mileage<160000):
        mileage_low=150000
        mileage_high=160000
    elif (mileage>=160000):
        mileage_low=160000
        mileage_high=mileage
    '''
    connection=connect_to_db(DATABASE_NAME)
    rate_query="SELECT  distinct RATE FROM "+HISTORY_TABLE+" where MARKA_NAME="+SQL_LEFT+make+SQL_LEFT+"and MODEL_NAME="+SQL_LEFT+model+SQL_LEFT+"and MILEAGE between "+mileage+" and YEAR="+SQL_LEFT+year+SQL_LEFT+" and KUZOV="+SQL_LEFT+kuzov+SQL_LEFT
    df=read_data_from_db(connection,rate_query)
    if df.empty:
        return "Sorry no car found for selected option\n Please select Another option from above List.",False
    else:
        rate_list=list(df["RATE"])
        return sorted(rate_list),True
    

#		REST API call to get bid prices based on selection        
def call_bid_lambda(country,port,vessel,company,model,s_year,e_year,mileage,kuzov,grade,engine_cc,rate,color):
    try:
        conn = http.client.HTTPSConnection(QUOTE_LAMBDA_URL)
        payload = "{\"company\": \""+company+"\",\"model\": \""+model+"\",\"s_year\": \""+s_year+"\",\"e_year\": \""+e_year+"\",\"mileage\": \""+mileage+"\",\"color\": "+str(color)+" ,\"kuzov\": \""+kuzov+"\",\"rate\": "+str(rate)+",\"countryCode\":\""+country+"\",\"portCode\":\""+port+"\",\"vessleCode\":\""+vessel+"\",\"grade\":"+str(grade)+",\"eng_v\":"+str(engine_cc)+"}"
        log.info(str(payload))
        headers = {'content-type': "application/json",'cache-control': "no-cache",'postman-token': QUOTE_LAMBDA_POSTMAN_TOKEN}
        conn.request(QUOTE_LAMBDA_METHOD , QUOTE_LAMBDA_EXTENSION_URL, payload, headers)
        res = conn.getresponse()
        data = res.read()
        #return payload,json.loads(data.decode("utf-8"))
        print(data.decode("utf-8"))
        return data.decode("utf-8")
        # print(data.decode("utf-8"))
    except Exception as e:
        log.error(str(e))
        return {}
#---Main function()---      
def main():
    try:
        #df=get_total_count()
        #print(df.iloc[0,0])
        #df=get_all_rate("toyota","corolla","50000")
        #print(df)
        #print(sorted(get_all_make()))
        #response_dict=call_bid_lambda("ARU","6","1","AUDI","A3","2000","2014","","8PBLR",[],[],[4],[])
        response_dict=call_bid_lambda("ARU","6","1","toyota","ALLEX","2005","2018","","NZE121",[],[],['4'],[])
        #{"company": "toyota","model": "ALLEX","s_year": "2005","e_year": "2018","mileage": "","color": [] ,"kuzov": "NZE121","rate": ['4'],"countryCode":"ARU","portCode":"6","vessleCode":"1","grade":[],"eng_v":[]}
        #price="The price is"+str(response_dict[2])
        d = json.loads(response_dict)
        print(d["price"])
    except Exception as e:
        log.error(e)

#------ Main -------      
if __name__ == "__main__":
	main()
